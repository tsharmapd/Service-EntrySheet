sap.ui.define([
	"pd/fr/controller/BaseController",
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/routing/History",
	"pd/fr/model/formatter",
	"sap/ui/model/Filter",
	"sap/m/MessageToast",
	"sap/m/MessageBox",
	"sap/ui/model/FilterOperator"
], function(BaseController, JSONModel, History, formatter, Filter, MessageToast, MessageBox, FilterOperator) {
	"use strict";

	return BaseController.extend("pd.fr.controller.Worklist", {

		formatter: formatter,

		/* =========================================================== */
		/* lifecycle methods                                           */
		/* =========================================================== */

		/**
		 * Called when the worklist controller is instantiated.
		 * @public
		 * 	tankDips:false,
				pumpOut:false,")
		 */
		onBeforeRendering: function() {
			var oJSONModel = this.getOwnerComponent().getModel("json");
			var showingpage = oJSONModel.getData().oViewModel;
			this.byId("HboxId").setVisible(false);
			this.byId("idProductsTable").setVisible(false);
		},
		onAfterRendering: function() {
			var oJSONModel = this.getView().getModel("json");
			var payloadDatas = {
				"FuelData": [],
				"TankDipsData": [],
				"PumpOutData": []
			};
			oJSONModel.setProperty("/payloadDatas", payloadDatas);
			oJSONModel.setSizeLimit(99999);
		},
		handleLoadItems: function(oControlEvent) {
			oControlEvent.getSource().getBinding("items").resume();
		},
		handleChange: function(oEvent) {
	
		/*	var isEdited = this.isModelEdited();
			var isEditedSave = this.isModelEditSave();
			var message = "No changes have been made to the declaration since it was last saved";
			if (!isEdited || !isEditedSave) {
				this.saveDeclaration();
			} else {
				MessageBox.warning(message, {});
			}*/
		},
	/*	isModelEdited:function(){
			var isEdited;
			if()
		}
*/
		handleSelectionChange: function(oEvent) {

			if (oEvent.getSource().getSelectedItem() !== null) {
				var key = oEvent.getSource().getSelectedItem().getProperty("key");
				//	var text =  oEvent.getSource().getSelectedItem().getProperty("text");
			} else {
				key = "";
			}

			var that = this;
			that.resetAll();
			if (key == "F") {
				this.byId("page").setTitle("Fuel Receipt");
				this.byId("pnlId").setVisible(true);
				this.byId("HboxId").setVisible(true);
				this.byId("RgTypId").setSelectedKey();
				this.byId("LcId").setSelectedKey();
				this.byId("idProductsTable").setVisible(true);
				var oJSONModel = that.getOwnerComponent().getModel("json");
				sap.ui.core.BusyIndicator.show(0);
				var oView2 = {
					fuelRcpt: true,
					tankDips: false,
					pumpOut: false
				};
				oEvent.getSource().setSelectedKey(key);
				oJSONModel.setProperty("/oViewModel", oView2);
				oJSONModel.setProperty("/MatrlModel", "");
				oJSONModel.refresh(true);
				sap.ui.core.BusyIndicator.hide();
				var flagMsg = false; 
			}
			
			else {
				if (key == "T") {
					this.byId("pnlId").setVisible(true);
					this.byId("page").setTitle("Tank Dips");
					this.byId("HboxId").setVisible(true);
					this.byId("RgTypId").setSelectedKey();
					this.byId("LcId").setSelectedKey();
					var oJSONModel = that.getView().getModel("json");
					sap.ui.core.BusyIndicator.show(0);
					var oView3 = {
						fuelRcpt: false,
						tankDips: true,
						pumpOut: false
					};
					oEvent.getSource().setSelectedKey(key);
					oJSONModel.setProperty("/oViewModel", oView3);
					oJSONModel.setProperty("/MatrlModel", "");
					oJSONModel.refresh(true);
					sap.ui.core.BusyIndicator.hide();
				}
				if (key == "P") {
					this.byId("pnlId").setVisible(false);
					this.byId("page").setTitle("Pump Out");
					this.byId("HboxId").setVisible(true);
					this.byId("RgTypId").setSelectedKey();
					this.byId("LcId").setSelectedKey();
					var oJSONModel = that.getView().getModel("json");
					sap.ui.core.BusyIndicator.show(0);
					var oView2 = {
						fuelRcpt: false,
						tankDips: false,
						pumpOut: true
					};
					oEvent.getSource().setSelectedKey(key);
					oJSONModel.setProperty("/oViewModel", oView2);
					oJSONModel.setProperty("/MatrlModel", "");
					oJSONModel.refresh(true);
					sap.ui.core.BusyIndicator.hide();
				}
				//	oJSONModel.refresh(true);
			}
			
		},

		refreshTable: function() {
			var  model =this.getOwnerComponent().getModel("json");
			var that = this;
           if(model.getProperty("/oViewModel").fuelRcpt){
       that._oTable = that.byId('idProductsTable');for (var i = 0; i < that._oTable.getItems().length; i++) {
				that._oTable.getItems()[i].getCells()[0].setValue("");
				that._oTable.getItems()[i].getCells()[1].setValue("");
				that._oTable.getItems()[i].getCells()[2].setValue("");
						}
           }
           else if(model.getProperty("/oViewModel").pumpOut){
           		that._oTable = that.byId('pmpOutTable');
           		for (var i = 0; i < that._oTable.getItems().length; i++) {
				that._oTable.getItems()[i].getCells()[0].setValue("");
				that._oTable.getItems()[i].getCells()[1].setValue("");
				that._oTable.getItems()[i].getCells()[2].setValue("");
						}
           }
			
		 if(model.getProperty("/oViewModel").tankDips){
           	that._tnkTable = that.byId('tDpTable');
           	 for (var j = 0; j < that._tnkTable.getItems().length; j++) {
				that._tnkTable.getItems()[j].getCells()[0].setValue("");
				that._tnkTable.getItems()[j].getCells()[1].setValue("");
				that._tnkTable.getItems()[j].getCells()[2].setValue("");
				that._tnkTable.getItems()[j].getCells()[3].setValue("");
				that._tnkTable.getItems()[j].getCells()[4].setValue("");
		}
           }
		},
		resetAll: function() {
			var that = this;
			//that.byId("selComb").setSelectedKey("");
			//that.byId("selComb").setValueState("None");
			//that.byId("rbMngd").setSelected(false);
			//	that.byId("rbNMngd").setSelected(false);
			//	that.byId("rbRtoS").setSelected(false);
			//	that.byId("rbTtoR").setSelected(false);
		//	that.refreshTable();
			that.byId("RgTypId").setSelectedKey("");
			that.byId("RgTypId").setValueState("None");
			that.byId("LcId").setSelectedKey("");
			that.byId("LcId").setValueState("None");
			that.byId("VnId").setSelectedKey("");
			that.byId("tdstr").setSelectedKey("");
			that.byId("tdmat").setSelectedKey("");
			that.byId("VnId").setValueState("None");
			that.byId("cmb1").setSelectedKey("");
			that.byId("cmb1").setValueState("None");
			that.byId("cmb2").setSelectedKey("");
			that.byId("cmb2").setValueState("None");
			that.byId("Qt1").setValue("");
			that.byId("Qt1").setValueState("None");
			that.byId("delvyDt").setValueState("None");
			that.byId("delvyDt").setValue("");
			that.tableBinding();
			that.getOwnerComponent().getModel("json").refresh();

			//	that.byId("idProductsTable").unbindItems();
			//	that.byId("tDpTable").unbindItems();
			//	that.byId("pmpOutTable").unbindItems(); 
			//	that.byId("ScStg").setValue("");
			//	that.byId("Optyp").setValue("");
			//   that.byId("Dpth").setValue("");
		},
		onInit: function() {
			this.getOwnerComponent().getRouter().getRoute("worklist").attachPatternMatched(this._onPatternMatched, this);
			this.tableBinding();
			this.oBusy = new sap.m.BusyDialog();

		},

		tableBinding: function() {
			var oJSONModel = this.getOwnerComponent().getModel("json");
			var oModel = this.getOwnerComponent().getModel();
		 	sap.ui.core.BusyIndicator.show(0);
			oModel.read("/ItemsSet", {
				success: function(r) {
						sap.ui.core.BusyIndicator.hide();
					oJSONModel.setProperty("/tabModel", r.results);
				}
			});
		},

		validateComboBox: function(oEvt) {
			var comboBox = oEvt.getSource();
			if (comboBox.getSelectedItemId() === "") {
				comboBox.setValueState("Error");
				comboBox.setValueStateText("Select valid item from list.");
			} else {
				comboBox.setValueState("None");
			}
			//	this.createPayload();
		},
		_onPatternMatched: function() {
			this.populateVendor();
			this.populateLocation();
			this.populateRigStorage();
			this.populateRig();
			this.populateRigType();
			this.populateMaterial();
			this.populateDepth();
			this.populateSection();
			this.populateOperationType();
			var oModel = this.getOwnerComponent().getModel();
			var oJSONModel = this.getOwnerComponent().getModel("json");
			sap.ui.core.BusyIndicator.show(0);
			oModel.read("/RecptTypeSet", {
				success: function(r) {
					sap.ui.core.BusyIndicator.hide();
					oJSONModel.setProperty("/ViewDrpdwn", r.results);
				}
			});
			var oModel = this.getView().getModel("oviewModel");
		},
		populateDepth: function() {
			var oModel = this.getOwnerComponent().getModel();
			var oJSONModel = this.getOwnerComponent().getModel("json");
			oModel.read("/welldiameterSet", {
				success: function(r) {
					oJSONModel.setProperty("/diaModel", r.results);
				},
				error: function() {}
			});
		},
		populateOperationType: function() {
			var oModel = this.getOwnerComponent().getModel();
			var oJSONModel = this.getOwnerComponent().getModel("json");
			oModel.read("/OperationsSet", {
				success: function(r) {
					oJSONModel.setProperty("/oprtnModel", r.results);
				},
				error: function() {}
			});
		},
		populateSection: function() {
			var oModel = this.getOwnerComponent().getModel();
			var oJSONModel = this.getOwnerComponent().getModel("json");
			oModel.read("/wellsectionSet", {
				success: function(r) {
					oJSONModel.setProperty("/secModel", r.results);
				},
				error: function() {}
			});

		},
		populateVendor: function() {
			var oModel = this.getOwnerComponent().getModel();
			var oJSONModel = this.getOwnerComponent().getModel("json");
			oModel.read("/VendorSet", {
				success: function(r) {
					oJSONModel.setProperty("/VndrModel", r.results);
				},
				error: function() {}
			});
		},
		populateLocation: function() {
			this._oTable = this.getView("table");
			//	this._oTableOperations = new TableOperations(this._oTable, ["Name", "Id", "Description"]);
			var oModel = this.getOwnerComponent().getModel();
			var oJSONModel = this.getOwnerComponent().getModel("json");
			sap.ui.core.BusyIndicator.show(0);
			oModel.read("/RigLocSet", {
				success: function(r) {
					sap.ui.core.BusyIndicator.hide();
					oJSONModel.setProperty("/LocModel", r.results);
				},
				error: function() {
					sap.ui.core.BusyIndicator.hide();
					MessageToast.show("Unable to get Location . Please try again.");
				}
			});
		},
		populateRigStorage: function() {
			this._oTable = this.getView("table");
			//	this._oTableOperations = new TableOperations(this._oTable, ["Name", "Id", "Description"]);
			var oModel = this.getOwnerComponent().getModel();
			var oJSONModel = this.getOwnerComponent().getModel("json");
			sap.ui.core.BusyIndicator.show(0);
			oModel.read("/RigStorageLocSet", {
				success: function(r) {
					sap.ui.core.BusyIndicator.hide();
					oJSONModel.setProperty("/StorModel", r.results);
				},
				error: function() {
					sap.ui.core.BusyIndicator.hide();
					MessageToast.show("Unable to get Storage Location. Please try again.");
				}
			});
		},
		populateRig: function() {
			var oModel = this.getOwnerComponent().getModel();
			var oJSONModel = this.getOwnerComponent().getModel("json");
			sap.ui.core.BusyIndicator.show();
			oModel.read("/RigNoSet", {
				success: function(r) {

					oJSONModel.setProperty("/RigModel", r.results);
					sap.ui.core.BusyIndicator.hide();
				},
				error: function() {
					sap.ui.core.BusyIndicator.hide();
					MessageToast.show("Unable to get manufacture Data. Please try again.");
				}
			});
		},
		populateRigType: function() {
			this._oTable = this.getView("table");
			var oModel = this.getOwnerComponent().getModel();
			var oJSONModel = this.getOwnerComponent().getModel("json");
			sap.ui.core.BusyIndicator.show(0);
			oModel.read("/RigTypesSet", {
				success: function(r) {
					sap.ui.core.BusyIndicator.hide();
					oJSONModel.setProperty("/RigTypeModel", r.results);
				},
				error: function() {
					sap.ui.core.BusyIndicator.hide();
					MessageToast.show("Unable to get the Rig Type. Please try again.");
				}
			});
		},
		populateMaterial: function() {
			this._oTable = this.getView("table");
			var oModel = this.getOwnerComponent().getModel();
			var oJSONModel = this.getOwnerComponent().getModel("json");

			//	sap.ui.core.BusyIndicator.show(0);

			var fValue1 = oJSONModel.getProperty("/sRig");
			var fValue2 = oJSONModel.getProperty("/sLoc");
			var aFilters = [new Filter("Rigtype", "EQ", fValue1), new Filter("Location", "EQ", fValue2)];
			oModel.read("/MaterialSet", {
				filters: aFilters,
				success: function(r) {
					//	sap.ui.core.BusyIndicator.hide();
					oJSONModel.setProperty("/MatrlModel", r.results);
				},
				error: function() {
					sap.ui.core.BusyIndicator.hide();
				}
			});
		},
		onSelectedRig: function(oEvent) {
			var ojsonModel = this.getOwnerComponent().getModel("json");
			var oVal = oEvent.getSource().getSelectedItem().getProperty("key");
			ojsonModel.setProperty("/sRig", oVal);
			this.populateMaterial();
		},
		onSelectedLocation: function(oEvent) {
			var ojsonModel = this.getOwnerComponent().getModel("json");
			var loc = oEvent.getSource().getSelectedItem().getProperty("key");
			ojsonModel.setProperty("/sLoc", loc);
			this.populateMaterial();
		},
		onSelections: function(oEvent) {
			var iIndex = this.byId("tDpTable").indexOfItem(this.byId("tDpTable").getSelectedItem());
			this.getOwnerComponent().getModel("json").setProperty("/index", iIndex);

			if (!this.dialog) {
				this.dialog = sap.ui.xmlfragment("pd.fr.view.internationalValues", this);
				this.getView().addDependent(this.dialog);
			}
			this.dialog.open();
		},
		onIntrlPress: function(oEvent) {
			var ojsonModel = this.getOwnerComponent().getModel("json");

			//	var tRecord = oEvent.getParameter("ListItem").getObject();
			var oTable = this.byId("tDpTable");
			//var sRow = oTable.getSelected;
			var tabModel = ojsonModel.getData().tabModel;
			var okey1 = sap.ui.getCore().byId("icmb1").getSelectedKey();
			var okey2 = sap.ui.getCore().byId("icmb2").getSelectedKey();
			var okey3 = sap.ui.getCore().byId("icmb3").getSelectedKey();
			var newdata = {};
			newdata.CartageAmount = okey1;
			newdata.Lgobe = okey2;
			newdata.Ebeln = okey3;
			var iIndex = ojsonModel.getProperty("/index");

			tabModel.splice(iIndex, 1, newdata);
			ojsonModel.setProperty("/tabModel", tabModel);
			ojsonModel.refresh(true);
			this.byId("secLbl").setVisible(true);
			this.byId("dpLbl").setVisible(true);
			this.byId("opLbl").setVisible(true);
			this.dialog.close();

		},

		onCancel: function() {
			this.dialog.close();
		},

		addNewCell: function(oEvent) {
			var oTable = this.byId("idProductsTable");
			var oJSONModel = this.getView().getModel("json");
			var Obj = this.getView().getModel("json").getData().tabModel;
			var oNewObject = {
				Matnr: "",
				Menge: "",
				Lgobe: ""
			};
			Obj.push(oNewObject);
			oJSONModel.setProperty("/data", Obj);
			oJSONModel.refresh(true);
		},

		onDeleteFuel: function(oEvent) {
			var that = this;
			var ojson = that.getOwnerComponent().getModel("json");
			if (ojson.getProperty("/oViewModel").fuelRcpt) {
				that.oTable = this.byId("idProductsTable");
			} else if (ojson.getProperty("/oViewModel").tankDips) {
				that.oTable = this.byId("idProductsTable2");
			} else {
				that.oTable = this.byId("idProductsTable3");
			}
			//	that.oTable.setMode(sap.m.ListMode.SingleSelectMaster);
			var Model = that.getModel("json").getData().tabModel;
			//	var selected = oTable.getSelectedItem();
			//	var Indx =oTable.indexOfItem(selected);
			if (Model.length !== 1) {

				var sItem = oEvent.getParameter("listItem").getBindingContext("json").getObject();
				//	oEvent.getSource().removeItem(oEvent.getParameter("listItem"));
				var oJSONModel = this.getView().getModel("json");
				var delObj = oJSONModel.getData().data;
				delObj.pop(sItem);
				//	that.oTable.attachDelete();

				oJSONModel.refresh(true);

			} else {
				MessageToast.show("Single entry should not be removed");
				that.oTable.attachDelete();
			}
		},
		/*	oHeader.ReceiptType = that.byId("selComb").getSelectedKey();
		oHeader.Managed = that.byId("rbMngd").getSelected();
		oHeader.NonManaged = that.byId("rbNMngd").getSelected();
		oHeader.Rigsupplier = that.byId("rbRtoS").getSelected();
		oHeader.transfertorig = that.byId("rbTtoR").getSelected();
		oHeader.Rig = that.byId("RgId").getSelectedKey();
		oHeader.RigType = that.byId("RgTypId").getSelectedKey();
		oHeader.Loc = that.byId("LcId").getSelectedKey();
		oHeader.Vend = that.byId("VnId").getSelectedKey();
		oDetail.StorageLoc = that.byId("cmb1").getSelectedKey();
		oDetail.Matrl = that.byId("cmb2").getSelectedKey();
		oDetail.Qt1  = that.byId("Qt1").getValue();
		oDetail.ScStg  = that.byId("ScStg").getValue();
		oDetail.Optyp  = that.byId("Optyp").getValue();
		oDetail.Depth  = that.byId("Dpth").getValue();  
		var updatedFormat;
			if (expDate === "") {
				updatedFormat = null;
			} else {
				var exportDate = new Date(expDate);
				updatedFormat = [exportDate.getFullYear(), exportDate.getMonth() + 1, exportDate.getDate()].join("-");
				updatedFormat = updatedFormat + "T00:00:00";
			}*/
		onCreateFr: function(oEvent) {
			var that = this;
			var proceed = true;
			var RigType = that.byId("RgTypId").getSelectedKey();
			if (RigType === "") {
				that.byId("RgTypId").setValueState("Error");
				that.byId("RgTypId").setValueStateText("Select valid item from list.");
				proceed = false;
			} else {
				that.byId("RgTypId").setValueState("None");
			}
			var Loc = that.byId("LcId").getSelectedKey();
			if (Loc === "") {
				that.byId("LcId").setValueState("Error");
				that.byId("LcId").setValueStateText("Select valid item from list.");
				proceed = false;
			} else {
				that.byId("LcId").setValueState("None");
			}
			var Vend = that.byId("VnId").getSelectedKey();
			if (Vend === "") {
				that.byId("VnId").setValueState("Error");
				that.byId("VnId").setValueStateText("Select valid item from list.");
				proceed = false;
			} else {
				that.byId("VnId").setValueState("None");
			}
			var delDate = that.byId("delvyDt").getValue();
			if (delDate === "") {
				//	that.byId("delvyDt").setValueState("Error");
				that.byId("delvyDt").setValueStateText("Select valid item from list.");
				proceed = false;
			} else if (delDate !== "") {
				that.byId("delvyDt").setValueState("None");
			}
			
			var oJSONModel = that.getOwnerComponent().getModel("json");
			var tModel = oJSONModel.getData().tabModel;
			//store all the context/contextPath of the table in an array
			var oHeader = {};
			var ItemData = [];
			if (oJSONModel.getProperty("/oViewModel").fuelRcpt) {
				for (var i = 0; i < tModel.length; i++) {
					var Items = {};
					Items.Menge = that.byId("idProductsTable").getItems()[i].mAggregations.cells[2].mProperties.value;
				
					if (Items.Menge === "") {
					that.byId("idProductsTable").getItems()[i].getCells()[3].setValueState("Error");
						that.byId("Qt1").setValueState("Error");
					} else {
						that.byId("Qt1").setValueState("None");
					}
					Items.Matnr = that.byId("idProductsTable").getItems()[i].mAggregations.cells[1].mProperties.selectedKey;
				/*	if (Items.Matnr === "") {
						that.byId("cmb2").setValueState("Error");
					} else {
						that.byId("cmb2").setValueState("None");
					}*/
					Items.Lgort = that.byId("idProductsTable").getItems()[i].mAggregations.cells[0].mProperties.selectedKey;
					ItemData.push(Items);
				}
			} else if (oJSONModel.getProperty("/oViewModel").tankDips) {
				for (var j = 0; j < tModel.length; j++) {
					var Items = {};
					Items.Menge = that.byId("tDpTable").getItems()[j].mAggregations.cells[4].mProperties.value;
					Items.Matnr = that.byId("tDpTable").getItems()[j].mAggregations.cells[1].mProperties.selectedKey;
					ItemData.push(Items);
				}
			} else if (oJSONModel.getProperty("/oViewModel").pumpOut) {
				for (var k = 0; k < tModel.length; k++) {
					var Items = {};
					Items.Menge = that.byId("pmpOutTable").getItems()[k].mAggregations.cells[2].mProperties.value;
					Items.Matnr = that.byId("pmpOutTable").getItems()[k].mAggregations.cells[1].mProperties.selectedKey;
					ItemData.push(Items);
				}
			}

			//	tModel.push(Items);
			oJSONModel.setProperty("/Payload", Items);
			var delDt = that.byId("delvyDt").getValue();
			var updatedFormat;
			if (delDt === "") {
				updatedFormat = null;
			} else {
				var delvyDate = new Date(delDt);
				updatedFormat = [delvyDate.getFullYear(), delvyDate.getMonth() + 1, delvyDate.getDate()].join("-");
				updatedFormat = updatedFormat + "T00:00:00";
			}
			oHeader.Bsart = "ZF";
			oHeader.MoveType = "901";
			oHeader.PstngDate = updatedFormat;
			oHeader.DocDate = updatedFormat;
			oHeader.Lifnr = that.byId("VnId").getSelectedKey();
			oHeader.Ekgrp = "";
			oHeader.ReceiptType = that.byId("selComb").getSelectedKey();
			oHeader.HeaderTxt = "";
			if(that.byId("rbTtoR").getSelected()){
				oHeader.TransferToRig ="X";
			}
			 else if (that.byId("rbRtoS").getSelected()) {
				oHeader.ReturnToSupp = "X";
			}
			if (that.byId("rbMngd").getSelected()) {
				oHeader.ManagedFuel = "X";
			} else if (that.byId("rbNMngd").getSelected()) {
				oHeader.NonManagedFuel = "X";
			}
			// insert item data into header data
			oHeader.ItemsSet = ItemData;
			//get model instance
			var oModelMain = this.getOwnerComponent().getModel();
			//call POST method
			sap.ui.core.BusyIndicator.show(0);
			if (proceed !== true) {
				MessageBox.warning("Please enter all the mandatory fields");
				sap.ui.core.BusyIndicator.hide();
			} else if (proceed === false && that.byId("delvyDt").getValue() === "") {
				MessageBox.warning("Please Enter the Delivery Date");
				sap.ui.core.BusyIndicator.hide();
			} else {
				var that = this;

				oModelMain.create("/HeaderSet", oHeader, {
					success: function(oData, oResponse) {
						// Success
						sap.ui.core.BusyIndicator.hide(5);
						var oMsg = oResponse.headers;
						//	var oEsheet = oResponse.data.Name1;
						var jsonStr = oMsg["sap-message"];
						sap.m.MessageToast.show((JSON.parse(jsonStr).message));
					that.refreshTable();
					that.resetAll();

					},
					error: function(oError) {
						sap.ui.core.BusyIndicator.hide();
						that.resetAll();
						jQuery.sap.require("sap.m.MessageBox");
						sap.m.MessageBox.show((JSON.parse(oError.responseText).error.message.value), {
							icon: sap.m.MessageBox.Icon.Information,
							title: "Message Box"
						});
					}
				});
			}
		},

		/* =========================================================== */
		/* event handlers                                              */
		/* =========================================================== */

		/**
		 * Triggered by the table's 'updateFinished' event: after new table
		 * data is available, this handler method updates the table counter.
		 * This should only happen if the update was successful, which is
		 * why this handler is attached to 'updateFinished' and not to the
		 * table's list binding's 'dataReceived' method.
		 * @param {sap.ui.base.Event} oEvent the update finished event
		 * @public
		 */
		onUpdateFinished: function(oEvent) {
			// update the worklist's object counter after the table update
			var sTitle,
				oTable = oEvent.getSource(),
				iTotalItems = oEvent.getParameter("total");
			// only update the counter if the length is final and
			// the table is not empty
			if (iTotalItems && oTable.getBinding("items").isLengthFinal()) {
				sTitle = this.getResourceBundle().getText("worklistTableTitleCount", [iTotalItems]);
			} else {
				sTitle = this.getResourceBundle().getText("worklistTableTitle");
			}
			this.getModel("worklistView").setProperty("/worklistTableTitle", sTitle);
		},

		/**
		 * Event handler when a table item gets pressed
		 * @param {sap.ui.base.Event} oEvent the table selectionChange event
		 * @public
		 */
		onPress: function(oEvent) {
			// The source is the list item that got pressed
			this._showObject(oEvent.getSource());
		},
		onClear:function(){
			this.refreshTable();
			this.resetAll();
		},

		/**
		 * Event handler when the share in JAM button has been clicked
		 * @public
		 */
		onShareInJamPress: function() {
			var oViewModel = this.getModel("worklistView"),
				oShareDialog = sap.ui.getCore().createComponent({
					name: "sap.collaboration.components.fiori.sharing.dialog",
					settings: {
						object: {
							id: location.href,
							share: oViewModel.getProperty("/shareOnJamTitle")
						}
					}
				});
			oShareDialog.open();
		},

		onSearch: function(oEvent) {
			if (oEvent.getParameters().refreshButtonPressed) {
				// Search field's 'refresh' button has been pressed.
				// This is visible if you select any master list item.
				// In this case no new search is triggered, we only
				// refresh the list binding.
				this.onRefresh();
			} else {
				var oTableSearchState = [];
				var sQuery = oEvent.getParameter("query");

				if (sQuery && sQuery.length > 0) {
					oTableSearchState = [new Filter("Maktx", FilterOperator.Contains, sQuery)];
				}
				this._applySearch(oTableSearchState);
			}

		},

		/**
		 * Event handler for refresh event. Keeps filter, sort
		 * and group settings and refreshes the list binding.
		 * @public
		 */
		onRefresh: function() {
			this._oTable.getBinding("items").refresh();
		},

		/* =========================================================== */
		/* internal methods                                            */
		/* =========================================================== */

		/**
		 * Shows the selected item on the object page
		 * On phones a additional history entry is created
		 * @param {sap.m.ObjectListItem} oItem selected Item
		 * @private
		 */
		_showObject: function(oItem) {
			this.getRouter().navTo("object", {
				objectId: oItem.getBindingContext().getProperty("Matnr")
			});
		},

		/**
		 * Internal helper method to apply both filter and search state together on the list binding
		 * @param {object} oTableSearchState an array of filters for the search
		 * @private
		 */
		_applySearch: function(oTableSearchState) {
			var oViewModel = this.getModel("worklistView");
			this._oTable.getBinding("items").filter(oTableSearchState, "Application");
			// changes the noDataText of the list in case there are no filter results
			if (oTableSearchState.length !== 0) {
				oViewModel.setProperty("/tableNoDataText", this.getResourceBundle().getText("worklistNoDataWithSearchText"));
			}
		}

	});
});