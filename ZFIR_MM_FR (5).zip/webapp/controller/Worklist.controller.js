sap.ui.define([
	"pd/fr/controller/BaseController",
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/routing/History",
	"pd/fr/model/formatter",
	"sap/ui/model/Filter",
	"sap/m/MessageToast",
	"sap/m/MessageBox",
	"sap/ui/model/FilterOperator"

], function(BaseController, JSONModel, History, formatter, Filter, MessageToast, MessageBox, FilterOperator) {
	"use strict";

	return BaseController.extend("pd.fr.controller.Worklist", {

		formatter: formatter,

		onBeforeRendering: function() {
			var oJSONModel = this.getOwnerComponent().getModel("json");
			var showingpage = oJSONModel.getData().oViewModel;
			this.byId("HboxId").setVisible(false);
			//	this.byId("VboxId").setVisible(false);
			this.byId("idProductsTable").setVisible(false);
		},
		/*	onAfterRendering: function() {
				var oJSONModel = this.getView().getModel("json");
				var payloadDatas = {
					"FuelData": [],
					"TankDipsData": [],
					"PumpOutData": []
				};
				oJSONModel.setProperty("/payloadDatas", payloadDatas);
				oJSONModel.setSizeLimit(99999);
			},*/
		/*	handleLoadItems: function(oControlEvent) {
				oControlEvent.getSource().getBinding("items").resume();
			},
			handleChange: function(oEvent) {
			},*/
		handleSelectionChange: function(oEvent) {
			var oJSONModel = this.getOwnerComponent().getModel("json");
			this.byId("cmb2").removeAllItems();
			//oJSONModel.setProperty("/MatrlModel", "");
			//	oJSONModel.setProperty("/StorModel", "");

			oJSONModel.refresh(true);

			if (oEvent.getSource().getSelectedItem() !== null) {
				var key = oEvent.getSource().getSelectedItem().getProperty("key");
				this.byId("MsgStrip").setVisible(false);
			} else {
				key = "";
			}
			var that = this;
			that.resetAll();
			that.refreshTable();
			if (key === "F") {
				var fFlag = true;

				this.byId("page").setTitle("Fuel Receipt");
				this.byId("pnlId").setVisible(true);
				this.byId("delDtBox").setVisible(true);
				this.byId("HboxId").setVisible(true);
				this.byId("RgTypId").setSelectedKey();
				this.byId("LcId").setSelectedKey();
				var today = new Date();
				this.byId("delvyDt").setDateValue(today);
				this.byId("vndrBox").setVisible(true);
				this.byId("MvBox").setVisible(false);
				this.byId("idProductsTable").setVisible(true);
				this.populateRigStorage();
			
				var oJSONModel = that.getOwnerComponent().getModel("json");
				oJSONModel.setProperty("/tabI", undefined);
				//	oJSONModel.setProperty("/MatrlModel0","");
				//	this.byId("cmb2").destroyItems();
				//	this.byId("idProductsTable").getCells()[2].destroyItems();
				oJSONModel.setProperty("/sRig", "");
				oJSONModel.setProperty("/sLoc", "");
				sap.ui.core.BusyIndicator.show(0);
				var oView2 = {
					fuelRcpt: true,
					tankDips: false,
					pumpOut: false,
					lubricants: false
				};
				oEvent.getSource().setSelectedKey(key);
				oJSONModel.setProperty("/oViewModel", oView2);
					this.populateMaterial();
				this.MaterialInitialLoad();
				oJSONModel.refresh(true);
				sap.ui.core.BusyIndicator.hide();
				var flagMsg = false;
			} else {
				if (key === "T") {
					/*	var oFlag = {
						fFlag: false,
						tFlag: true,
						pFlag: false,
						lFlag: false
					};
					oEvent.getSource().setSelectedKey(key);
					oJSONModel.setProperty("/oFlagModel", oFlag);*/
					/*var tFlag = true;
					if(that.byId("tDpTable").getItems()[0].getCells()[5].getValue() === "" ){
						tFlag = false;
						MessageBox.warning("Unsaved data will be lost");
					}*/
					this.byId("page").setTitle("Tank Dips");
					this.byId("delDtBox").setVisible(false);
					this.byId("HboxId").setVisible(true);
					this.byId("pnlId").setVisible(false);
					this.byId("RgTypId").setSelectedKey();
					this.byId("LcId").setSelectedKey();
					this.byId("vndrBox").setVisible(true);
					this.byId("MvBox").setVisible(false);
					this.populateRigStorage();
				
					var today = new Date();
					this.byId("toDt").setDateValue(today);
					var oJSONModel = that.getView().getModel("json");
					oJSONModel.setProperty("/tabI", undefined);
					oJSONModel.setProperty("/sRig", "");
					oJSONModel.setProperty("/sLoc", "");
					sap.ui.core.BusyIndicator.show(0);
					var oView3 = {
						fuelRcpt: false,
						tankDips: true,
						pumpOut: false,
						lubricants: false
					};
					oEvent.getSource().setSelectedKey(key);
					oJSONModel.setProperty("/oViewModel", oView3);
					this.populateMaterial();
					this.MaterialInitialLoad();
					oJSONModel.refresh(true);
					sap.ui.core.BusyIndicator.hide();
				}
				if (key == "L") {
					this.byId("page").setTitle("Lubricants");
					this.byId("pnlId").setVisible(false);
					this.byId("HboxId").setVisible(true);
					this.byId("delDtBox").setVisible(true);
					this.byId("RgTypId").setSelectedKey();
					this.byId("LcId").setSelectedKey();
					this.byId("vndrBox").setVisible(true);
					this.byId("MvBox").setVisible(false);
					this.populateRigStorage();
				
					var today = new Date();
					this.byId("delvyDt").setDateValue(today);
					//this.byId("idProductsTable").setVisible(true);
					var oJSONModel = this.getOwnerComponent().getModel("json");
					oJSONModel.setProperty("/tabI", undefined);
					sap.ui.core.BusyIndicator.show(0);
					var oView2 = {
						fuelRcpt: false,
						tankDips: false,
						pumpOut: false,
						lubricants: true
					};
					oEvent.getSource().setSelectedKey(key);
					oJSONModel.setProperty("/oViewModel", oView2);
					this.populateMaterial();
					this.MaterialInitialLoad();
					oJSONModel.setProperty("/sRig", "");
					oJSONModel.setProperty("/sLoc", "");
					oJSONModel.setProperty("/tabI", undefined);
					//	oJSONModel.setProperty("/MatrlModel", "");
					oJSONModel.refresh();
					sap.ui.core.BusyIndicator.hide();
					var flagMsg = false;
				}
				if (key == "P") {
					that.byId("delDtBox").setVisible(true);
					that.byId("pnlId").setVisible(false);
					that.byId("page").setTitle("Pump Out");
					that.byId("HboxId").setVisible(true);
					that.byId("RgTypId").setSelectedKey();
					that.byId("LcId").setSelectedKey();
					if (that.byId("rbTtoR").getSelected()) {
						that.byId("vndrBox").setVisible(false);
						that.byId("MvBox").setVisible(true);
					}
					var today = new Date();
					this.byId("delvyDt").setDateValue(today);
					//		that.byId("vndrBox").setVisible(true);
					//	that.byId("rbRtoS").setSelected(true);
					this.populateRigStorage();
					this.populateMaterial();
					this.MaterialInitialLoad();

					var oJSONModel = that.getView().getModel("json");
					oJSONModel.setProperty("/tabI", undefined);
					sap.ui.core.BusyIndicator.show(0);
					var oView2 = {
						fuelRcpt: false,
						tankDips: false,
						pumpOut: true,
						lubricants: false
					};
					oEvent.getSource().setSelectedKey(key);
					oJSONModel.setProperty("/oViewModel", oView2);
					oJSONModel.setProperty("/sRig", "");
					oJSONModel.refresh();
					sap.ui.core.BusyIndicator.hide();
				}
			}
		},
		//on transfer to rig radiobtn selection
		onTrnsfrtoRig: function(oevent) {
			var that = this;
			if (oevent.getSource().getSelected()) {
				that.byId("vndrBox").setVisible(false);
				that.byId("MvBox").setVisible(true);
				that.byId("wbsId").setVisible(true);
			}

		},
		//on return to supplier radio btn selection
		onRtntoSupp: function(oEvent) {
			var that = this;

			if (oEvent.getSource().getSelected()) {
				that.byId("vndrBox").setVisible(true);
				that.byId("MvBox").setVisible(false);
				that.byId("wbsId").setVisible(false);
			}
		},
		NonMngdSelected: function(oEvent) {
			var that = this;
			if (oEvent.getSource().getSelected()) {
				that.populateMaterial();
			}
		},
		/*	MngdSelected:function(){
			
			},*/
		// to refresh the table items
		refreshTable: function() {
			var model = this.getOwnerComponent().getModel("json");
			var that = this;
			if (model.getProperty("/oViewModel").fuelRcpt) {
				that._oTable = that.byId('idProductsTable');
				for (var i = 0; i < that._oTable.getItems().length; i++) {
					that._oTable.getItems()[i].getCells()[0].setValue("");
					that._oTable.getItems()[i].getCells()[1].setValue("");

					that._oTable.getItems()[i].getCells()[2].setValue("");
					//that._oTable.getItems()[i].getCells()[2].unbindItems();
					//that.byId("cmb2").unbindItems();
					that._oTable.getItems()[i].getCells()[3].setValue("");
					that._oTable.getItems()[i].getCells()[4].setText("");
				}
			} else if (model.getProperty("/oViewModel").pumpOut) {
				that._oTable = that.byId('pmpOutTable');
				for (var i = 0; i < that._oTable.getItems().length; i++) {
					that._oTable.getItems()[i].getCells()[0].setValue("");
					that._oTable.getItems()[i].getCells()[1].setValue("");
					that._oTable.getItems()[i].getCells()[2].setValue("");
					that._oTable.getItems()[i].getCells()[3].setValue("");
					that._oTable.getItems()[i].getCells()[4].setValue("");
					that._oTable.getItems()[i].getCells()[5].setValue("");

				}
			} else if (model.getProperty("/oViewModel").lubricants) {
				that._oTable = that.byId('idLubTable');
				for (var i = 0; i < that._oTable.getItems().length; i++) {
					that._oTable.getItems()[i].getCells()[0].setValue("");
					that._oTable.getItems()[i].getCells()[1].setValue("");
					that._oTable.getItems()[i].getCells()[2].setValue("");
					that._oTable.getItems()[i].getCells()[3].setValue("");
					that._oTable.getItems()[i].getCells()[4].setValue("");

				}
			}

			if (model.getProperty("/oViewModel").tankDips) {
				that._tnkTable = that.byId('tDpTable');
				for (var j = 0; j < that._tnkTable.getItems().length; j++) {
					that._tnkTable.getItems()[j].getCells()[0].setValue("");
					that._tnkTable.getItems()[j].getCells()[1].setValue("");
					that._tnkTable.getItems()[j].getCells()[2].setValue("");
					that._tnkTable.getItems()[j].getCells()[3].setValue("");
					that._tnkTable.getItems()[j].getCells()[4].setValue("");
					that._tnkTable.getItems()[j].getCells()[5].setValue("");
					that._tnkTable.getItems()[j].getCells()[6].setValue("");
				}
			}
		},
		refreshPumpout: function() {
			that.byId("MvId").setVisible(false);
		},
		// to reset all the input values
		resetAll: function() {
			var that = this;
			that.byId("RgTypId").setSelectedKey("");
			that.byId("RgTypId").setValueState("None");
			that.byId("LcId").setSelectedKey("");
			that.byId("LcId").setValueState("None");
			that.byId("VnId").setSelectedKey("");
			that.byId("tdstr").setSelectedKey("");
			that.byId("tdmat").setSelectedKey("");
			that.byId("VnId").setValueState("None");
			that.byId("cmb1").setSelectedKey("");
			that.byId("MvId").setSelectedKey("");
			that.byId("priceCol").setVisible(false);
			that.byId("cmb1").setValueState("None");
			that.byId("cmb2").setSelectedKey("");
			that.byId("cmb2").setValueState("None");
			that.byId("Qt1").setValue("");
			that.byId("Qt1").setValueState("None");
			that.byId("delvyDt").setValueState("None");
			that.byId("delvyDt").setValue("");
			that.tableBinding();
			that.getOwnerComponent().getModel("json").refresh();
			//	that.byId("idProductsTable").unbindItems();
			//	that.byId("tDpTable").unbindItems();
			//	that.byId("pmpOutTable").unbindItems(); 
			//	that.byId("ScStg").setValue("");
			//	that.byId("Optyp").setValue("");
			//   that.byId("Dpth").setValue("");
		},
		onInit: function() {

			this._onPatternMatched();
			/*	var oModel = this.getOwnerComponent().getModel();
				var oJSONModel = this.getOwnerComponent().getModel("json");
				oModel.read("/OperationsSet", {
					success: function(r) {
						oJSONModel.setProperty("/oprtnModel", r.results);
					},
					error: function() {}
				});
				oModel.read("/RecptTypeSet", {
					success: function(r) {
						sap.ui.core.BusyIndicator.hide();
						oJSONModel.setProperty("/ViewDrpdwn", r.results);
					}
				});

				oModel.read("/welldiameterSet", {
					success: function(r) {
						oJSONModel.setProperty("/diaModel", r.results);
					},
					error: function() {}
				});

				oModel.read("/wellsectionSet", {
					success: function(r) {
						oJSONModel.setProperty("/secModel", r.results);
					},
					error: function() {}
				});

				//To get Vendor data model

				oModel.read("/VendorSet", {
					success: function(r) {
						oJSONModel.setProperty("/VndrModel", r.results);
					},
					error: function(oError) {
						oError;
					}
				});

				// To get the Location model

				sap.ui.core.BusyIndicator.show(0);
				oModel.read("/RigLocSet", {
					success: function(r) {
						sap.ui.core.BusyIndicator.hide();
						oJSONModel.setProperty("/LocModel", r.results);
					},
					error: function() {
						sap.ui.core.BusyIndicator.hide();
						MessageToast.show("Unable to get Location . Please try again.");
					}
				});

				sap.ui.core.BusyIndicator.show(0);
				oModel.read("/chargetoSet", {
					success: function(r) {
						sap.ui.core.BusyIndicator.hide();
						oJSONModel.setProperty("/chargeModel", r.results);
					},
					error: function() {
						sap.ui.core.BusyIndicator.hide();
						MessageToast.show("Unable to get charge to . Please try again.");
					}
				});

				//item level rig storage also get data based on material filter

				var receipttype = this.byId("selComb").getSelectedKey();
				var aFilters = [new Filter("ReceiptType", "EQ", receipttype)];
				oModel.read("/RigStorageLocSet", {
					filters: aFilters,
					success: function(r) {
						sap.ui.core.BusyIndicator.hide();
						oJSONModel.setProperty("/StorModel", r.results);
					},
					error: function() {
						sap.ui.core.BusyIndicator.hide();
						MessageToast.show("Unable to get Storage Location. Please try again.");
					}
				});

				// to get the Rig No

				sap.ui.core.BusyIndicator.show();
				oModel.read("/RigNoSet", {
					success: function(r) {
						oJSONModel.setProperty("/RigModel", r.results);
						sap.ui.core.BusyIndicator.hide();
					},
					error: function() {
						sap.ui.core.BusyIndicator.hide();
						MessageToast.show("Unable to get manufacture Data. Please try again.");
					}
				});
				oModel.read("/RigNoSet", {
					success: function(r) {
						oJSONModel.setProperty("/RigModel", r.results);
						sap.ui.core.BusyIndicator.hide();
					},
					error: function() {
						sap.ui.core.BusyIndicator.hide();
						MessageToast.show("Unable to get manufacture Data. Please try again.");
					}
				});

				//Rig Type Model

				oModel.read("/RigTypesSet", {
					success: function(r) {
						sap.ui.core.BusyIndicator.hide();
						oJSONModel.setProperty("/RigTypeModel", r.results);
					},
					error: function() {
						sap.ui.core.BusyIndicator.hide();
						MessageToast.show("Unable to get the Rig Type. Please try again.");
					}
				});

				oModel.read("/MaterialSet", {
					success: function(r) {
						//	sap.ui.core.BusyIndicator.hide();
						oJSONModel.setProperty("/MatrlModel", r.results);
					},
					error: function() {
						sap.ui.core.BusyIndicator.hide();
					}
				});
				oModel.read("/ItemsSet", {
					success: function(r) {
						sap.ui.core.BusyIndicator.hide();
						oJSONModel.setProperty("/tabModel", r.results);
					}
				});

				this.populateMaterial();

				this.oBusy = new sap.m.BusyDialog();*/
		},

		tableBinding: function() {
			var oJSONModel = this.getOwnerComponent().getModel("json");
			var oModel = this.getOwnerComponent().getModel();
			sap.ui.core.BusyIndicator.show(0);
			oModel.read("/ItemsSet", {
				success: function(r) {
					sap.ui.core.BusyIndicator.hide();
					oJSONModel.setProperty("/tabModel", r.results);
				}
			});
		},

		validateComboBox: function(oEvt) {
			var comboBox = oEvt.getSource();
			if (comboBox.getSelectedItemId() === "") {
				comboBox.setValueState("Error");
				comboBox.setValueStateText("Select valid item from list.");
			} else {
				comboBox.setValueState("None");
			}
		},
		validateInput: function(oEvent) {
			if (oEvent.getParameters().value !== "" && oEvent.getParameters().value !== "0" && oEvent.getParameters().value !== "0.000") {
				var val = oEvent.getSource().setValueState("None");
			} else {
				oEvent.getSource().setValueState("Error");
			}

		},
		_onPatternMatched: function() {
			this.populateVendor();
			this.populateLocation();
			this.populateRigStorage();
			this.populateRig();
			this.populateRigType();
			this.populateMaterial();
			this.MaterialInitialLoad();
			this.populateDepth();
			this.populateSection();
			this.populateOperationType();
			this.populateCharge();
			this.tableBinding();
			var oModel = this.getOwnerComponent().getModel();
			var oJSONModel = this.getOwnerComponent().getModel("json");
			sap.ui.core.BusyIndicator.show(0);
			oModel.read("/RecptTypeSet", {
				success: function(r) {
					sap.ui.core.BusyIndicator.hide();
					oJSONModel.setProperty("/ViewDrpdwn", r.results);
				}
			});
		},
		//diameter of the tnkDips international Values
		populateDepth: function() {
			var oModel = this.getOwnerComponent().getModel();
			var oJSONModel = this.getOwnerComponent().getModel("json");
			oModel.read("/welldiameterSet", {
				success: function(r) {
					oJSONModel.setProperty("/diaModel", r.results);
				},
				error: function() {}
			});
		},
		///operation type data
		populateOperationType: function() {
			var oModel = this.getOwnerComponent().getModel();
			var oJSONModel = this.getOwnerComponent().getModel("json");
			oModel.read("/OperationsSet", {
				success: function(r) {
					oJSONModel.setProperty("/oprtnModel", r.results);
				},
				error: function() {}
			});
		},
		//section data model
		populateSection: function() {
			var oModel = this.getOwnerComponent().getModel();
			var oJSONModel = this.getOwnerComponent().getModel("json");
			oModel.read("/wellsectionSet", {
				success: function(r) {
					oJSONModel.setProperty("/secModel", r.results);
				},
				error: function() {}
			});
		},
		//To get Vendor data model
		populateVendor: function() {
			var oModel = this.getOwnerComponent().getModel();
			var oJSONModel = this.getOwnerComponent().getModel("json");
			oModel.read("/VendorSet", {
				success: function(r) {
					oJSONModel.setProperty("/VndrModel", r.results);
				},
				error: function(oError) {
					oError;
				}
			});
		},
		// To get the Location model
		populateLocation: function() {
			this._oTable = this.getView("table");
			var oModel = this.getOwnerComponent().getModel();
			var oJSONModel = this.getOwnerComponent().getModel("json");
			sap.ui.core.BusyIndicator.show(0);
			oModel.read("/RigLocSet", {
				success: function(r) {
					sap.ui.core.BusyIndicator.hide();
					oJSONModel.setProperty("/LocModel", r.results);
				},
				error: function() {
					sap.ui.core.BusyIndicator.hide();
					MessageToast.show("Unable to get Location . Please try again.");
				}
			});
		},
		// to populate charge to 
		populateCharge: function() {
			var oModel = this.getOwnerComponent().getModel();
			var oJSONModel = this.getOwnerComponent().getModel("json");
			sap.ui.core.BusyIndicator.show(0);
			oModel.read("/chargetoSet", {
				success: function(r) {
					sap.ui.core.BusyIndicator.hide();
					oJSONModel.setProperty("/chargeModel", r.results);
				},
				error: function() {
					sap.ui.core.BusyIndicator.hide();
					MessageToast.show("Unable to get charge to . Please try again.");
				}
			});
		},
		//item level rig storage also get data based on material filter
		populateRigStorage: function() {
			var oModel = this.getOwnerComponent().getModel();
			var oJSONModel = this.getOwnerComponent().getModel("json");
			sap.ui.core.BusyIndicator.show(0);
			/*	if (oJSONModel.getProperty("/sMatrltoFltrLoc") !== undefined) {
					var oFltr = oJSONModel.getProperty("/sMatrltoFltrLoc");

					var aFilters = [new Filter("Matnr", "EQ", oFltr)];
				} else if (this.byId("selComb").getSelectedKey() !== "") {
					var receipttype = this.byId("selComb").getSelectedKey();
					var aFilters = [new Filter("ReceiptType", "EQ", receipttype)];
				} else {
					var aFilters = "";
				}*/
			var receipttype = this.byId("selComb").getSelectedKey();
			var aFilters = [new Filter("ReceiptType", "EQ", receipttype)];
			oModel.read("/RigStorageLocSet", {
				filters: aFilters,
				success: function(r) {
					sap.ui.core.BusyIndicator.hide();
					oJSONModel.setProperty("/StorModel", r.results);
				},
				error: function() {
					sap.ui.core.BusyIndicator.hide();
					MessageToast.show("Unable to get Storage Location. Please try again.");
				}
			});
		},

		// to get the Rig No
		populateRig: function() {
			var oModel = this.getOwnerComponent().getModel();
			var oJSONModel = this.getOwnerComponent().getModel("json");
			sap.ui.core.BusyIndicator.show();
			oModel.read("/RigNoSet", {
				success: function(r) {
					oJSONModel.setProperty("/RigModel", r.results);
					sap.ui.core.BusyIndicator.hide();
				},
				error: function() {
					sap.ui.core.BusyIndicator.hide();
					MessageToast.show("Unable to get manufacture Data. Please try again.");
				}
			});
		},
		//Rig Type Model
		populateRigType: function() {
			this._oTable = this.getView("table");
			var oModel = this.getOwnerComponent().getModel();
			var oJSONModel = this.getOwnerComponent().getModel("json");
			sap.ui.core.BusyIndicator.show(0);
			oModel.read("/RigTypesSet", {
				success: function(r) {
					sap.ui.core.BusyIndicator.hide();
					oJSONModel.setProperty("/RigTypeModel", r.results);
				},
				error: function() {
					sap.ui.core.BusyIndicator.hide();
					MessageToast.show("Unable to get the Rig Type. Please try again.");
				}
			});
		},
		//To load all the materials initially
		MaterialInitialLoad: function() {
			var oModel = this.getOwnerComponent().getModel();
			var oJSONModel = this.getOwnerComponent().getModel("json");
			var that = this;
			var oFilter = [];
			if (oJSONModel.getProperty("/oViewModel").tankDips || oJSONModel.getProperty("/oViewModel").fuelRcpt || oJSONModel.getProperty(
					"/oViewModel").pumpOut || oJSONModel.getProperty("/oViewModel").lubricants) {

				var Recpt = that.byId("selComb").getSelectedKey();
				var aFilters = [new Filter("Rigtype", "EQ", ""), new Filter("ReceiptType", "EQ", Recpt),
					new Filter("Lgort", "EQ", ""), new Filter("NonManagedFuel", "EQ", "")
				];
			}
			if (oJSONModel.getProperty("/oViewModel").tankDips) {
				var fRig = oJSONModel.getProperty("/sRig");
				Recpt = that.byId("selComb").getSelectedKey();
				var aFilters = [new Filter("Rigtype", "EQ", fRig), new Filter("ReceiptType", "EQ", Recpt),
					new Filter("Lgort", "EQ", ""), new Filter("NonManagedFuel", "EQ", "")
				];
			} else {
				if (oJSONModel.getProperty("/sRig") !== undefined) {
					fRig = oJSONModel.getProperty("/sRig");
					Recpt = that.byId("selComb").getSelectedKey();
					var aFilters = [new Filter("Rigtype", "EQ", fRig), new Filter("ReceiptType", "EQ", Recpt),
						new Filter("Lgort", "EQ", ""), new Filter("NonManagedFuel", "EQ", "")
					];
				}
				if (oJSONModel.getProperty("/sRig") !== undefined && that.byId("rbNMngd").getSelected() === true) {
					fRig = oJSONModel.getProperty("/sRig");
					Recpt = that.byId("selComb").getSelectedKey();
					aFilters = [new Filter("Rigtype", "EQ", fRig), new Filter("ReceiptType", "EQ", Recpt),
						new Filter("Lgort", "EQ", ""), new Filter("NonManagedFuel", "EQ", "X")
					];
				}

				if (oJSONModel.getProperty("/sRig") !== undefined && oJSONModel.getProperty("/sStorLoc") !== undefined && that.byId("rbNMngd").getSelected() ===
					true) {
					fRig = oJSONModel.getProperty("/sRig");
					Recpt = that.byId("selComb").getSelectedKey();
					aFilters = [new Filter("Rigtype", "EQ", fRig), new Filter("ReceiptType", "EQ", Recpt),
						new Filter("Lgort", "EQ", ""), new Filter("NonManagedFuel", "EQ", "X")
					];
				}
			}
			oModel.read("/MaterialSet", {
				filters: aFilters,
				success: function(r) {

					//	sap.ui.core.BusyIndicator.hide();
					oJSONModel.setProperty("/iMtrlModel", r.results);
				},
				error: function() {
					sap.ui.core.BusyIndicator.hide();
				}
			});
		},
		/// to get the materials based on rig, location
		populateMaterial: function() {
			var that = this;
			var oModel = this.getOwnerComponent().getModel();
			var oJSONModel = this.getOwnerComponent().getModel("json");

			var aFilter = [];
			if (oJSONModel.getProperty("/oViewModel").tankDips) {
				var fRig = oJSONModel.getProperty("/sRig");
				var Recpt = that.byId("selComb").getSelectedKey();
				var aFilters = [new Filter("Rigtype", "EQ", fRig), new Filter("ReceiptType", "EQ", Recpt),
					new Filter("Lgort", "EQ", oJSONModel.getProperty("/sStorLoc")), new Filter("NonManagedFuel", "EQ", "")
				];
			} else {
				if (oJSONModel.getProperty("/sRig") !== undefined) {
					var fRig = oJSONModel.getProperty("/sRig");
					var Recpt = that.byId("selComb").getSelectedKey();
					var aFilters = [new Filter("Rigtype", "EQ", fRig), new Filter("ReceiptType", "EQ", Recpt),
						new Filter("Lgort", "EQ", ""), new Filter("NonManagedFuel", "EQ", "")
					];
				}
				if (oJSONModel.getProperty("/sRig") !== undefined && that.byId("rbNMngd").getSelected() === true) {
					var fRig = oJSONModel.getProperty("/sRig");
					var Recpt = that.byId("selComb").getSelectedKey();
					var aFilters = [new Filter("Rigtype", "EQ", fRig), new Filter("ReceiptType", "EQ", Recpt),
						new Filter("Lgort", "EQ", ""), new Filter("NonManagedFuel", "EQ", "X")
					];
				}
				if (oJSONModel.getProperty("/sStorLoc") !== undefined) {
					var fRig = oJSONModel.getProperty("/sRig");
					var Recpt = that.byId("selComb").getSelectedKey();
					var aFilters = [new Filter("Rigtype", "EQ", ""), new Filter("ReceiptType", "EQ", Recpt),
						new Filter("Lgort", "EQ", oJSONModel.getProperty("/sStorLoc")), new Filter("NonManagedFuel", "EQ", "")
					];
				}
				if (oJSONModel.getProperty("/sStorLoc") !== undefined && oJSONModel.getProperty("/sStorLoc") !== undefined) {
					var fRig = oJSONModel.getProperty("/sRig");
					var Recpt = that.byId("selComb").getSelectedKey();
					var aFilters = [new Filter("Rigtype", "EQ", fRig), new Filter("ReceiptType", "EQ", Recpt),
						new Filter("Lgort", "EQ", oJSONModel.getProperty("/sStorLoc")), new Filter("NonManagedFuel", "EQ", "")
					];
				}
				if (oJSONModel.getProperty("/sRig") !== undefined && oJSONModel.getProperty("/sStorLoc") !== undefined && that.byId("rbNMngd").getSelected() ===
					true) {
					fRig = oJSONModel.getProperty("/sRig");
					Recpt = that.byId("selComb").getSelectedKey();
					aFilters = [new Filter("Rigtype", "EQ", fRig), new Filter("ReceiptType", "EQ", Recpt),
						new Filter("Lgort", "EQ", oJSONModel.getProperty("/sStorLoc")), new Filter("NonManagedFuel", "EQ", "X")
					];
				}
			}
			var I = oJSONModel.getProperty("/tabI");
			//	var o ="/ " + I;
			/*if(I === undefined){
			oModel.read("/MaterialSet", {
					filters: aFilters,
					success: function(r) {
						//	sap.ui.core.BusyIndicator.hide();
						oJSONModel.setProperty("/MatrlModel", r.results);
					},
					error: function() {
						sap.ui.core.BusyIndicator.hide();
					}
				});
			}*/

			oModel.read("/MaterialSet", {
				filters: aFilters,
				success: function(r) {
					//	sap.ui.core.BusyIndicator.hide();
					oJSONModel.setProperty("/MatrlModel" + I, r.results);
				},
				error: function() {
					sap.ui.core.BusyIndicator.hide();
				}
			});

		},
		// On material change if cartage show price $ input entry
		onMaterialChange: function(oEvent) {
			var that = this;
			var x = oEvent.getSource().getBindingContext("json").getPath().replace(/tabModel\//g, '');
			var Index = x.replace(/\//g, '');
			var oJSONModel = this.getOwnerComponent().getModel("json");
			var oVal = oEvent.getSource().getSelectedItem().getProperty("key");
			var oI = oJSONModel.getProperty("/tabI");
			var path = "/MatrlModel" + oI;
			//	var oo =	oJSONModel.getProperty(path);
			var matrlIndx = oEvent.getSource().getSelectedItem().getBindingContext("json").getPath().slice(-1);

			/*		var filterdMtrl = oJSONModel.getData().MatrlModel;
					var mtrl = oJSONModel.getData().iMtrlModel;
					var tabModel = oJSONModel.getData().tabModel;
					var mflag = false;
					var sVal = "";
				
				for (var i = 0; i < filterdMtrl.length; i++) {
						if(mflag=== false){
						if(oVal === filterdMtrl[i].Matnr){
							mflag= true;
						//	oJSONModel.setProperty("/NoMtrl",!mflag);
					}
						}
						
				
				}
					if(!mflag){
					MessageBox.error("Selected material is not available in the storage location");
					var path =oEvent.getSource().getBindingContext("json").getPath().replace(/tabModel\//g, '');
					var indx =path.replace(/\//g, '');
					that.getOwnerComponent().getModel("json").setProperty("/continue",true);
						oJSONModel.getData().tabModel[Index].Lgobe = "X";
							that.byId("idProductsTable").bindCells(tabModel);
					}
					else{
							oJSONModel.getData().tabModel[Index].Lgobe = "";
							that.byId("idProductsTable").bindCells(tabModel);
					}*/
			//	that.byId("cmb2").setValueState("Error");
			//	that.byId("idProductsTable").getItems()[indx].getCells()[2].setText("");
			//	break;
			//	oEvent.getSource().getSelectedItem()

			//	var y = oEvent.getParameter("selectedItem").oBindingContexts.json.sPath.replace(/MatrlModel\//g, '');
			//	var matpath = oEvent.getSource().getSelectedItem().getBindingContext("json").getPath()
			//	var matrlIndx = y.replace(/\//g, '');

			this.getOwnerComponent().getModel("json").setProperty("/Indx", Index);
			if (oJSONModel.getProperty("/oViewModel").tankDips) {
				this.byId("tdpTable").getItems()[Index].getCells()[6].setValue(oJSONModel.getProperty(path)[matrlIndx].Meins);
			}
			if (oJSONModel.getProperty("/oViewModel").pumpOut && that.byId("rbRtoS").getSelected()) {
				this.byId("pmpOutTable").getItems()[Index].getCells()[5].setValue(oJSONModel.getProperty(path)[matrlIndx].Meins);
			} else if (that.byId("rbTtoR").getSelected() && oJSONModel.getProperty("/oViewModel").pumpOut) {
				this.byId("pmpOutTable").getItems()[Index].getCells()[5].setValue(oJSONModel.getProperty(path)[matrlIndx].Meins);

			}
			if (oJSONModel.getProperty("/oViewModel").lubricants) {
				this.byId("idLubTable").getItems()[Index].getCells()[3].setValue(oJSONModel.getProperty(path)[matrlIndx].Meins);
			}

			this.byId("idProductsTable").getItems()[Index].getCells()[4].setText(oJSONModel.getProperty(path)[matrlIndx].Meins);
			//var cartg = oEvent.getSource().getSelectedItem().getProperty("additionalText");
			var cartg = oJSONModel.getProperty(path)[matrlIndx].Cartage;
			if (cartg === "X") {
				if (!this.cDialog) {
					this.cDialog = sap.ui.xmlfragment("pd.fr.view.cartage", this);
				}
				this.cDialog.open();
			}
		},

		//on tdips material change get stock and show in table
		ontDipsMaterlChng: function(oEvent) {
			//	var path = oEvent.getParameter("selectedItem").getBindingContext("json").getPath().replace(/MatrlModel\//g, '');
			var Index = oEvent.getSource().getSelectedItem().getBindingContext("json").getPath().slice(-1);
			var x = oEvent.getSource().getBindingContext("json").getPath().replace(/tabModel\//g, '');
			var tableIndx = x.replace(/\//g, '');

			var path = "/MatrlModel" + tableIndx;
			var oJsonModel = this.getOwnerComponent().getModel("json");
			this.byId("tDpTable").getItems()[tableIndx].getCells()[6].setValue(oJsonModel.getProperty(path)[Index].Meins)

			//	this.byId("tDpTable").getItems()[Index]

			var stockVal = oEvent.getSource().getParent().getCells()[3].setValue(oJsonModel.getProperty(path)[Index].Labst);
			if (stockVal === "0.000") {
				MessageBox.warning("Stock is zero or not applicable");
			}
			//	var stock = oEvent.getSource().getParent().getCells()[4].getValue();
			/*	if (oEvent.getSource().getParent().getCells()[5].getValue() !== "") {
					var curr = oEvent.getSource().getParent().getCells()[5].getValue();
				} 
				if (oEvent.getSource().getParent().getCells()[4].getValue() !== "0.000" && oEvent.getSource().getParent().getCells()[5].getValue()) {
					var Quantity = stock - curr;
					oEvent.getSource().getParent().getCells()[6].setValue(Quantity);
				}*/
			this.getOwnerComponent().getModel("json").refresh();
		},
		onCurrentReadingChange: function(oEvent) {
			var curr = oEvent.getParameters().value;
			var x = oEvent.getSource().getBindingContext("json").getPath().replace(/tabModel\//g, '');
			var Index = x.replace(/\//g, '');
			var stock = this.byId("tDpTable").getItems()[Index].getCells()[3].getValue();
			var Quantity = stock - curr;
			this.byId("tDpTable").getItems()[Index].getCells()[5].setValue(Quantity);
		},
		onNo: function() {

			this.cDialog.close();
		},
		//on cartage dialog Yes press
		onYes: function(oEvent) {
			var cprice = sap.ui.getCore().byId("cPrice").getValue();
			var ojson = this.getOwnerComponent().getModel("json");
			ojson.setProperty("/cPrice", cprice);
			ojson.setProperty("/cartageMtrl", true);
			this.byId("priceCol").setVisible(true);
			if (ojson.getProperty('/oViewModel').lubricants) {
				this.byId("priceCol2").setVisible(true);
			}
			this.byId("crtgId").setVisible(true);
			var i = ojson.getProperty("/tabI");
			this.byId("idProductsTable").getItems()[i].getCells()[2].setValue(cprice);
			this.cDialog.close();
		},
		//to get selected Rig value and load the Materials dynamically
		onSelectedRig: function(oEvent) {
			var ojsonModel = this.getOwnerComponent().getModel("json");
			var oVal = oEvent.getSource().getSelectedItem().getProperty("key");
			ojsonModel.setProperty("/sRig", oVal);
			this.MaterialInitialLoad();
			/*	var z = ojsonModel.getProperty("/tabI");
			var i = ojsonModel.getData().tabModel.length;
			var d = i - 1 ;
			var that= this;
			if(ojsonModel.getProperty("/oViewModel").fuelRcpt){
		that.byId("idProductsTable").getItems()[d].getCells()[2].bindItems("json>/MatrlModel" + z ,
            new sap.ui.core.ListItem({
            	 key:"{json>Matnr}", text:"{json>Maktx}"
            }) );
			}
		
				if(ojsonModel.getProperty("/oViewModel").tankDips){
         	that.byId("tDpTable").getItems()[d].getCells()[2].bindItems("json>/MatrlModel" + z ,
            new sap.ui.core.ListItem({
            	 key:"{json>Matnr}", text:"{json>Maktx}"
            }) );
				}
					if(ojsonModel.getProperty("/oViewModel").pumpOut){
         	that.byId("idProductsTable").getItems()[d].getCells()[3].bindItems("json>/MatrlModel" + z ,
            new sap.ui.core.ListItem({
            	 key:"{json>Matnr}", text:"{json>Maktx}"
            }) );
				
			}*/
		},
		// to get the item level stor location value and load the  materials dynamically
		onStorLocChange: function(oEvent) {
			var ojsonModel = this.getOwnerComponent().getModel("json");
			var oVal = oEvent.getSource().getSelectedItem().getProperty("key");
			ojsonModel.setProperty("/sStorLoc", oVal);
			var i = oEvent.getSource().getParent().getParent().indexOfItem(oEvent.getSource().getParent());
			ojsonModel.setProperty("/tabI", i);
			if (ojsonModel.getProperty("/oViewModel").fuelRcpt) {
				//	this.byId("cmb2").unbindItems();
				oEvent.getSource().getParent().getParent().getItems()[i].getCells()[1].bindItems("json>/MatrlModel" + i,
					new sap.ui.core.ListItem({
						key: "{json>Matnr}",
						text: "{json>Maktx}"
					}));
			}
			if (ojsonModel.getProperty("/oViewModel").tankDips) {
				oEvent.getSource().getParent().getParent().getItems()[i].getCells()[2].bindItems("json>/MatrlModel" + i,
					new sap.ui.core.ListItem({
						key: "{json>Matnr}",
						text: "{json>Maktx}"
					}));
			}
			if (ojsonModel.getProperty("/oViewModel").pumpOut) {
				oEvent.getSource().getParent().getParent().getItems()[i].getCells()[3].bindItems("json>/MatrlModel" + i,
					new sap.ui.core.ListItem({
						key: "{json>Matnr}",
						text: "{json>Maktx}"
					}));
			}
			this.populateMaterial();
		},
		handleValueHelp: function(oEvent) {
			var sInputValue = oEvent.getSource().getValue();
			this.inputId = oEvent.getSource().getId();
			var oJsonModel = this.getOwnerComponent().getModel("json");
			var i = oEvent.getSource().getParent().getParent().indexOfItem(oEvent.getSource().getParent());
			oJsonModel.setProperty("/Index", i);
			var path = oEvent.getSource().getParent().getParent().getItems()[0].getBindingContext("json").getPath();
			// create value help dialog
			if (!this._oMLf4) {
				this._oMLf4 = sap.ui.xmlfragment(
					"pd.fr.view.Matrl_f4",
					this
				);
				this.getView().addDependent(this._oMLf4);
			}
			// create a filter for the binding
			this._oMLf4.getBinding("items").filter([new Filter(
				"Matnr",
				sap.ui.model.FilterOperator.Contains, sInputValue
			)]);
			// open value help dialog filtered by the input value
			this._oMLf4.open(sInputValue);
		},
		_handleValuHelpClose: function(evt) {
			var srvInput;
			var oDialog = evt.getParameter("id");
			var oSelectedItem = evt.getParameter("selectedItem");
			var that = this;
			if (oSelectedItem) {
				if (oDialog === "mat") {
					srvInput = that.byId("cmb2");
					var i = that.getOwnerComponent().getModel("json").getProperty("/Index");
					var path = that.byId("idProductsTable").getItems()[i].getBindingContext("json").getPath();
					that.getOwnerComponent().getModel("json").getData().tabModel[i].Matnr = oSelectedItem.getTitle();
					//	that.getOwnerComponent().getModel("json").refresh(true);

					//	srvInput.setValue(oSelectedItem.getTitle());
				}
			}

			evt.getSource().getBinding("items").filter([]);

		},

		//	 var list = this.getView().byId("myList");
		/*	*/
		/* oEvent.getSource().getParent().getParent().getItems()[i].getCells()[1].setSelected*/
		/*	var loopLength = ojsonModel.oData.MatrlModel.length;
			var table=oEvent.getSource().getParent().getParent();
			var index=table.indexOfItem(oEvent.getSource().getParent());
			for(var i=0;i<loopLength;i++)
			{
				table.getItems()[index].getCells()[1].addItem(
				new sap.ui.core.Item({
				value:ojsonModel.oData.MatrlModel[i].Maktx
				
				}));
			}*/

		// materials based on selected location in Header level
		onSelectedLocation: function(oEvent) {
			var ojsonModel = this.getOwnerComponent().getModel("json");
			var loc = oEvent.getSource().getSelectedItem().getProperty("key");
			ojsonModel.setProperty("/sLoc", loc);
			this.populateMaterial();
		},
		// action on selections of international values
		onSelections: function(oEvent) {
			var iIndex = this.byId("tDpTable").indexOfItem(this.byId("tDpTable").getSelectedItem());
			this.getOwnerComponent().getModel("json").setProperty("/index", iIndex);
			if (!this.dialog) {
				this.dialog = sap.ui.xmlfragment("pd.fr.view.internationalValues", this);
				this.getView().addDependent(this.dialog);
			}
			this.dialog.open();
		},
		// on Yes  press of international values
		onIntrlPress: function(oEvent) {
			var ojsonModel = this.getOwnerComponent().getModel("json");
			//	var tRecord = oEvent.getParameter("ListItem").getObject();
			var oTable = this.byId("tDpTable");
			//var sRow = oTable.getSelected;
			var tabModel = ojsonModel.getData().tabModel;
			var okey1 = sap.ui.getCore().byId("icmb1").getSelectedKey();
			var okey2 = sap.ui.getCore().byId("icmb2").getSelectedKey();
			var okey3 = sap.ui.getCore().byId("icmb3").getSelectedKey();
			var newdata = {};
			newdata.CartageAmount = okey1;
			newdata.Lgobe = okey2;
			newdata.Ebeln = okey3;
			var iIndex = ojsonModel.getProperty("/index");
			tabModel.splice(iIndex, 1, newdata);
			ojsonModel.setProperty("/tabModel", tabModel);
			ojsonModel.refresh(true);
			//	this.byId("secLbl").setVisible(true);
			//	this.byId("dpLbl").setVisible(true);
			//	this.byId("opLbl").setVisible(true);
			this.dialog.close();
		},
		onCancel: function() {
			this.dialog.close();
		},
		// on add Icon press add the new row
		addNewCell: function(oEvent) {
			//	var oTable = this.byId("idProductsTable");
			this.byId("secLbl").setVisible(false);
			this.byId("dpLbl").setVisible(false);
			this.byId("opLbl").setVisible(false);
			var oJSONModel = this.getView().getModel("json");
			var Obj = this.getView().getModel("json").getData().tabModel;
			var oNewObject = {
				Matnr: "",
				Menge: "",
				Lgobe: ""
			};
			Obj.push(oNewObject);
			oJSONModel.setProperty("/data", Obj);
			oJSONModel.refresh(true);
		},
		// on delete icon press delete the selected row
		onDeleteFuel: function(oEvent) {
			var that = this;
			var ojson = that.getOwnerComponent().getModel("json");
			if (ojson.getProperty("/oViewModel").fuelRcpt) {
				that.oTable = that.byId("idProductsTable");
			} else if (ojson.getProperty("/oViewModel").tankDips) {
				that.oTable = that.byId("idProductsTable2");
			} else {
				that.oTable = that.byId("idProductsTable3");
			}
			var Model = that.getModel("json").getData().tabModel;
			//	var selected = oTable.getSelectedItem();
			//	var Indx =oTable.indexOfItem(selected);
			if (Model.length !== 1) {
				var sItem = oEvent.getSource().getParent().getBindingContext("json").getObject();
				//	var sItem = oEvent.getParameter("listItem").getBindingContext("json").getObject();
				//	oEvent.getSource().removeItem(oEvent.getParameter("listItem"));
				var oJSONModel = this.getView().getModel("json");
				var delObj = oJSONModel.getData().data;
				delObj.pop(sItem);
				oJSONModel.refresh(true);
			} else {
				MessageToast.show("Single entry should not be removed");
			}
		},
		// Posting for all  Receipt Types Fuel,TankDips,PumpOut,Lubricants
		onCreateFr: function(oEvent) {
			var that = this;
			var proceed = true;
			var RigType = that.byId("RgTypId").getSelectedKey();
			if (RigType === "") {
				that.byId("RgTypId").setValueState("Error");
				that.byId("RgTypId").setValueStateText("Select valid item from list.");
				proceed = false;
			} else {
				that.byId("RgTypId").setValueState("None");
			}
			var Loc = that.byId("LcId").getSelectedKey();
			if (Loc === "") {
				that.byId("LcId").setValueState("Error");
				that.byId("LcId").setValueStateText("Select valid item from list.");
				proceed = false;
			} else {
				that.byId("LcId").setValueState("None");
			}
			var Vend = that.byId("VnId").getSelectedKey();
			/*if (that.byId("rbTtoR").getSelected() && that.getOwnerComponent().getModel("json").getProperty("/oViewModel").lubricants) {
			}*/
			if (Vend === "") {
				that.byId("VnId").setValueState("Error");
				that.byId("VnId").setValueStateText("Select valid item from list.");
				proceed = false;
			} else {
				that.byId("VnId").setValueState("None");
			}

			var delDate = that.byId("delvyDt").getDateValue();
			var todaysDt = that.byId("toDt").getDateValue();
			var tDipsflag = true;
			if (that.getOwnerComponent().getModel("json").getProperty("/oViewModel").tankDips) {
				tDipsflag = false;
			}
			if (tDipsflag) {
				if (delDate === "") {
					//	that.byId("delvyDt").setValueState("Error");
					that.byId("delvyDt").setValueStateText("Select valid item from list.");
					proceed = false;
				} else if (delDate !== "") {
					that.byId("delvyDt").setValueState("None");
				}
			}
			if (tDipsflag !== true) {

				if (todaysDt === "") {
					//	that.byId("delvyDt").setValueState("Error");
					that.byId("toDt").setValueStateText("Select valid item from list.");
					proceed = false;
				} else if (todaysDt !== "") {
					that.byId("toDt").setValueState("None");
				}
			}

			var oJSONModel = that.getOwnerComponent().getModel("json");
			var tModel = oJSONModel.getData().tabModel;
			var mModel = oJSONModel.getData().iMtrlModel;
			//store all the context/contextPath of the table in an array
			var oHeader = {};
			var ItemData = [];
			//for Fuel Receipt
			if (oJSONModel.getProperty("/oViewModel").fuelRcpt) {
				for (var i = 0; i < tModel.length; i++) {
					var Items = {};
					//	Items.CartageAmount = "0.00";

					if (that.byId("idProductsTable").getItems()[i].getCells()[2].getValue() !== "") {
						Items.CartageAmount = that.byId("idProductsTable").getItems()[i].getCells()[2].getValue();
					}
				/*	if (that.byId("idProductsTable").getItems()[i].getCells()[3].getValue() === "") {
						that.byId("idProductsTable").getItems()[i].getCells()[3].setValueState("Error");
						proceed = false;
					} else if (Items.Menge !== "") {
						that.byId("idProductsTable").getItems()[i].getCells()[2].setValueState("None");
					}*/

					Items.Menge = that.byId("idProductsTable").getItems()[i].getCells()[3].getValue();
					if (Items.Menge === "") {
						that.byId("idProductsTable").getItems()[i].getCells()[3].setValueState("Error");
						proceed = false;
					} else if (Items.Menge !== "") {
						that.byId("idProductsTable").getItems()[i].getCells()[3].setValueState("None");
					}
					Items.Matnr = that.byId("idProductsTable").getItems()[i].getCells()[1].getSelectedKey();
					if (Items.Matnr === "") {
						that.byId("idProductsTable").getItems()[i].getCells()[1].setValueState("Error");
						that.byId("cmb2").setValueState("Error");
					} else {
						that.byId("cmb2").setValueState("None");
					}
					//	Items.Matnr = "101";
					Items.Lgort = that.byId("idProductsTable").getItems()[i].getCells()[0].getSelectedKey();
					if (Items.Lgort === "") {
						that.byId("idProductsTable").getItems()[i].getCells()[0].setValueState("Error");
						that.byId("cmb1").setValueState("Error");
					} else {
						that.byId("cmb1").setValueState("None");
					}
					ItemData.push(Items);
				}
			} else if (oJSONModel.getProperty("/oViewModel").tankDips) {
				for (var j = 0; j < tModel.length; j++) {
					var Items = {};

					Items.Chargeto = that.byId("tDpTable").getItems()[j].getCells()[0].getSelectedKey();
					if (Items.Chargeto === "") {
						that.byId("tDpTable").getItems()[j].getCells()[0].setValueState("Error");
						//	that.byId("tDcmb1").setValueState("Error");
					} else {
						that.byId("tDpTable").getItems()[j].getCells()[0].setValueState("None");
					}
					//	Items.MoveToWbs = that.byId("tDpTable").getItems()[j].getCells()[1].getValue();
					Items.Lgort = that.byId("tDpTable").getItems()[j].getCells()[1].getSelectedKey();
					if (Items.Lgort === "") {
						that.byId("tDpTable").getItems()[j].getCells()[1].setValueState("Error");
					} else {
						that.byId("tDpTable").getItems()[j].getCells()[1].setValueState("None");
					}
					Items.Matnr = that.byId("tDpTable").getItems()[j].getCells()[2].getSelectedKey();
					if (Items.Matnr === "") {
						that.byId("tDpTable").getItems()[j].getCells()[2].setValueState("Error");
					} else {
						that.byId("tDpTable").getItems()[j].getCells()[2].setValueState("None");
					}
					Items.Menge = that.byId("tDpTable").getItems()[j].getCells()[5].getValue();
					if (Items.Menge === "0") {
						that.byId("tDpTable").getItems()[j].getCells()[5].setValueState("Error");

						MessageToast.show("Quantity should not be zero");
						proceed = false;
					}
					if (Items.Menge === "") {
						that.byId("tDpTable").getItems()[j].getCells()[5].setValueState("Error");
						MessageToast.show("Enter current reading to calculate quantity");
						proceed = false;
					}
					if (that.byId("tDpTable").getItems()[j].getCells()[7].getText() !== "" &&
						that.byId("tDpTable").getItems()[j].getCells()[8].getText() !== "" &&
						that.byId("tDpTable").getItems()[j].getCells()[9].getText() !== "") {
						Items.Wellsection = that.byId("tDpTable").getItems()[j].getCells()[7].getText();
						Items.OperationType = that.byId("tDpTable").getItems()[j].getCells()[8].getText();
						Items.Diameter = that.byId("tDpTable").getItems()[j].getCells()[9].getText();
					}

					//	Items.Meins = that.byId("tDpTable").getItems()[j].getCells()[].getValue();

					ItemData.push(Items);
				}
			} else if (oJSONModel.getProperty("/oViewModel").pumpOut) {
				for (var k = 0; k < tModel.length; k++) {
					var Items = {};
					Items.Menge = that.byId("pmpOutTable").getItems()[k].getCells()[4].getValue();
					if (Items.Menge === "") {
						that.byId("pmpOutTable").getItems()[k].getCells()[4].setValueState("Error");
						MessageToast.show("Enter a valid quantity");
						proceed = false;
					}
					Items.Matnr = that.byId("pmpOutTable").getItems()[k].getCells()[3].getSelectedKey();
					if (Items.Matnr === "") {
						that.byId("pmpOutTable").getItems()[k].getCells()[3].setValueState("Error");
						proceed = false;
					}
					Items.Lgort = that.byId("pmpOutTable").getItems()[k].getCells()[1].getSelectedKey();
					if (Items.Lgort === "") {
						that.byId("pmpOutTable").getItems()[k].getCells()[1].setValueState("Error");
						proceed = false;
					}

					Items.Chargeto = that.byId("pmpOutTable").getItems()[k].getCells()[0].getSelectedKey();
					if (Items.Chargeto === "") {
						that.byId("pmpOutTable").getItems()[k].getCells()[0].setValueState("Error");
						proceed = false;
					}
					if (that.byId("rbTtoR").getSelected()) {
						Items.MoveToWbs = that.byId("pmpOutTable").getItems()[k].getCells()[2].getValue();
						if (that.byId("pmpOutTable").getItems()[k].getCells()[2].getValue() === "") {
							MessageBox.warning("Please enter the Wbs element");
						}
					}
					ItemData.push(Items);
				}
			} else if (oJSONModel.getProperty("/oViewModel").lubricants) {
				for (var r = 0; r < tModel.length; r++) {
					var Items = {};
				if (that.byId("idProductsTable").getItems()[r].getCells()[2].getValue() !== "") {
						Items.CartageAmount = that.byId("idProductsTable").getItems()[r].getCells()[2].getValue();
					}
			
					if (Items.Menge === "") {
						that.byId("idLubTable").getItems()[r].getCells()[3].setValueState("Error");
						proceed = false;
					} else if (Items.Menge !== "") {
						Items.Menge	= that.byId("idLubTable").getItems()[r].getCells()[3].getValue();
						that.byId("idLubTable").getItems()[r].getCells()[3].setValueState("None");
					}
					Items.Matnr = that.byId("idLubTable").getItems()[r].getCells()[1].getSelectedKey();
					if (Items.Matnr === "") {
						that.byId("tDpTable").getItems()[r].getCells()[1].setValueState("Error");
					} else {
						that.byId("tDpTable").getItems()[r].getCells()[1].setValueState("None");
					}

					Items.Lgort = that.byId("idLubTable").getItems()[r].getCells()[0].getSelectedKey();
					if (Items.Lgort === "") {
						that.byId("idLubTable").getItems()[r].getCells()[0].setValueState("Error");
					} else {
						that.byId("idLubTable").getItems()[r].getCells()[0].setValueState("None");
					}

					ItemData.push(Items);
				}
			}

			//	tModel.push(Items);
			oJSONModel.setProperty("/Payload", Items);
			var delDt = that.byId("delvyDt").getValue();
			var tdyDt = that.byId("toDt").getValue();
			var updatedFormat;
			var dateformat;
			if (delDt === "") {
				updatedFormat = null;
			} else {
				var delvyDate = new Date(delDt);
				updatedFormat = [delvyDate.getFullYear(), delvyDate.getMonth() + 1, delvyDate.getDate()].join("-");
				updatedFormat = updatedFormat + "T00:00:00";
				oHeader.PstngDate = updatedFormat;
				oHeader.DocDate = updatedFormat;
			}
			if (oJSONModel.getProperty("/oViewModel").tankDips) {
				if (tdyDt === "") {
					dateformat = null;
				} else {
					var today = new Date(tdyDt);
					dateformat = [today.getFullYear(), today.getMonth() + 1, today.getDate()].join("-");
					dateformat = dateformat + "T00:00:00";
					oHeader.PstngDate = dateformat;
					oHeader.DocDate = dateformat;
				}
			}
			oHeader.Bsart = "ZF";
			oHeader.MoveType = "901";
			//	oHeader.Location = that.byId("LcId").getSelectedKey();

			if (oJSONModel.getProperty("/oViewModel").pumpOut) {
				oHeader.MoveStloc = that.byId("MvId").getSelectedKey();
			}
			oHeader.Lifnr = that.byId("VnId").getSelectedKey();
			oHeader.Ekgrp = "";
			oHeader.ReceiptType = that.byId("selComb").getSelectedKey();
			oHeader.HeaderTxt = "";
			if (that.byId("rbTtoR").getSelected() && oJSONModel.getProperty("/oViewModel").pumpOut) {
				oHeader.TransferToRig = "X";
				that.byId("vndrBox").setVisible(false);
				that.byId("MvBox").setVisible(true);
			} else if (oJSONModel.getProperty("/oViewModel").pumpOut && that.byId("rbRtoS").getSelected()) {

				that.byId("rbMngd").setSelected(false);
				that.byId("MvBox").setVisible(false);
				that.byId("vndrBox").setVisible(true);
				oHeader.ReturnToSupp = "X";
			}

			var tDipsflag = true;
			if (oJSONModel.getProperty("/oViewModel").tankDips) {
				tDipsflag = false;
			}
			var LubFlag = true;
			if (oJSONModel.getProperty("/oViewModel").lubricants) {
				LubFlag = false;
			}
			if (oJSONModel.getProperty("/oViewModel").pumpOut) {
				LubFlag = false;
			}
			if (tDipsflag && LubFlag) {
				if (that.byId("rbMngd").getSelected()) {
					oHeader.ManagedFuel = "X";
				} else if (that.byId("rbNMngd").getSelected()) {
					oHeader.NonManagedFuel = "X";
				}
			}

			// insert item data into header data
			oHeader.ItemsSet = ItemData;
			//get model instance
			var oModelMain = this.getOwnerComponent().getModel();
			//call POST method
			//	sap.ui.core.BusyIndicator.show(0);
			if (that.byId("MvId").getSelectedKey() !== "" && that.byId("VnId").getSelectedKey() === "") {
				proceed = true;
			}
			if (proceed !== true) {
				MessageBox.warning("Please enter all the mandatory fields");
				sap.ui.core.BusyIndicator.hide();
			} else if (proceed === true && that.byId("delvyDt").getValue() === "" && tDipsflag) {
				MessageBox.warning("Please Enter the Delivery Date");
				sap.ui.core.BusyIndicator.hide();
			} else if (proceed === true && oJSONModel.getProperty("/continue")) {
				MessageBox.warning("Please Choose the appropriate material");
				sap.ui.core.BusyIndicator.hide();
			} else {
				var that = this;
				sap.ui.core.BusyIndicator.show();
				oModelMain.create("/HeaderSet", oHeader, {
					success: function(oData, oResponse) {
						// Success
						sap.ui.core.BusyIndicator.hide();
						var oMsg = oResponse.headers;
						//	var oEsheet = oResponse.data.Name1;
						var jsonStr = oMsg["sap-message"];
						//	sap.m.MessageToast.show((JSON.parse(jsonStr).message));
						//	that.getOwnerComponent().getModel("json").setProperty("/Message", (JSON.parse(jsonStr).message));
						//	that.byId("MsgStrip").setVisible(true);
						MessageBox.success((JSON.parse(jsonStr).message));
						var p = that.getOwnerComponent().getModel("json").getProperty("/tabI");
						that.getOwnerComponent().getModel("json").setProperty("/MatrlModel" + p, "");
						that.refreshTable();
						that.resetAll();

					},
					error: function(oError, oResponse) {
						sap.ui.core.BusyIndicator.hide();
						jQuery.sap.require("sap.m.MessageBox");
						sap.m.MessageBox.show((JSON.parse(oError.responseText).error.message.value), {
							icon: sap.m.MessageBox.Icon.Information,
							title: "Message Box"
						});
					}
				});
			}
		},
		suggestionItemSelected: function(oEvt) {
			oEvt.getSource();
			oEvt.getParameters();
		},

		/* =========================================================== */
		/* event handlers                                              */
		/* =========================================================== */

		/**
		 * Triggered by the table's 'updateFinished' event: after new table
		 * data is available, this handler method updates the table counter.
		 * This should only happen if the update was successful, which is
		 * why this handler is attached to 'updateFinished' and not to the
		 * table's list binding's 'dataReceived' method.
		 * @param {sap.ui.base.Event} oEvent the update finished event
		 * @public
		 */
		onUpdateFinished: function(oEvent) {
			// update the worklist's object counter after the table update
			var sTitle,
				oTable = oEvent.getSource(),
				iTotalItems = oEvent.getParameter("total");
			// only update the counter if the length is final and
			// the table is not empty
			if (iTotalItems && oTable.getBinding("items").isLengthFinal()) {
				sTitle = this.getResourceBundle().getText("worklistTableTitleCount", [iTotalItems]);
			} else {
				sTitle = this.getResourceBundle().getText("worklistTableTitle");
			}
			this.getModel("worklistView").setProperty("/worklistTableTitle", sTitle);
		},

		/**
		 * Event handler when a table item gets pressed
		 * @param {sap.ui.base.Event} oEvent the table selectionChange event
		 * @public
		 */
		onPress: function(oEvent) {
			// The source is the list item that got pressed
			this._showObject(oEvent.getSource());
		},
		onClear: function() {
			this.refreshTable();
			this.resetAll();
		},

		/**
		 * Event handler when the share in JAM button has been clicked
		 * @public
		 */
		onShareInJamPress: function() {
			var oViewModel = this.getModel("worklistView"),
				oShareDialog = sap.ui.getCore().createComponent({
					name: "sap.collaboration.components.fiori.sharing.dialog",
					settings: {
						object: {
							id: location.href,
							share: oViewModel.getProperty("/shareOnJamTitle")
						}
					}
				});
			oShareDialog.open();
		},

		onSearch: function(oEvent) {
			if (oEvent.getParameters().refreshButtonPressed) {
				// Search field's 'refresh' button has been pressed.
				// This is visible if you select any master list item.
				// In this case no new search is triggered, we only
				// refresh the list binding.
				this.onRefresh();
			} else {
				var oTableSearchState = [];
				var sQuery = oEvent.getParameter("query");

				if (sQuery && sQuery.length > 0) {
					oTableSearchState = [new Filter("Maktx", FilterOperator.Contains, sQuery)];
				}
				this._applySearch(oTableSearchState);
			}

		},

		/**
		 * Event handler for refresh event. Keeps filter, sort
		 * and group settings and refreshes the list binding.
		 * @public
		 */
		onRefresh: function() {
			this._oTable.getBinding("items").refresh();
		},

		/* =========================================================== */
		/* internal methods                                            */
		/* =========================================================== */

		/**
		 * Shows the selected item on the object page
		 * On phones a additional history entry is created
		 * @param {sap.m.ObjectListItem} oItem selected Item
		 * @private
		 */
		_showObject: function(oItem) {
			this.getRouter().navTo("object", {
				objectId: oItem.getBindingContext().getProperty("Matnr")
			});
		},

		/**
		 * Internal helper method to apply both filter and search state together on the list binding
		 * @param {object} oTableSearchState an array of filters for the search
		 * @private
		 */
		_applySearch: function(oTableSearchState) {
			var oViewModel = this.getModel("worklistView");
			this._oTable.getBinding("items").filter(oTableSearchState, "Application");
			// changes the noDataText of the list in case there are no filter results
			if (oTableSearchState.length !== 0) {
				oViewModel.setProperty("/tableNoDataText", this.getResourceBundle().getText("worklistNoDataWithSearchText"));
			}
		}

	});
});