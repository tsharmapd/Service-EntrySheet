jQuery.sap.require("sap.ui.qunit.qunit-css");
jQuery.sap.require("sap.ui.thirdparty.qunit");
jQuery.sap.require("sap.ui.qunit.qunit-junit");
QUnit.config.autostart = false;

sap.ui.require([
		"sap/ui/test/Opa5",
		"pd/fr/test/integration/pages/Common",
		"sap/ui/test/opaQunit",
		"pd/fr/test/integration/pages/Worklist",
		"pd/fr/test/integration/pages/Object",
		"pd/fr/test/integration/pages/NotFound",
		"pd/fr/test/integration/pages/Browser",
		"pd/fr/test/integration/pages/App"
	], function (Opa5, Common) {
	"use strict";
	Opa5.extendConfig({
		arrangements: new Common(),
		viewNamespace: "pd.fr.view."
	});

	sap.ui.require([
		"pd/fr/test/integration/WorklistJourney",
		"pd/fr/test/integration/ObjectJourney",
		"pd/fr/test/integration/NavigationJourney",
		"pd/fr/test/integration/NotFoundJourney",
		"pd/fr/test/integration/FLPIntegrationJourney"
	], function () {
		QUnit.start();
	});
});