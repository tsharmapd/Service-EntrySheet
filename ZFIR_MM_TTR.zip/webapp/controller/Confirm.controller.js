sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/core/routing/History",
	"sap/m/MessageBox",
	"sap/ui/model/Filter",
	"sap/m/MessageToast"
], function(Controller, History, MessageBox, Filter, MessageToast) {
	"use strict";

	return Controller.extend("va.controller.Confirm", {
		onInit: function() {
			this.getOwnerComponent().getRouter().getRoute("confirm").attachPatternMatched(this._onMatched, this);

		},
		_onMatched: function() {
			var oModel = this.getOwnerComponent().getModel();
			var oJSONModel = this.getOwnerComponent().getModel("json");
			var oTable = this.byId("tabId");
			oTable.setVisible(false);
			var that = this;
			this.oBusy = new sap.m.BusyDialog();
			this.oBusy.open();

			oModel.read("/HeadSet", {
				success: function(r) {
					that.oBusy.close();
					oJSONModel.setProperty("/headModel", r.results);
				},
				error: function() {
					that.oBusy.close();
					MessageToast.show("Unable to get records from Header Please try again.");
				}
			});
			oModel.read("/CheckflagSet('B')", {
				success: function(r, s) {
					oJSONModel.setProperty("/RigNum", r);
				}
			});
			oJSONModel.refresh();
		},

		/// navigation back to previous hash
		onNavBack: function() {
			var sPreviousHash = History.getInstance().getPreviousHash(),
				oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation");
			if (sPreviousHash !== undefined || !oCrossAppNavigator.isInitialNavigation()) {
				history.go(-1);
			} else {
				oCrossAppNavigator.toExternal({
					target: {
						shellHash: "#Shell-home"
					}
				});
			}
		},
		onSelectedItem: function(oEvent) {
			var oModel = this.getOwnerComponent().getModel();
			var oJSONModel = this.getOwnerComponent().getModel("json");
			var selctdItem = oEvent.getParameter("listItem").getBindingContext("json").getObject();
			var Mtr = selctdItem.Ttr;
			var that = this;
			var Flg = "X";
			// this.sSearch = oEvent.getParameter("query");
			var aFilter = [];
			aFilter.push(new sap.ui.model.Filter(
				"Mtrnum",
				sap.ui.model.FilterOperator.EQ, Mtr
			));
			aFilter.push(new sap.ui.model.Filter(
				"Flag",
				sap.ui.model.FilterOperator.EQ, Flg
			));
			aFilter.push(new sap.ui.model.Filter(
				"Item",
				sap.ui.model.FilterOperator.EQ, ""
			));
			oModel.read("/DraftitemsSet", {
				filters: aFilter,
				success: function(r) {
					sap.ui.core.BusyIndicator.hide();
					oJSONModel.setProperty("/confModel", r.results);
					oJSONModel.refresh("true");
					var oTable = that.byId("tabId");
					oTable.setVisible(true);
				},
				error: function() {
					sap.ui.core.BusyIndicator.hide();
				}
			});
			oJSONModel.refresh();
		}

	});
});