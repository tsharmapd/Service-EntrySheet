sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/core/routing/History",
	"sap/m/MessageBox",
	"sap/ui/model/Filter",
	"sap/m/MessageToast"
], function(Controller, History, MessageBox, Filter, MessageToast) {
	"use strict";

	return Controller.extend("va.controller.ShoppingCart", {
		onInit: function() {
			this.getOwnerComponent().getRouter().getRoute("cart").attachPatternMatched(this._onMatched, this);

		},
		_onMatched: function() {
			var oModel = this.getOwnerComponent().getModel();
			var oJSONModel = this.getOwnerComponent().getModel("json");
			var that = this;
			this.oBusy = new sap.m.BusyDialog();
			this.oBusy.open();

			oModel.read("/CheckflagSet('X')", {
				success: function(r) {
					that.oBusy.close();
					oJSONModel.setProperty("/Flag", r);
				}
			});
			oModel.read("/DraftitemsSet", {
				success: function(r) {
					that.oBusy.close();
					oJSONModel.setProperty("/cartModel", r.results);
				},
				error: function() {
					that.oBusy.close();
					MessageToast.show("Unable to get records from cartData. Please try again.");
				}
			});
			// oJSONModel.refresh();
		},

		/// navigation back to previous hash
		onNavBack: function() {
			var sPreviousHash = History.getInstance().getPreviousHash(),
				oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation");
			if (sPreviousHash !== undefined || !oCrossAppNavigator.isInitialNavigation()) {
				history.go(-1);
			} else {
				oCrossAppNavigator.toExternal({
					target: {
						shellHash: "#Shell-home"
					}
				});
			}
		},

		//// on delete pressed of the dialog draft items//
		onDeleteSelectedItemPressed: function(oEvent) {
			var oModel = this.getOwnerComponent().getModel();
			var oJSONModel = this.getOwnerComponent().getModel("json");
			var selctdItem = oEvent.getParameter("listItem").getBindingContext("json").getObject();
			var olinenum = selctdItem.Item;
			var Guid = selctdItem.Mtrnum;
			//	sap.ui.core.BusyIndicator.show(0);
			oModel.remove("/DraftitemsSet(Mtrnum='" + Guid + "',Item='" + olinenum + "')", {
				success: function(data, response) {
					sap.ui.core.BusyIndicator.hide();
					oModel.read("/DraftitemsSet", {
						success: function(r, s) {
							oJSONModel.setProperty("/cartModel", r.results);
						}
					});
					MessageToast.show("Draft item successfully removed from cart");
					oModel.read("/CheckflagSet('X')", {
						success: function(r) {
							sap.ui.core.BusyIndicator.hide();
							oJSONModel.setProperty("/Flag", r);
						}
					});
					oJSONModel.refresh("true");
				}
			});
		}

	});
});