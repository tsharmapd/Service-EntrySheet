sap.ui.define([
	"va/controller/BaseController",
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/routing/History",
	"va/model/formatter",
	"sap/m/MessageBox",
	"sap/ui/model/Filter",
	"sap/m/MessageToast",
	"sap/ui/model/FilterOperator"

], function(BaseController, JSONModel, History, formatter, MessageBox, Filter, MessageToast, FilterOperator) {
	"use strict";

	return BaseController.extend("va.controller.Worklist", {

		formatter: formatter,

		/* =========================================================== */
		/* lifecycle methods                                           */
		/* =========================================================== */

		/**
		 * Called when the worklist controller is instantiated.
		 * @public
		 */
		onInit: function() {
			var oModel = this.getOwnerComponent().getModel();
			var oJSONModel = this.getOwnerComponent().getModel("json");
			sap.ui.core.BusyIndicator.show(0);

			oModel.read("/SeachitemSet", {
				success: function(r) {
					oJSONModel.setProperty("/tableModel", r.results);
				},
				error: function() {}
			});
			oModel.read("/CheckflagSet('B')", {
				success: function(r, s) {
					oJSONModel.setProperty("/RigNum", r);
				}
			});
			oModel.read("/CheckflagSet('X')", {
				success: function(r) {
					sap.ui.core.BusyIndicator.hide();
					oJSONModel.setProperty("/Flag", r);

				}
			});
			sap.ui.core.BusyIndicator.hide(0);
			oJSONModel.refresh(true);

		},

		/* =========================================================== */
		/* event handlers                                              */
		/* =========================================================== */

		onDiscard: function() {
			var oModel = this.getOwnerComponent().getModel();
			var oJSONModel = this.getOwnerComponent().getModel("json");
			var oRecord = this.getView().getModel("json").getData().Flag[0];
			var Mtr = {};
			var olinenum = {};
			var flag = "X";
			Mtr = oRecord.Mtr;
			// var srecord = oRecord.Guid;

			oModel.remove("/DraftitemsSet(Mtrnum='" + Mtr + "',Item='" + olinenum + "',Flag='" + flag + "')", {
				success: function(data, response) {
					MessageBox.success("Draft item successfully removed ");
					oModel.read("/CheckflagSet('X')", {
						success: function(r) {
							oJSONModel.setProperty("/Flag", r);
						}
					});
					oJSONModel.refresh("true");
				},
				error: function() {

					MessageBox.error("Unable to delete records from cartData. Please try again.");
				}
			});
			oJSONModel.refresh();
			this.oInitalDialog.close();
		},

		OnLostHole: function(oevent) {
			var that = this;
			if (oevent.getSource().getSelected()) {
				that.byId("job").setVisible(true);
				that.byId("jobId").setVisible(true);
				that.byId("opr").setVisible(true);
				that.byId("oprId").setVisible(true);
				that.byId("well").setVisible(true);
				that.byId("wellId").setVisible(true);
				that.byId("lsd").setVisible(true);
				that.byId("lsdId").setVisible(true);
				that.byId("lat").setVisible(true);
				that.byId("latId").setVisible(true);
				that.byId("log").setVisible(true);
				that.byId("logId").setVisible(true);
				that.byId("ship").setVisible(false);
				that.byId("shipId").setVisible(false);
				// that.byId("wbsId").setVisible(true);
			}

		},

		onTrnsfrRig: function(oevent) {
			var that = this;
			if (oevent.getSource().getSelected()) {
				that.byId("job").setVisible(false);
				that.byId("jobId").setVisible(false);
				that.byId("opr").setVisible(false);
				that.byId("oprId").setVisible(false);
				that.byId("well").setVisible(false);
				that.byId("wellId").setVisible(false);
				that.byId("lsd").setVisible(false);
				that.byId("lsdId").setVisible(false);
				that.byId("lat").setVisible(false);
				that.byId("latId").setVisible(false);
				that.byId("log").setVisible(false);
				that.byId("logId").setVisible(false);
				that.byId("ship").setVisible(true);
				that.byId("shipId").setVisible(true);
				// that.byId("wbsId").setVisible(true);
			}

		},

		OnNonTrackItemPress: function(oEvent) {
			if (!this._oAddNonTrack) {
				this._oAddNonTrack = sap.ui.xmlfragment("va.view.AddNonTrack", this);
				this.getView().addDependent(this._oAddNonTrack);
				// forward compact/cozy style into Dialog
				// this._oCatalogDialog.addStyleClass(this.getOwnerComponent().getContentDensityClass());
			}
			this._oAddNonTrack.open();
		},

		onCancelpDialog: function() {
			var that = this;
			that.oAddNonTrack.close();
		},

		handleValueHelp: function(oEvent) {
			var sInputValue = oEvent.getSource().getValue();
			this.inputId = oEvent.getSource().getId();
			// create value help dialog
			if (!this._valueHelpDialog) {
				this._valueHelpDialog = sap.ui.xmlfragment("va.view.ValueHelp", this);
				this.getView().addDependent(this._valueHelpDialog);
			}
			this._valueHelpDialog.open(sInputValue);
		},

		handleValueHp: function(oEvent) {
			var sInputValue = oEvent.getSource().getValue();
			this.inputId = oEvent.getSource().getId();
			// create value help dialog
			if (!this._valueHpDialog) {
				this._valueHpDialog = sap.ui.xmlfragment("va.view.ValueHp", this);
				this.getView().addDependent(this._valueHpDialog);
			}
			this._valueHpDialog.open(sInputValue);
		},

		_handleValueHpClose: function(evt) {
			var that = this;
			// var oJSONModel = that.getOwnerComponent().getModel("json");
			var oSelectedItem = evt.getParameter("selectedItem");
			if (oSelectedItem) {
				var orderInput = this.byId("rigId");
				orderInput.setValue(oSelectedItem.getTitle());
				// var oVal = oSelectedItem.getDescription();
				// oJSONModel.setProperty("/Matrlnumber", oVal);

			}
			// evt.getSource().getBinding("items").filter([]);
		},
		_handleValueHelpClose: function(evt) {
			var that = this;
			// var oJSONModel = that.getOwnerComponent().getModel("json");
			var oSelectedItem = evt.getParameter("selectedItem");
			if (oSelectedItem) {
				var orderInput = this.byId("plantId");
				orderInput.setValue(oSelectedItem.getTitle());
				// var oVal = oSelectedItem.getDescription();
				// oJSONModel.setProperty("/Matrlnumber", oVal);

			}
			// evt.getSource().getBinding("items").filter([]);
		},
		onAddToCartPressed: function(oEvent) {
			var shText = this.byId("plantId");

			if (shText.getValue() === "") {
				shText.setValueState("Error");
				MessageBox.error("Enter the Plant");
			} else {
				shText.setValueState("None");
				var rig = this.byId("rigId");
				if (rig.getValue() === "") {
					rig.setValueState("Error");
					MessageBox.error("Enter the Rig Number");
				} else {
					rig.setValueState("None");
					var objData = oEvent.getSource().getParent().getBindingContext("json").getObject();
					if (objData.Qty === "0.000" || objData.Qtyy === "") {
						MessageBox.warning("Quantity should not be Empty or Zero");
					} else {
						var cartData = {};
						var table = oEvent.getSource().getParent().getParent().getParent();
						var items = oEvent.getSource().getParent().getParent();
						var index = table.indexOfItem(items);
						var selectedStatus = table.getItems()[index].getCells()[4].getSelectedItem().getText();
						cartData.Reasoncode = selectedStatus;
						cartData.Matnr = objData.Matnr;
						// cartData.Knttp = this.byId("selComb").getSelectedKey();
						cartData.Maktx = objData.Description;
						cartData.Charg = objData.Condition;
						cartData.EntryQty = objData.Qty;
						cartData.Type = objData.Type;
						cartData.Menge = objData.Availqty;
						cartData.Comments = objData.Comments;
						cartData.Towerks = this.getView().byId("plantId").getValue();
						cartData.Shipmentinfo = this.getView().byId("shipId").getValue();
						cartData.Tolgort = this.getView().byId("rigId").getValue();
						// cartData.Shipmentdate = this.getView().byId("transId").getValue();
						cartData.Tolongitude = this.getView().byId("latId").getValue();
						cartData.Tolatitude = this.getView().byId("logId").getValue();
						var oModel = this.getOwnerComponent().getModel();
						var oJSONModel = this.getOwnerComponent().getModel("json");
						sap.ui.core.BusyIndicator.show(0);
						oModel.create("/DraftitemsSet", cartData, {

							success: function(oData, oResponse) {
								// MessageToast.show("Item added to cart");
								oModel.read("/CheckflagSet('X')", {
									success: function(r) {
										oJSONModel.setProperty("/Flag", r);
										oJSONModel.refresh("true");
										MessageToast.show("Item added to cart");
										sap.ui.core.BusyIndicator.hide();
									}

								});
								// to update the table with the new item created  
								oModel.read("/DraftitemsSet", {
									success: function(r, s) {
										oJSONModel.setProperty("/cartModel", r.results);
										sap.ui.core.BusyIndicator.hide();
									}
								});
								oJSONModel.refresh(true);
							},
							error: function(Odata, oResponse) {
								sap.ui.core.BusyIndicator.hide();
								// var oMsg = oResponse.headers;
								// var jsonStr = oMsg["sap-message"];
								// sap.m.MessageToast.show((JSON.parse(jsonStr).message));

							}
						});
					}
				}
			}
		},

		
		onCreateItemPress: function(oEvent) {
			var canProceed = true;
			var shText = sap.ui.getCore().byId("shtextId");
			if (shText.getValue() === "") {
				shText.setValueState("Error");
				shText.setValueStateText("Enter Material");
				canProceed = false;
			}

			var qtyVal = sap.ui.getCore().byId("qtyId");
			if (qtyVal.getValue() === "") {
				qtyVal.setValueState("Error");
				qtyVal.setValueStateText("Enter Quantity");
				canProceed = false;
			}
			// if (canProceed === "true") {
			var addToCart = {};
			//	addToCart.Knttp = accAsgn;
			addToCart.Ntdescription = shText.getValue();
			addToCart.Ntentryqty = qtyVal.getValue();

			var oModel = this.getOwnerComponent().getModel();
			var oJSONModel = this.getOwnerComponent().getModel("json");
			sap.ui.core.BusyIndicator.show(0);
			oModel.create("/DraftitemsSet", addToCart, {
				success: function(oData, oResponse) {
					MessageToast.show("Item added to cart");
					oModel.read("/CheckflagSet('X')", {
						success: function(r) {
							oJSONModel.setProperty("/Flag", r);
							oJSONModel.refresh("true");
							MessageToast.show("Item added to cart");
							sap.ui.core.BusyIndicator.hide();
						}

					});
					sap.ui.getCore().byId("shtextId").setValue("");
					sap.ui.getCore().byId("shtextId").setValueState("None");
					sap.ui.getCore().byId("qtyId").setValue("");
					sap.ui.getCore().byId("qtyId").setValueState("None");
					// to update the table with the new item created  
					oModel.read("/DraftitemsSet", {
						success: function(r, s) {
							oJSONModel.setProperty("/cartModel", r.results);
							sap.ui.core.BusyIndicator.hide();
						}
					});
					oJSONModel.refresh(true);
				},
				error: function() {
					sap.ui.core.BusyIndicator.hide();
				}
			});
		},
		// },

		//// shopping cart button opens dialog with draft items
		onShoppingCartPressed: function(oEvent) {
			var oJSONModel = this.getOwnerComponent().getModel("json");
			sap.ui.core.BusyIndicator.show();
			this.getOwnerComponent().getModel().read("/DraftitemsSet", {
				success: function(r) {

					oJSONModel.setProperty("/cartModel", r.results);
					sap.ui.core.BusyIndicator.hide();
				}
			});

			if (!this.ocartPress) {
				this.ocartPress = sap.ui.xmlfragment("va.view.ShoppingCart", this);
				this.getView().addDependent(this.ocartPress);
			}

			this.ocartPress.open();
		},

		//// on delete pressed of the dialog draft items//
		onDeletePressed: function(oEvent) {
			var oModel = this.getOwnerComponent().getModel();
			var oJSONModel = this.getOwnerComponent().getModel("json");
			var selctdItem = oEvent.getParameter("listItem").getBindingContext("json").getObject();
			var olinenum = selctdItem.Item;
			var Guid = selctdItem.Mtrnum;
			var flag = "X";
			//	sap.ui.core.BusyIndicator.show(0);
			oModel.remove("/DraftitemsSet(Mtrnum='" + Guid + "',Item='" + olinenum + "',Flag='" + flag + "')", {
				success: function(data, response) {
					sap.ui.core.BusyIndicator.hide();
					oModel.read("/DraftitemsSet", {
						success: function(r, s) {
							oJSONModel.setProperty("/cartModel", r.results);
						}
					});
					MessageToast.show("Draft item successfully removed from cart");
					oModel.read("/CheckflagSet('X')", {
						success: function(r) {
							sap.ui.core.BusyIndicator.hide();
							oJSONModel.setProperty("/Flag", r);
						}
					});
					oJSONModel.refresh("true");
				}
			});
		},

		///// cart dialog cancel closes dialog
		cancel: function() {
			this.ocartPress.close();
		},

		getRouter: function() {
			return sap.ui.core.UIComponent.getRouterFor(this);
		},
		//// navigation on View cart press on cart dialog
		ViewCart: function(oEvt) {
			var cartId = "cartId";
			this.getOwnerComponent().getRouter().navTo("cart", {
				cartId: cartId
			});
		},

		onChangeSel: function(oEvt) {
			this.sComb = this.byId("selComb").getSelectedKey();
			if (this.sComb === "T") {
				var confirmId = "confirmId";
				this.getOwnerComponent().getRouter().navTo("confirm", {
					confirmId: confirmId
				});
			}
		},

		// });

		/**
		 * Triggered by the table's 'updateFinished' event: after new table
		 * data is available, this handler method updates the table counter.
		 * This should only happen if the update was successful, which is
		 * why this handler is attached to 'updateFinished' and not to the
		 * table's list binding's 'dataReceived' method.
		 * @param {sap.ui.base.Event} oEvent the update finished event
		 * @public
		 */
		onUpdateFinished: function(oEvent) {
			// update the worklist's object counter after the table update
			var sTitle,
				oTable = oEvent.getSource(),
				iTotalItems = oEvent.getParameter("total");
			// only update the counter if the length is final and
			// the table is not empty
			if (iTotalItems && oTable.getBinding("items").isLengthFinal()) {
				sTitle = this.getResourceBundle().getText("worklistTableTitleCount", [iTotalItems]);
			} else {
				sTitle = this.getResourceBundle().getText("worklistTableTitle");
			}
			this.getModel("worklistView").setProperty("/worklistTableTitle", sTitle);
		},

		/**
		 * Event handler when a table item gets pressed
		 * @param {sap.ui.base.Event} oEvent the table selectionChange event
		 * @public
		 */
		onPress: function(oEvent) {
			// The source is the list item that got pressed
			this._showObject(oEvent.getSource());
		},

		/**
		 * Event handler when the share in JAM button has been clicked
		 * @public
		 */
		onShareInJamPress: function() {
			var oViewModel = this.getModel("worklistView"),
				oShareDialog = sap.ui.getCore().createComponent({
					name: "sap.collaboration.components.fiori.sharing.dialog",
					settings: {
						object: {
							id: location.href,
							share: oViewModel.getProperty("/shareOnJamTitle")
						}
					}
				});
			oShareDialog.open();
		},

		onSearch: function(oEvent) {
			if (oEvent.getParameters().refreshButtonPressed) {
				// Search field's 'refresh' button has been pressed.
				// This is visible if you select any master list item.
				// In this case no new search is triggered, we only
				// refresh the list binding.
				this.onRefresh();
			} else {
				var aTableSearchState = [];
				var sQuery = oEvent.getParameter("query");

				if (sQuery && sQuery.length > 0) {
					aTableSearchState = [new Filter("Description", FilterOperator.Contains, sQuery)];
				}
				this._applySearch(aTableSearchState);
			}

		},

		/**
		 * Event handler for refresh event. Keeps filter, sort
		 * and group settings and refreshes the list binding.
		 * @public
		 */
		onRefresh: function() {
			var oTable = this.byId("table");
			oTable.getBinding("items").refresh();
		},

		/* =========================================================== */
		/* internal methods                                            */
		/* =========================================================== */

		/**
		 * Shows the selected item on the object page
		 * On phones a additional history entry is created
		 * @param {sap.m.ObjectListItem} oItem selected Item
		 * @private
		 */
		_showObject: function(oItem) {
			this.getRouter().navTo("object", {
				objectId: oItem.getBindingContext().getProperty("Matnr")
			});
		},

		/**
		 * Internal helper method to apply both filter and search state together on the list binding
		 * @param {sap.ui.model.Filter[]} aTableSearchState An array of filters for the search
		 * @private
		 */
		_applySearch: function(aTableSearchState) {
			var oTable = this.byId("table"),
				oViewModel = this.getModel("worklistView");
			oTable.getBinding("items").filter(aTableSearchState, "Application");
			// changes the noDataText of the list in case there are no filter results
			if (aTableSearchState.length !== 0) {
				oViewModel.setProperty("/tableNoDataText", this.getResourceBundle().getText("worklistNoDataWithSearchText"));
			}
		}

	});
});