/*global location */
sap.ui.define([
	"pr/req/controller/BaseController",
	"sap/ui/model/json/JSONModel",
	"pr/req/model/formatter",
	"sap/m/MessageBox",
	"sap/ui/model/Filter"

], function(BaseController, JSONModel, formatter, MessageBox, Filter) {
	"use strict";

	return BaseController.extend("pr.req.controller.Detail", {

		formatter: formatter,

		/* =========================================================== */
		/* lifecycle methods                                           */
		/* =========================================================== */

		onInit: function(oEvent) {
			//	this.getRouter().getRoute("object").attachPatternMatched(this._onObjectMatched, this);
			//	_onObjectMatched : function (oEvent) {
			//	var oArguments = oEvent.getParameter("arguments");
			//	this._sObjectId = oArguments.objectId;
			//	var oJSONModel= this.getView().getModel("json");
			//	var mArguments = oJSONModel.getProperty("/Filtervalue");
			//	var aFilters = [new Filter("Matkl", "EQ", "15100000")];

			//	var oTable = this.getView().byId("table");
			//	var oModel= this.getOwnerComponent().getModel();
			//	var oJSONModel = this.getOwnerComponent().getModel("json");
			/*	oModel.read("/SearchItemsSet", {
					success: function(r) {
						oTable.setBusy(false);
					 oJSONModel.setProperty("/tablebindingModel", r.results);
					},
					error: function() {
                        oTable.setBusy(false);
						MessageBox.error("Unable to delete records from cartData. Please try again.");
					}
				});*/
		},
		
			onSearchPressed: function(oEvent) {
			this.sSearch = oEvent.getParameter("query");
		//	this._oTableOperations.setSearchTerm(sSearch);
		//	this._oTableOperations.applyTableOperations();
		},
		
		onShoppingCartPressed: function() {
		//	var oView= this;
				if (!this._oShopDialog) {
					this._oShopDialog = sap.ui.xmlfragment("pr.req.view.ShoppingCart", this);
					this.getView().addDependent(this._oShopDialog);
				// forward compact/cozy style into Dialog
				this._oShopDialog.addStyleClass(this.getOwnerComponent().getContentDensityClass());
				
				}
				this._oShopDialog.open();
			},
				cancel:function(){
					
					this._oShopDialog.close();
					
				},
					getRouter: function() {
			return sap.ui.core.UIComponent.getRouterFor(this);
		},
				
				
				ViewCart:function(oEvt){
					var cartId="cartId";
				this.getOwnerComponent().getRouter().navTo("cart", {
					cartId: cartId
			});
			},
			
				onAddToCartPressed: function(oEvent) {
					var oData = {
				Corder: this.Corder,
				Coyear: this.Coyear,
			//	DocContent: sContent,
			//	Title: sTitle
			};
			this.getOwnerComponent().getModel().callFunction("/DraftitemsSet",oData, {
				method: "POST",
					success: function() {
				
				},
				error: function() {
				
					MessageBox.error("Unable to save note.");
				}
			
			//	success: (this.onCartSrvSuccess.bind(this)),
			//	error: (this.onCartSrvError.bind(this))
			});
		}
			
		
	
	/*	onCartSrvSuccess: function(oEvent) {
			var oModel = this.getOwnerComponent().getModel();
			var sKey = oModel.createKey("/DraftitemsSet", {
			});
			var sProductName = oModel.getProperty(sKey).Name;
		
	    	this._oHeaderButton = this.getView().byId("headerCartBtn");
			this._oHeaderButton.getElementBinding().refresh();
		}*/

		
			//var cartId="cartId";
			/*	this.getRouter().navTo("cart", {
					cartId: cartId*/
			//	});

		//	_oShopDialog.$().offset({top : "100", right : "100"});

		//	var getKey = oJSONModel.Filtervalue[0].results;                         
		/*		var oList;
				var Selected= true;
		var oView = this.getView();
		var listS;
		var aListIds = ["catlgList", "EquipList", "PrevReqList"];
		if (oEvent) {
			oList = oEvent.getSource();
			aListIds.forEach(function(sId) {
				oView.byId(sId).setSelected(false);
			});
			oList.setSelected(true);
			listS = oList;
		} else {
			aListIds.forEach(function(sId) {
				if (oView.byId(sId).getSelected()) {
					oList = oView.byId(sId);
				}
			});
			listS = aListIds;
		}
			
				var sFilterValue = "Matkl";
					if (oList.getId().indexOf("catlgList") !== -1) {
			sFilterValue = "Matkl";
		} else if (oList.getId().indexOf("EquipList") !== -1) {
			sFilterValue = "Mfrnr";
		}/* else if (oList.getId().indexOf("PrevReqList") !== -1) {
			sFilterValue = "COMP";
		}*/

		/*	var oFilter = new Filter("sFilterValue", "EQ", sFilterValue);
		//	this._populateOverviewTable(oFilter, tilesS);
					var oTable = this.getView().byId("Table");
					var oModel= this.getOwnerComponent().getModel();
					var oJSONModel = this.getOwnerComponent().getModel("json");
				oModel.read("/SearchItemsSet", {
					filters:[oFilter],
					success: function(r) {
						oTable.setBusy(false);
					 oJSONModel.setProperty("/tablebindingModel", r.results);
						var iRows = r.results.length;
					if (iRows > 10) {
						oTable.setVisibleRowCount(10);
					} else if (iRows > 0 && iRows < 11) {
						oTable.setVisibleRowCount(iRows);
					} else if (iRows === 0 || !iRows) {
						oTable.setVisibleRowCount(1);
					}
				
		
					},*/

		// Model used to manipulate control states. The chosen values make sure,
		// detail page is busy indication immediately so there is no break in
		// between the busy indication for loading the view's meta data
		//	var oViewModel = new JSONModel({
		//	busy : false,
		//	delay : 0,
		//	lineItemListTitle : this.getResourceBundle().getText("detailLineItemTableHeading")
		//	});

		//	this.getRouter().getRoute("object").attachPatternMatched(this._onObjectMatched, this);

		//	this.setModel(oViewModel, "detailView");

		//this.getOwnerComponent().getModel().metadataLoaded().then(this._onMetadataLoaded.bind(this));

		/* =========================================================== */
		/* event handlers                                              */
		/* =========================================================== */

		/**
		 * Event handler when the share by E-Mail button has been clicked
		 * @public
		 */
		/*	onShareEmailPress : function () {
				var oViewModel = this.getModel("detailView");

				sap.m.URLHelper.triggerEmail(
					null,
					oViewModel.getProperty("/shareSendEmailSubject"),
					oViewModel.getProperty("/shareSendEmailMessage")
				);
			},*/

		/**
		 * Event handler when the share in JAM button has been clicked
		 * @public
		 */
		/*	onShareInJamPress : function () {
				var oViewModel = this.getModel("detailView"),
					oShareDialog = sap.ui.getCore().createComponent({
						name : "sap.collaboration.components.fiori.sharing.dialog",
						settings : {
							object :{
								id : location.href,
								share : oViewModel.getProperty("/shareOnJamTitle")
							}
						}
					});

				oShareDialog.open();
			},
*/
		/**
		 * Updates the item count within the line item table's header
		 * @param {object} oEvent an event containing the total number of items in the list
		 * @private
		 */
		/*	onListUpdateFinished : function (oEvent) {
				var sTitle,
					iTotalItems = oEvent.getParameter("total"),
					oViewModel = this.getModel("detailView");

				// only update the counter if the length is final
				if (this.byId("lineItemsList").getBinding("items").isLengthFinal()) {
					if (iTotalItems) {
						sTitle = this.getResourceBundle().getText("detailLineItemTableHeadingCount", [iTotalItems]);
					} else {
						//Display 'Line Items' instead of 'Line items (0)'
						sTitle = this.getResourceBundle().getText("detailLineItemTableHeading");
					}
					oViewModel.setProperty("/lineItemListTitle", sTitle);
				}
			},
*/
		/* =========================================================== */
		/* begin: internal methods                                     */
		/* =========================================================== */

		/**
		 * Binds the view to the object path and expands the aggregated line items.
		 * @function
		 * @param {sap.ui.base.Event} oEvent pattern match event in route 'object'
		 * @private
		 */
		/*	_onObjectMatched : function (oEvent) {
				var sObjectId =  oEvent.getParameter("arguments").objectId;
				this.getModel().metadataLoaded().then( function() {
					var sObjectPath = this.getModel().createKey("SesHeaderSet", {
						Ebeln :  sObjectId
					});
					this._bindView("/" + sObjectPath);
				}.bind(this));
			},*/

		/**
		 * Binds the view to the object path. Makes sure that detail view displays
		 * a busy indicator while data for the corresponding element binding is loaded.
		 * @function
		 * @param {string} sObjectPath path to the object to be bound to the view.
		 * @private
		 */
		/*	_bindView : function (sObjectPath) {
				// Set busy indicator during view binding
				var oViewModel = this.getModel("detailView");

				// If the view was not bound yet its not busy, only if the binding requests data it is set to busy again
				oViewModel.setProperty("/busy", false);

				this.getView().bindElement({
					path : sObjectPath,
					events: {
						change : this._onBindingChange.bind(this),
						dataRequested : function () {
							oViewModel.setProperty("/busy", true);
						},
						dataReceived: function () {
							oViewModel.setProperty("/busy", false);
						}
					}
				});
			},
*/
		/*	_onBindingChange : function () {
				var oView = this.getView(),
					oElementBinding = oView.getElementBinding();

				// No data for the binding
				if (!oElementBinding.getBoundContext()) {
					this.getRouter().getTargets().display("detailObjectNotFound");
					// if object could not be found, the selection in the master list
					// does not make sense anymore.
					this.getOwnerComponent().oListSelector.clearMasterListSelection();
					return;
				}

				var sPath = oElementBinding.getPath(),
					oResourceBundle = this.getResourceBundle(),
					oObject = oView.getModel().getObject(sPath),
					sObjectId = oObject.Ebeln,
					sObjectName = oObject.Ebeln,
					oViewModel = this.getModel("detailView");

				this.getOwnerComponent().oListSelector.selectAListItem(sPath);

				oViewModel.setProperty("/saveAsTileTitle",oResourceBundle.getText("shareSaveTileAppTitle", [sObjectName]));
				oViewModel.setProperty("/shareOnJamTitle", sObjectName);
				oViewModel.setProperty("/shareSendEmailSubject",
					oResourceBundle.getText("shareSendEmailObjectSubject", [sObjectId]));
				oViewModel.setProperty("/shareSendEmailMessage",
					oResourceBundle.getText("shareSendEmailObjectMessage", [sObjectName, sObjectId, location.href]));
			},*/

		/*	_onMetadataLoaded : function () {
				// Store original busy indicator delay for the detail view
				var iOriginalViewBusyDelay = this.getView().getBusyIndicatorDelay(),
					oViewModel = this.getModel("detailView"),
					oLineItemTable = this.byId("lineItemsList"),
					iOriginalLineItemTableBusyDelay = oLineItemTable.getBusyIndicatorDelay();

				// Make sure busy indicator is displayed immediately when
				// detail view is displayed for the first time
				oViewModel.setProperty("/delay", 0);
				oViewModel.setProperty("/lineItemTableDelay", 0);

				oLineItemTable.attachEventOnce("updateFinished", function() {
					// Restore original busy indicator delay for line item table
					oViewModel.setProperty("/lineItemTableDelay", iOriginalLineItemTableBusyDelay);
				});

				// Binding the view will set it to not busy - so the view is always busy if it is not bound
				oViewModel.setProperty("/busy", true);
				// Restore original busy indicator delay for the detail view
				oViewModel.setProperty("/delay", iOriginalViewBusyDelay);
			}*/

	});

});