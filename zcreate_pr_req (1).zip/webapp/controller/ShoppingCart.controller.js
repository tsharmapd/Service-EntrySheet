sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/core/routing/History",
	"sap/m/MessageBox"
], function(Controller,History,MessageBox) {
	"use strict";

	return Controller.extend("pr.req.controller.ShoppingCart", {
		
		
		onInit:function(){
			
	var oModel= this.getOwnerComponent().getModel();
	var oJSONModel = this.getOwnerComponent().getModel("json");
	var oTable= this.getView().byId("cartTable");
	oModel.read("/DraftitemsSet", {
					success: function(r) {
						oTable.setBusy(false);
					 oJSONModel.setProperty("/cartModel", r.results);
					},
					error: function() {
                        oTable.setBusy(false);
						MessageBox.error("Unable to delete records from cartData. Please try again.");
					}
				});
		},
		
			onNavBack: function() {
			var sPreviousHash = History.getInstance().getPreviousHash(),
				oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation");

			if (sPreviousHash !== undefined || !oCrossAppNavigator.isInitialNavigation()) {
				history.go(-1);
			} else {
				oCrossAppNavigator.toExternal({
					target: {
						shellHash: "#Shell-home"
					}
				});
			}
		}
/*	onNavBack:function(){
		this.getRouter().navTo("object",true);	var oHistory = History.getInstance();
			var sPreviousHash = oHistory.getPreviousHash();

			if (sPreviousHash !== undefined) {
				window.history.go(-1);
			} else {
				var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
				oRouter.navTo("object", true);
			}
		}
	*/
	

	
		//	}

	});

});