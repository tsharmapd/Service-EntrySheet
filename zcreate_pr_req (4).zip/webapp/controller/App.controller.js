sap.ui.define([
		"pr/req/controller/BaseController",
		"sap/ui/model/json/JSONModel",
		"sap/ui/model/Filter",
		"sap/m/MessageBox"
	], function(BaseController, JSONModel, Filter, MessageBox) {
		"use strict";

		return BaseController.extend("pr.req.controller.App", {
			onBeforeRendering: function() {
			
			/*	var oModel = this.getOwnerComponent().getModel();
				var that = this;
				var oJSONModel = new JSONModel({});
			
				oModel.read("/CheckflagSet('X')", {
					success: function(r) {
						var data = r;

						oJSONModel.setProperty("/flag", data);
						if (data.Flag === "X") {
							if (!that.oMessageDialog) {
								that.oMessageDialog = sap.ui.xmlfragment("pr.req.view.messageDialog", that);
								that.getView().addDependent(that.oMessageDialog);
					}					// forward compact/cozy style into Dialog
							that.oMessageDialog.addStyleClass(that.getOwnerComponent().getContentDensityClass());
						that.oMessageDialog.open();
                       	}			
				},

					error: function() {

						MessageBox.error("Unable to retrieve data for flag. Please try again.");
					}
				});*/
			},
			onAfterRendering: function() {
			/*	var oModel = this.getOwnerComponent().getModel();
				var oJSONModel = this.getOwnerComponent().getModel("json");
				oModel.read("/DraftitemsSet", {
					success: function(r) {
						var data = r;

						oJSONModel.setProperty("/cartModel", data.results);

					},

					error: function() {

						MessageBox.error("Unable to retrieve data for flag. Please try again.");
					}
				});
*/
			},
		/*	onContinueToCartPress: function() {
				var cartId = "cartId";
				this.getOwnerComponent().getRouter().navTo("cart", {
					cartId: cartId
				});

			

			},*/
		//	onDiscard: function() {
		//		var oModel = this.getOwnerComponent().getModel();
			//	var oJSONModel = this.getOwnerComponent().getModel("json");

			//	var oRecord = this.getView().getModel("json").getData().cartModel[0];
				
				


			

			//	var delData = {};
				/*delData.Carrier = oRecord.Carrier;
				delData.Contn = oRecord.Contn;
				delData.Dploc = oRecord.Dploc;
				delData.Ebelp = oRecord.Ebelp;*/
			//	delData.Guid =	oRecord.Guid;
				/*	delData.Image = oRecord.Image;
					delData.Knttp = oRecord.Knttp;
					delData.Lfdat = oRecord.Lfdat;
					delData.Maktx = oRecord.Maktx;
					delData.Matkl = oRecord.Matkl;
					delData.Matnr = oRecord.Matnr;
					delData.Menge = oRecord.Menge;
					delData.Mfrnr = oRecord.Mfrnr;
					delData.Preis = oRecord.Preis;
					delData.Text = oRecord.Text;
					delData.Uom = oRecord.Uom;
					delData.Verpr = oRecord.Verpr;
					delData.Waers = oRecord.Waers;*/
				//	var srecord =oRecord.Guid ;

            // var actGuid = srecord.replace(/'/g, '\'');

			/*	oModel.remove("/DraftitemsSet('" + srecord + "')", delData, {
					success: function(data,response) {
					MessageBox.success("Draft item successfully removed ");	

					},
					error: function() {

						MessageBox.error("Unable to delete records from cartData. Please try again.");
					}
				});
				oJSONModel.refresh();
				this.oMessageDialog.close();
			}*/

			/*	onShoppingCartPressed: function() {
					var that = this;
					if (!that._oShoppingCartDialog) {
									that._oShoppingCartDialog = sap.ui.xmlfragment("pr.req.view.ShoppingCart", that);
									that.getView().addDependent(that._oShoppingCartDialog);

								}
								// forward compact/cozy style into Dialog
							//	this._oCartDialog.addStyleClass(that.getOwnerComponent().getContentDensityClass());

							that._oShoppingCartDialog.open();
				}
					*/

			//////OnInit std app logic/////
			/*	var oViewModel,
				fnSetAppNotBusy,
				oListSelector = this.getOwnerComponent().oListSelector,
				iOriginalBusyDelay = this.getView().getBusyIndicatorDelay();

			oViewModel = new JSONModel({
				busy : true,
				delay : 0
			});
			this.setModel(oViewModel, "appView");

			fnSetAppNotBusy = function() {
				oViewModel.setProperty("/busy", false);
				oViewModel.setProperty("/delay", iOriginalBusyDelay);
			};

			this.getOwnerComponent().getModel().metadataLoaded()
					.then(fnSetAppNotBusy);

			// Makes sure that master view is hidden in split app
			// after a new list entry has been selected.
			oListSelector.attachListSelectionChange(function () {
				this.byId("idAppControl").hideMaster();
			}, this);*/

			// apply content density mode to root view
			//	this.getView().addStyleClass(this.getOwnerComponent().getContentDensityClass());

		});

	}

);