/*global locatiFonFav */
sap.ui.define([
	"pr/req/controller/BaseController",
	"sap/ui/model/json/JSONModel",
	"pr/req/model/formatter",
	"sap/m/MessageBox",
	"sap/ui/model/Filter"

], function(BaseController, JSONModel, formatter, MessageBox, Filter) {
	"use strict";

	return BaseController.extend("pr.req.controller.Detail", {

		formatter: formatter,

		onBeforeRendering: function() {
			var oModel = this.getOwnerComponent().getModel();
			var that = this;
			var oJSONModel = new JSONModel({});

			oModel.read("/CheckflagSet('X')", {
				success: function(r) {
					var data = r;

					oJSONModel.setProperty("/flag", data);
					if (data.Flag === "X") {
						if (!that.oMessageDialog) {
							that.oMessageDialog = sap.ui.xmlfragment("pr.req.view.messageDialog", that);
							that.getView().addDependent(that.oMessageDialog);
						} // forward compact/cozy style into Dialog
						that.oMessageDialog.addStyleClass(that.getOwnerComponent().getContentDensityClass());
						that.oMessageDialog.open();
					}
				},

				error: function() {

					MessageBox.error("Unable to retrieve data for flag. Please try again.");
				}
			});

			oModel.read("/CheckflagSet('X')", {
				success: function(r) {
					oJSONModel.setProperty("/Flag", r);
				}
			});
		},
		onContinueToCartPress: function() {
			var cartId = "cartId";
			this.getOwnerComponent().getRouter().navTo("cart", {
				cartId: cartId
			});
		},
		onDiscard: function() {
			var oModel = this.getOwnerComponent().getModel();
			var oJSONModel = this.getOwnerComponent().getModel("json");

			var oRecord = this.getView().getModel("json").getData().cartModel[0];

			var delData = {};

			delData.Guid = oRecord.Guid;

			var srecord = oRecord.Guid;

			oModel.remove("/DraftitemsSet('" + srecord + "')", delData, {
				success: function(data, response) {
					MessageBox.success("Draft item successfully removed ");
					oModel.read("/CheckflagSet('X')", {
						success: function(r) {
							oJSONModel.setProperty("/Flag", r);
						}
					});
					oJSONModel.refresh("true");

				},
				error: function() {

					MessageBox.error("Unable to delete records from cartData. Please try again.");
				}
			});
			oJSONModel.refresh();
			this.oMessageDialog.close();
		},

		/**/
		/* =========================================================== */
		/* lifecycle methods                                           */
		/* =========================================================== */

		onInit: function(oEvent) {
		//	this.getOwnerComponent().getRouter().getRoute("object").attachPatternMatched(this._onPatternMatched, this);

			var oModel = this.getOwnerComponent().getModel();
			var oJSONModel = this.getOwnerComponent().getModel("json");

			oModel.read("/FavoriteSet", {
				success: function(r) {
					oJSONModel.setProperty("/favSelctdModel", r.results);

				}
			});
			oModel.read("/DraftitemsSet", {
				success: function(r, s) {

					oJSONModel.setProperty("/cartModel", r.results);

				}
			});

		},

		onSearchPressed: function(oEvent) {

			this.sSearch = oEvent.getParameter("query");
			//	this.sFilters = this.getView().getModel("json").getData().filterValues;
			//	this.Matkl = this.sFilters.Matkl;
			//	this.Mfrnr = this.sFilters.Mfrnr;
			//	this.Mfrpn = this.sFilters.Mfrpn;
			var oModel = this.getView().getModel();
			var oJSONModel = this.getView().getModel("json");
			oModel.read("/SearchItemsSet", {
				filters: [new Filter("Matkl", "EQ", ""), new Filter("Mfrnr", "EQ",
					""), new Filter("Mfrpn", "EQ", ""), new Filter("Matnr", "EQ", this.sSearch)],
				success: function(r) {

					oJSONModel.setProperty("/tablebindingModel", r.results);
					oJSONModel.refresh(true);
					/*	for (var i = 0; i < oJSONModel.getProperty("/favSelctdModel").length; i++) {
				if (oJSONModel.getProperty("/favSelctdModel")[i][0].Matnr !== undefined) {
				 
						for (var j = 0; j < oJSONModel.getProperty("/tablebindingModel")[j].length; j++) {
							if (oJSONModel.getProperty("/favSelctdModel")[i][j].Matnr === oJSONModel.getProperty("/tablebindingModel")[i][j].Matnr) {
							//	del.push(oJSONModel.getProperty("/payloadDatas").documentTab[i][j]);
							var setflag = "true";
							}
							else{
								var setflag ="false";
							}
						}
					
						oJSONModel.refresh(true);
					}
				}*/
				},
				error: function() {

				}
			});

			//	this._oTableOperations.setSearchTerm(sSearch);
			//	this._oTableOperations.applyTableOperations();
		},

		onDeletePressed: function(oEvent) {
			var sobjData = oEvent.getParameter("listItem").getBindingContext("json").getObject();
			var oModel = this.getOwnerComponent().getModel();
			oModel.remove("/DraftitemsSet", sobjData, {

			});
		},

		onShoppingCartPressed: function(oEvent) {

			//	var oView= this;
			if (!this.ocartPress) {
				this.ocartPress = sap.ui.xmlfragment("pr.req.view.ShoppingCart", this);
				this.getView().addDependent(this.ocartPress);

				var oJSONModel = this.getOwnerComponent().getModel("json");
				//	this._oShopDialog.bindItems("/cartModel");				
				this.ocartPress.setModel(oJSONModel);

			}

			this.ocartPress.open();
		},
		onCartDialogDeletePress:function(oEvent){
			var sDelete = oEvent.getSource().getParent().getBindingContext("json").getObject();
		},

		cancel: function() {

			this.ocartPress.close();

		},
		getRouter: function() {
			return sap.ui.core.UIComponent.getRouterFor(this);
		},

		ViewCart: function(oEvt) {
			var cartId = "cartId";
			this.getOwnerComponent().getRouter().navTo("cart", {
				cartId: cartId
			});
		},

		onQckviewPressed: function(oEvent) {
			if (!this.oQckVwdialog) {
				this.oQckVwdialog = sap.ui.xmlfragment("pr.req.view.QuickView", this);

			}
			var sObject = oEvent.getSource().getParent().getBindingContext("json").getObject();
			var oJSONModel = this.getOwnerComponent().getModel("json");

			oJSONModel.setProperty("/QckvwModel", sObject);
			this.oQckVwdialog.setModel(oJSONModel);
			this.oQckVwdialog.bindElement("/QckvwModel");
			this.oQckVwdialog.openBy(oEvent.getSource());
		},

		onFavoriteSelection: function(oEvent) {
			var state = oEvent.getSource().getPressed();
			this.setflag = "X";
			this.setevent = "";
			if (state==false) {
				this.setflag = "Y";
				var favObj = oEvent.getSource().getParent().getBindingContext("json").getObject();
				var sfavorite = {};

				sfavorite.Maktx = favObj.Maktx;
				sfavorite.Matkl = favObj.Matkl;
				sfavorite.Matnr = favObj.Matnr;
				sfavorite.Menge = favObj.Menge;
				sfavorite.Mfrnr = favObj.Mfrnr;
				//  sfavorite.Fav = favObj.Fav;
				sfavorite.Uom = favObj.Uom;
				sfavorite.Verpr = favObj.Verpr;
				sfavorite.Waers = favObj.Waers;

				var oModel = this.getOwnerComponent().getModel();
				var oJSONModel = this.getOwnerComponent().getModel("json");

				oModel.create("/FavoriteSet", sfavorite, {
					success: function(oData, oResponse) {
						MessageBox.success(oResponse.data.Text);
					},
					error: function() {

					}
				});
			}

			if (state==true) {
				var oModel = this.getOwnerComponent().getModel();

				var unfavObj = oEvent.getSource().getParent().getBindingContext("json").getObject();
				var unfavorite = {};

				/*	unfavorite.Maktx = unfavObj.Maktx;
					unfavorite.Matkl = unfavObj.Matkl;*/
				unfavorite.Matnr = unfavObj.Matnr;
				/*unfavorite.Menge = unfavObj.Menge;
				unfavorite.Mfrnr = unfavObj.Mfrnr;

				unfavorite.Uom = unfavObj.Uom;
				unfavorite.Verpr = unfavObj.Verpr;
				unfavorite.Waers = unfavObj.Waers;*/

				oModel.remove("/FavoriteSet('" + unfavObj.Matnr + "')", unfavorite, {
					success: function(oData, oResponse) {
						MessageBox.success(oResponse.data.Text);
					},
					error: function() {

					}
				});
			}

		},

		onAddToCartPressed: function(oEvent) {
		//	var oJSONModel = this.getOwnerComponet().getModel();
			//	/var qty = this.getView().byId("QtyId").getValue();
			var scombSlctd= this.byId("selComb").getSelectedKey();
			

			var objData = oEvent.getSource().getParent().getBindingContext("json").getObject();
			if (objData.Menge === "0.000") {

				MessageBox.error("Please choose the No.of Quantities to order.");
			} else {
				var cartData = {};

				cartData.Ebelp = "00010";
				cartData.Knttp =
				cartData.Maktx = objData.Maktx;
				cartData.Matkl = objData.Matkl;
				cartData.Matnr = objData.Matnr;
				cartData.Menge = objData.Menge;
				cartData.Mfrnr = objData.Mfrnr;
				//	
				cartData.Uom = objData.Uom;
				cartData.Verpr = objData.Verpr;
				cartData.Waers = objData.Waers;

				var oModel = this.getOwnerComponent().getModel();
				var oJSONModel = this.getOwnerComponent().getModel("json");

				oModel.create("/DraftitemsSet", cartData, {
					success: function(oData, oResponse) {
						MessageBox.success(oResponse.data.Text);

						oModel.read("/CheckflagSet('X')", {
							success: function(r) {
								oJSONModel.setProperty("/Flag", r);

							}
						});
						oModel.read("/DraftitemsSet", {
							success: function(r, s) {

								oJSONModel.setProperty("/cartModel", r.results);
							}
						});

						oJSONModel.refresh("true");
					},
					error: function() {

					}
				});

			}
		}

		/*	onCartSrvSuccess: function(oEvent) {
				var oModel = this.getOwnerComponent().getModel();
				var sKey = oModel.createKey("/DraftitemsSet",o               {
				});
				var sProductName = oModel.getProperty(sKey).Name;
			
		    	this._oHeaderButton = this.getView().byId("headerCartBtn");
				this._oHeaderButton.getElementBinding().refresh();
			}*/

		//var cartId="cartId";
		/*	this.getRouter().navTo("cart", {
				cartId: cartId*/
		//	});

		//	_oShopDialog.$().offset({top : "100", right : "100"});

		//	var getKey = oJSONModel.Filtervalue[0].results;                         
		/*		var oList;
				var Selected= true;
		var oView = this.getView();
		var listS;
		var aListIds = ["catlgList", "EquipList", "PrevReqList"];
		if (oEvent) {
			oList = oEvent.getSource();
			aListIds.forEach(function(sId) {
				oView.byId(sId).setSelected(false);
			});
			oList.setSelected(true);
			listS = oList;
		} else {
			aListIds.forEach(function(sId) {
				if (oView.byId(sId).getSelected()) {
					oList = oView.byId(sId);
				}
			});
			listS = aListIds;
		}
			
				var sFilterValue = "Matkl";
					if (oList.getId().indexOf("catlgList") !== -1) {
			sFilterValue = "Matkl";
		} else if (oList.getId().indexOf("EquipList") !== -1) {
			sFilterValue = "Mfrnr";
		}/* else if (oList.getId().indexOf("PrevReqList") !== -1) {
			sFilterValue = "COMP";
		}*/

		/*	var oFilter = new Filter("sFilterValue", "EQ", sFilterValue);
		//	this._populateOverviewTable(oFilter, tilesS);
					var oTable = this.getView().byId("Table");
					var oModel= this.getOwnerComponent().getModel();
					var oJSONModel = this.getOwnerComponent().getModel("json");
				oModel.read("/SearchItemsSet", {
					filters:[oFilter],
					success: function(r) {
						oTable.setBusy(false);
					 oJSONModel.setProperty("/tablebindingModel", r.results);
						var iRows = r.results.length;
					if (iRows > 10) {
						oTable.setVisibleRowCount(10);
					} else if (iRows > 0 && iRows < 11) {
						oTable.setVisibleRowCount(iRows);
					} else if (iRows === 0 || !iRows) {
						oTable.setVisibleRowCount(1);
					}
				
		
					},*/

		// Model used to manipulate control states. The chosen values make sure,
		// detail page is busy indication immediately so there is no break in
		// between the busy indication for loading the view's meta data
		//	var oViewModel = new JSONModel({
		//	busy : false,
		//	delay : 0,
		//	lineItemListTitle : this.getResourceBundle().getText("detailLineItemTableHeading")
		//	});

		//	this.getRouter().getRoute("object").attachPatternMatched(this._onObjectMatched, this);

		//	this.setModel(oViewModel, "detailView");

		//this.getOwnerComponent().getModel().metadataLoaded().then(this._onMetadataLoaded.bind(this));

		/* =========================================================== */
		/* event handlers                                              */
		/* =========================================================== */

		/**
		 * Event handler when the share by E-Mail button has been clicked
		 * @public
		 */
		/*	onShareEmailPress : function () {
				var oViewModel = this.getModel("detailView");

				sap.m.URLHelper.triggerEmail(
					null,
					oViewModel.getProperty("/shareSendEmailSubject"),
					oViewModel.getProperty("/shareSendEmailMessage")
				);
			},*/

		/**
		 * Event handler when the share in JAM button has been clicked
		 * @public
		 */
		/*	onShareInJamPress : function () {
				var oViewModel = this.getModel("detailView"),
					oShareDialog = sap.ui.getCore().createComponent({
						name : "sap.collaboration.components.fiori.sharing.dialog",
						settings : {
							object :{
								id : location.href,
								share : oViewModel.getProperty("/shareOnJamTitle")
							}
						}
					});

				oShareDialog.open();
			},
*/
		/**
		 * Updates the item count within the line item table's header
		 * @param {object} oEvent an event containing the total number of items in the list
		 * @private
		 */
		/*	onListUpdateFinished : function (oEvent) {
				var sTitle,
					iTotalItems = oEvent.getParameter("total"),
					oViewModel = this.getModel("detailView");

				// only update the counter if the length is final
				if (this.byId("lineItemsList").getBinding("items").isLengthFinal()) {
					if (iTotalItems) {
						sTitle = this.getResourceBundle().getText("detailLineItemTableHeadingCount", [iTotalItems]);
					} else {
						//Display 'Line Items' instead of 'Line items (0)'
						sTitle = this.getResourceBundle().getText("detailLineItemTableHeading");
					}
					oViewModel.setProperty("/lineItemListTitle", sTitle);
				}
			},
*/
		/* =========================================================== */
		/* begin: internal methods                                     */
		/* =========================================================== */

		/**
		 * Binds the view to the object path and expands the aggregated line items.
		 * @function
		 * @param {sap.ui.base.Event} oEvent pattern match event in route 'object'
		 * @private
		 */
		/*	_onObjectMatched : function (oEvent) {
				var sObjectId =  oEvent.getParameter("arguments").objectId;
				this.getModel().metadataLoaded().then( function() {
					var sObjectPath = this.getModel().createKey("SesHeaderSet", {
						Ebeln :  sObjectId
					});
					this._bindView("/" + sObjectPath);
				}.bind(this));
			},*/

		/**
		 * Binds the view to the object path. Makes sure that detail view displays
		 * a busy indicator while data for the corresponding element binding is loaded.
		 * @function
		 * @param {string} sObjectPath path to the object to be bound to the view.
		 * @private
		 */
		/*	_bindView : function (sObjectPath) {
				// Set busy indicator during view binding
				var oViewModel = this.getModel("detailView");

				// If the view was not bound yet its not busy, only if the binding requests data it is set to busy again
				oViewModel.setProperty("/busy", false);

				this.getView().bindElement({
					path : sObjectPath,
					events: {
						change : this._onBindingChange.bind(this),
						dataRequested : function () {
							oViewModel.setProperty("/busy", true);
						},
						dataReceived: function () {
							oViewModel.setProperty("/busy", false);
						}
					}
				});
			},
*/
		/*	_onBindingChange : function () {
				var oView = this.getView(),
					oElementBinding = oView.getElementBinding();

				// No data for the binding
				if (!oElementBinding.getBoundContext()) {
					this.getRouter().getTargets().display("detailObjectNotFound");
					// if object could not be found, the selection in the master list
					// does not make sense anymore.
					this.getOwnerComponent().oListSelector.clearMasterListSelection();
					return;
				}

				var sPath = oElementBinding.getPath(),
					oResourceBundle = this.getResourceBundle(),
					oObject = oView.getModel().getObject(sPath),
					sObjectId = oObject.Ebeln,
					sObjectName = oObject.Ebeln,
					oViewModel = this.getModel("detailView");

				this.getOwnerComponent().oListSelector.selectAListItem(sPath);

				oViewModel.setProperty("/saveAsTileTitle",oResourceBundle.getText("shareSaveTileAppTitle", [sObjectName]));
				oViewModel.setProperty("/shareOnJamTitle", sObjectName);
				oViewModel.setProperty("/shareSendEmailSubject",
					oResourceBundle.getText("shareSendEmailObjectSubject", [sObjectId]));
				oViewModel.setProperty("/shareSendEmailMessage",
					oResourceBundle.getText("shareSendEmailObjectMessage", [sObjectName, sObjectId, location.href]));
			},*/

		/*	_onMetadataLoaded : function () {
				// Store original busy indicator delay for the detail view
				var iOriginalViewBusyDelay = this.getView().getBusyIndicatorDelay(),
					oViewModel = this.getModel("detailView"),
					oLineItemTable = this.byId("lineItemsList"),
					iOriginalLineItemTableBusyDelay = oLineItemTable.getBusyIndicatorDelay();

				// Make sure busy indicator is displayed immediately when
				// detail view is displayed for the first time
				oViewModel.setProperty("/delay", 0);
				oViewModel.setProperty("/lineItemTableDelay", 0);

				oLineItemTable.attachEventOnce("updateFinished", function() {
					// Restore original busy indicator delay for line item table
					oViewModel.setProperty("/lineItemTableDelay", iOriginalLineItemTableBusyDelay);
				});

				// Binding the view will set it to not busy - so the view is always busy if it is not bound
				oViewModel.setProperty("/busy", true);
				// Restore original busy indicator delay for the detail view
				oViewModel.setProperty("/delay", iOriginalViewBusyDelay);
			}*/

	});

});