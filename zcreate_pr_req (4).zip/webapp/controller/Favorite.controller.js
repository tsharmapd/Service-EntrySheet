sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function(Controller) {
	"use strict";

	return Controller.extend("pr.req.controller.Favorite", {
		

	onInit:function(){
		var  oModel = this.getOwnerComponent().getModel();
		var oJSONModel = this.getOwnerComponent().getModel("json");
		
		oModel.read("/FavoriteSet",{
			success:function(r){
				oJSONModel.setProperty("/favSelctdModel",r.results);
			}
		});
	//	this.getView().byId("favTable").setModel(oJSONModel);
	//	this.getView().byId("favTable").setModel("tablebindingModel");
	},
		getRouter: function() {
			return sap.ui.core.UIComponent.getRouterFor(this);
		},
	onFavNavBack:function(){
			var objId = "objectId";
			this.getRouter().navTo("object", {
				objectId: objId
			});
		}
	

		/**
		 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
		 * (NOT before the first rendering! onInit() is used for that one!).
		 * @memberOf pr.req.view.Favorite
		 */
		//	onBeforeRendering: function() {
		//
		//	},

		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf pr.req.view.Favorite
		 */
		//	onAfterRendering: function() {
		//
		//	},

		/**
		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		 * @memberOf pr.req.view.Favorite
		 */
		//	onExit: function() {
		//
		//	}

	});

});