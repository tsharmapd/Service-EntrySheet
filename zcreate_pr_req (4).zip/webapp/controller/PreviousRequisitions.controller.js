sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function(Controller) {
	"use strict";

	return Controller.extend("pr.req.controller.PreviousRequisitions", {

		onInit: function() {
			var oModel = this.getOwnerComponent().getModel();
			var oJSONModel = this.getOwnerComponent().getModel("json");
			oModel.read("/PrevitemsSet", {
				success: function(r) {
					oJSONModel.setProperty("/prevTableModel", r.results);
				}
			});
		},
		onPrevNavBack: function() {
			var objId = "objectId";
			this.getRouter().navTo("object", {
				objectId: objId
			});
		},
		onPrevReqAddtoCartPress: function(oEvent) {
		
			var oJSONModel = this.getOwnerComponent().getModel("json");
	      	var oMaster={};
			var Items = [];
			var oTable = this.byId('idProductsTable');
			var selectedItems = oTable.getSelectedItems();

			for (var i = 0; i < selectedItems.length; i++) {
            /*	if (oMaster.Guid == null) {
					// create header	///P///	
					oMaster.Flag = "P";
					oMaster.Guid = "X";
				}*/
		
                Items.push({
                "Banfn" : selectedItems[i].getCells()[0].getText(),
				"Knttp" :selectedItems[i].getCells()[1].getText(),
				"Matnr" : selectedItems[i].getCells()[2].getText(),
				"Txz01" : selectedItems[i].getCells()[3].getText(),
				"Verpr" : selectedItems[i].getCells()[4].getText(),
				"Menge" : selectedItems[i].getCells()[5].getText(),
			    "Lfdat" : selectedItems[i].getCells()[7].getText(),
				"Matkl" : selectedItems[i].getCells()[8].getText()	
                });
			
				
			}

			oJSONModel.setProperty("/Payload", Items);

		

			var oModel = this.getOwnerComponent().getModel("json").getData().Payload;
		//	var oTable = this.byId("idProductsTable").getItems();
			//store all the context/contextPath of the table in an array
			var oMaster = {};
			var oItemData = [];
			for (var i = 0; i < oModel.length; i++) {
				if (oMaster.Guid == null) {
					// create header	///P///	
					oMaster.Flag = "P";
					oMaster.Guid = "X";
				}
				//create item 
				var oDetail = {};
			//	oDetail.Guid = oModel[i].Guid;
			//	oDetail.Ebelp = oModel[i].Ebelp;
				oDetail.Matnr = oModel[i].Matnr;
				oDetail.Maktx = oModel[i].Maktx;
			//	oDetail.Uom = oModel[i].Uom;
		/*	if(oModel[i].Verpr!==Null){
				oDetail.Verpr = oModel[i].Verpr;
			}*/
				
				oDetail.Waers = oModel[i].Waers;
				oDetail.Matkl = oModel[i].Matkl;
				oDetail.Knttp = oModel[i].Knttp;
				oDetail.Menge = oModel[i].Menge;
			//	oDetail.Lfdat = oModel[i].Lfdat;
				oItemData.push(oDetail);
			}

			// insert item data into header data
			oMaster.nav_htoi = oItemData;
			//get model instance

			var oModelMain = this.getOwnerComponent().getModel();
			//set http header with tokem fetch
			oModelMain.setHeaders({
				"Access-Control-Allow-Origin": "*",
				"Content-Type": "application/x-www-form-urlencoded",
				"X-CSRF-Token": "Fetch"
			});
			//fetch token and get reponse
			var token;
			oModelMain.read('/DraftitemsSet', null, null, false, function(oData, oResponse) {
					token = oResponse.headers['x-csrf-token'];
				},
				function() {
					alert("Error while reading");
				});
			//set http header for POST rest with token fetched from read
			oModelMain.setHeaders({
				"X-Requested-With": "XMLHttpRequest",
				"Content-Type": "application/json",
				"DataServiceVersion": "2.0",
				"Accept": "application/atom+xml,application/atomsvc+xml,application/xml",
				"X-CSRF-Token": token
			});
			//call POST method
			sap.ui.core.BusyIndicator.show(0);
			var that = this;
			oModelMain.create("/CheckflagSet", oMaster, {
				success: function(oData, oResponse) {
					// Success
					sap.ui.core.BusyIndicator.hide();
					var oMsg = oResponse.headers;
					//	var oEsheet = oResponse.data.Name1;
					var jsonStr = oMsg["sap-message"];
					sap.m.MessageToast.show((JSON.parse(jsonStr).message));
				}
			});
		}

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf pr.req.view.PreviousRequisitions
		 */
		//	onInit: function() {
		//
		//	},

		/**
		 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
		 * (NOT before the first rendering! onInit() is used for that one!).
		 * @memberOf pr.req.view.PreviousRequisitions
		 */
		//	onBeforeRendering: function() {
		//
		//	},

		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf pr.req.view.PreviousRequisitions
		 */
		//	onAfterRendering: function() {
		//
		//	},

		/**
		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		 * @memberOf pr.req.view.PreviousRequisitions
		 */
		//	onExit: function() {
		//
		//	}

	});

});