sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/core/routing/History",
	"sap/m/MessageBox"
], function(Controller, History, MessageBox) {
	"use strict";

	return Controller.extend("pr.req.controller.ShoppingCart", {

		onInit: function() {
			this.getView().byId("cntcLbl").setLayoutData(new sap.m.FlexItemData({
				alignSelf: sap.m.FlexAlignSelf.Center
			}));
			this.getView().byId("carLbl").setLayoutData(new sap.m.FlexItemData({
				alignSelf: sap.m.FlexAlignSelf.Center
			}));
			this.getView().byId("dflocLbl").setLayoutData(new sap.m.FlexItemData({
				alignSelf: sap.m.FlexAlignSelf.Center
			}));

			var oModel = this.getOwnerComponent().getModel();
			var oJSONModel = this.getOwnerComponent().getModel("json");
			var oTable = this.getView().byId("cartTable");
			sap.ui.core.BusyIndicator.show(0);
			oModel.read("/DraftitemsSet", {
				success: function(r) {
					//	oTable.setBusy(false);
					sap.ui.core.BusyIndicator.hide();
					oJSONModel.setProperty("/cartModel", r.results);
				},
				error: function() {
					//    oTable.setBusy(false);
					MessageBox.error("Unable to get records from cartData. Please try again.");
				}
			});
			oModel.read("/CheckflagSet('X')", {
				success: function(r) {
					oJSONModel.setProperty("/Flag", r);
				}
			});
		},

		onNavBack: function() {
			var sPreviousHash = History.getInstance().getPreviousHash(),
				oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation");

			if (sPreviousHash !== undefined || !oCrossAppNavigator.isInitialNavigation()) {
				history.go(-1);
			} else {
				oCrossAppNavigator.toExternal({
					target: {
						shellHash: "#Shell-home"
					}
				});
			}
		},
		onOrderPressed: function() {
			var oModel = this.getOwnerComponent().getModel("json").getData().cartModel;
			var oTable = this.byId("checkOutTable").getItems();
			//store all the context/contextPath of the table in an array
			var oMaster = {};
			var oItemData = [];
			for (var i = 0; i < oModel.length; i++) {
				if (oMaster.Guid == null) {
					// create header	///P///	
					oMaster.Flag = "X";
					oMaster.Guid = oModel[i].Guid;
				}
				//create item 
				var oDetail = {};
				oDetail.Guid = oModel[i].Guid;
				oDetail.Ebelp = oModel[i].Ebelp;
				oDetail.Matnr = oModel[i].Matnr;
				oDetail.Maktx = oModel[i].Maktx;
				oDetail.Uom = oModel[i].Uom;
				oDetail.Preis = oModel[i].Verpr;
				oDetail.Waers = oModel[i].Waers;
				oDetail.Matkl = oModel[i].Matkl;
				oDetail.Knttp = oModel[i].Knttp;
				oDetail.Menge = oModel[i].Menge;
				oDetail.Lfdat = oModel[i].Lfdat;
				oItemData.push(oDetail);
			}

			// insert item data into header data
			oMaster.nav_htoi = oItemData;
			//get model instance

			var oModelMain = this.getOwnerComponent().getModel();
			//set http header with tokem fetch
			oModelMain.setHeaders({
				"Access-Control-Allow-Origin": "*",
				"Content-Type": "application/x-www-form-urlencoded",
				"X-CSRF-Token": "Fetch"
			});
			//fetch token and get reponse
			var token;
			oModelMain.read('/DraftitemsSet', null, null, false, function(oData, oResponse) {
					token = oResponse.headers['x-csrf-token'];
				},
				function() {
					alert("Error while reading");
				});
			//set http header for POST rest with token fetched from read
			oModelMain.setHeaders({
				"X-Requested-With": "XMLHttpRequest",
				"Content-Type": "application/json",
				"DataServiceVersion": "2.0",
				"Accept": "application/atom+xml,application/atomsvc+xml,application/xml",
				"X-CSRF-Token": token
			});
			//call POST method
			sap.ui.core.BusyIndicator.show(0);
			var that = this;
			oModelMain.create("/CheckflagSet", oMaster, {
				success: function(oData, oResponse) {
					// Success
					sap.ui.core.BusyIndicator.hide();
					var oMsg = oResponse.headers;
					//	var oEsheet = oResponse.data.Name1;
					var jsonStr = oMsg["sap-message"];
					sap.m.MessageToast.show((JSON.parse(jsonStr).message)); ///////////
					//add create operation for uploading files to backend
					var oFileName = that.byId("attach");
					if (oFileName.getValue()) {
						var sPath = "/sap/opu/odata/sap/ZMM_ODATA_PR_NEW_SRV/DraftitemsSet";
						var sFileVal = oFileName.getValue();
						var sGuid = oMaster.Guid;

						var sUrl = sPath + "(Filename='" + sFileVal + "',sGuid='')/$value";
						oFileName.setUploadUrl(sUrl);
						oFileName.setSendXHR(true);

						//add header parameters
						that.getOwnerComponent().getModel().refreshSecurityToken();
						var file = jQuery.sap.domById(oFileName.getId() + "-fu").files[0];
						var base64_marker = 'data:' + file.type + ';base64,';
						var reader = new FileReader();
						reader.onload = (function(theFile) {
							return function(evt) {
								var base64Index = evt.target.result.indexOf(base64_marker) + base64_marker.length;
								var base64 = evt.target.result.substring(base64Index);
								var token = that.getOwnerComponent().getModel().getHeaders()['x-csrf-token'];
								$.ajaxSetup({
									cache: false
								});

								jQuery.ajax({
									url: sPath,
									async: false,
									dataType: 'json',
									cache: false,
									data: base64,
									type: "POST",
									beforeSend: function(xhr) {
										xhr.setRequestHeader("X-CSRF-Token", token);
										xhr.setRequestHeader("Content-Type", file.type);
										xhr.setRequestHeader("slug", sFileVal + ",");
									},
									success: function(odata) {
										oFileName.setValue("");
									}
								});
							};
						})(file);
						reader.readAsDataURL(file);

					} //get value from file if condition
				},
				error: function(oError) {
					// Error
					sap.ui.core.BusyIndicator.hide();
					jQuery.sap.require("sap.m.MessageBox");
					sap.m.MessageBox.show((JSON.parse(oError.responseText).error.message.value), {
						icon: sap.m.MessageBox.Icon.Information,
						title: "Message Box"
					});
				}
			});
		},
		onDeleteSelectedItemPressed:function(oEvent) {

			var oModel = this.getOwnerComponent().getModel();
			var oJSONModel = this.getOwnerComponent().getModel("json");
			var selctdItem = oEvent.getParameter("listItem").getBindingContext("json").getObject();

			var oRecord = this.getView().getModel("json").getData().cartModel[0];

			var delData = {};

			delData.Guid = oRecord.Guid;

			var srecord = oRecord.Guid;

			oModel.remove("/DraftitemsSet('" + selctdItem + "')", delData, {
				success: function(data, response) {
					MessageBox.success("Draft item successfully removed ");
					oModel.read("/CheckflagSet('X')", {
						success: function(r) {
							oJSONModel.setProperty("/Flag", r);
						}
					});
					oJSONModel.refresh("true");
				}
			});
		},

		///Attachment
		openAttachmentDialog: function() {
			if (!this.dialogAttachment) {
				this.dialogAttachment = sap.ui.xmlfragment("pr.req.view.AttachmentDialog", this);
			}
			this.dialogAttachment.open();
		},
		onAttachmentCancelPress: function() {
			this.dialogAttachment.close();
		},

		onAttachmentSubmitPress: function() {
			this.dialogAttachment.close();
		}

	});
});