jQuery.sap.require("sap.ui.qunit.qunit-css");
jQuery.sap.require("sap.ui.thirdparty.qunit");
jQuery.sap.require("sap.ui.qunit.qunit-junit");
QUnit.config.autostart = false;

sap.ui.require([
	"sap/ui/test/Opa5",
	"pr/req/test/integration/pages/Common",
	"sap/ui/test/opaQunit",
	"pr/req/test/integration/pages/App",
	"pr/req/test/integration/pages/Browser",
	"pr/req/test/integration/pages/Master",
	"pr/req/test/integration/pages/Detail",
	"pr/req/test/integration/pages/NotFound"
], function (Opa5, Common) {
	"use strict";
	Opa5.extendConfig({
		arrangements: new Common(),
		viewNamespace: "pr.req.view."
	});

	sap.ui.require([
		"pr/req/test/integration/NavigationJourneyPhone",
		"pr/req/test/integration/NotFoundJourneyPhone",
		"pr/req/test/integration/BusyJourneyPhone"
	], function () {
		QUnit.start();
	});
});