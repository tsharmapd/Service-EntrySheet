/*global locatiFonFav */
sap.ui.define([
	"pr/req/controller/BaseController",
	"sap/ui/model/json/JSONModel",
	"pr/req/model/formatter",
	"sap/m/MessageBox",
	"sap/ui/model/Filter",
	"sap/m/MessageToast"

], function(BaseController, JSONModel, formatter, MessageBox, Filter, MessageToast) {
	"use strict";

	return BaseController.extend("pr.req.controller.Detail", {

		formatter: formatter,
		/**/
		/* =========================================================== */
		/* lifecycle methods                                           */
		/* =========================================================== */

		onInit: function(oEvent) {
			var oModel = this.getOwnerComponent().getModel();
			var oJSONModel = this.getOwnerComponent().getModel("json");
			oModel.read("/DraftitemsSet", {
				success: function(r, s) {
					oJSONModel.setProperty("/cartModel", r.results);
				}
			});
			oModel.read("/CheckflagSet('B')", {
				success: function(r, s) {
					oJSONModel.setProperty("/RigNum", r);
				}
			});
			oJSONModel.refresh(true);
		},
		///  updatefinish not work as data model set from master Controller 
		onListUpdateFinished: function(oEvent) {

		},
		/// on Search filter with the material num to get all items starting with number of matnr
		onSearchPressed: function(oEvent) {
			this.sSearch = oEvent.getParameter("query");
			var oModel = this.getView().getModel();
			var oJSONModel = this.getView().getModel("json");
			sap.ui.core.BusyIndicator.show(0);
			oModel.read("/SearchItemsSet", {
				filters: [new Filter("Matkl", "EQ", ""), new Filter("Mfrnr", "EQ",
					""), new Filter("Mfrpn", "EQ", ""), new Filter("Maktx", "EQ", this.sSearch)],
				success: function(r) {
					sap.ui.core.BusyIndicator.hide();
					oJSONModel.setProperty("/tablebindingModel", r.results);
					oJSONModel.refresh("true");
				},
				error: function() {
					sap.ui.core.BusyIndicator.hide();
				}
			});
		},
		//	
		onDetailsTableUpdateFinished: function(oEvent) {
			var sTitle,
				fOrderTotal = 0,
				iTotalItems = oEvent.getParameter("total"),
				oJSONModel = this.getOwnerComponent().getModel("json");
			if (oEvent.getSource().getBinding("items").isLengthFinal()) {
				if (iTotalItems) {
					sTitle = this.byId("detailsItemHeader").setText("Items (" + iTotalItems + ")");
				} else {
					//Display 'Line Items' instead of 'Line items (0)'
					sTitle = this.byId("detailsItemHeader").setText("Items(0)");
				}
			}
		},

		//// on delete pressed of the dialog draft items//
		onDeletePressed: function(oEvent) {
			var oModel = this.getOwnerComponent().getModel();
			var oJSONModel = this.getOwnerComponent().getModel("json");
			var selctdItem = oEvent.getParameter("listItem").getBindingContext("json").getObject();
			var olinenum = selctdItem.Ebelp;
			var Guid = selctdItem.Guid;
			//	sap.ui.core.BusyIndicator.show(0);
			oModel.remove("/DraftlineSet(Guid='" + Guid + "',Ebelp='" + olinenum + "')", {
				success: function(data, response) {
					sap.ui.core.BusyIndicator.hide();
					oModel.read("/DraftitemsSet", {
						success: function(r, s) {
							oJSONModel.setProperty("/cartModel", r.results);
						}
					});
					MessageToast.show("Draft item successfully removed from cart");
					oModel.read("/CheckflagSet('X')", {
						success: function(r) {
							sap.ui.core.BusyIndicator.hide();
							oJSONModel.setProperty("/Flag", r);
						}
					});
					oJSONModel.refresh("true");
				}
			});
		},
		//// shopping cart button opens dialog with draft items
		onShoppingCartPressed: function(oEvent) {
			var oJSONModel = this.getOwnerComponent().getModel("json");
			sap.ui.core.BusyIndicator.show();
			this.getOwnerComponent().getModel().read("/DraftitemsSet", {
				success: function(r) {

					oJSONModel.setProperty("/cartModel", r.results);
					sap.ui.core.BusyIndicator.hide();
				}
			});
			//// To get selectedkey from combobox 
			this.sComb = this.byId("selComb").getSelectedKey();
			oJSONModel.setProperty("/SelectedKey", this.sComb);
			if (!this.ocartPress) {
				this.ocartPress = sap.ui.xmlfragment("pr.req.view.fragment.ShoppingCart", this);
				this.getView().addDependent(this.ocartPress);
				this.ocartPress.setModel(oJSONModel);
				oJSONModel.refresh();
			}
			this.ocartPress.setModel(oJSONModel);
			oJSONModel.refresh();
			this.ocartPress.open();
		},

		///// cart dialog cancel closes dialog
		cancel: function() {
			this.ocartPress.close();
		},
		// Router component for navigation
		getRouter: function() {
			return sap.ui.core.UIComponent.getRouterFor(this);
		},

		//// navigation on View cart press on cart dialog
		ViewCart: function(oEvt) {
			var cartId = "cartId";
			this.getOwnerComponent().getRouter().navTo("cart", {
				cartId: cartId
			});
		},
		/// Quick view opens with details
		onQckviewPressed: function(oEvent) {
			if (!this.oQckVwdialog) {
				this.oQckVwdialog = sap.ui.xmlfragment("pr.req.view.fragment.QuickView", this);
			}
			var sObject = oEvent.getSource().getParent().getBindingContext("json").getObject();
			var oJSONModel = this.getOwnerComponent().getModel("json");
			oJSONModel.setProperty("/QckvwModel", sObject);
			this.oQckVwdialog.setModel(oJSONModel);
			this.oQckVwdialog.bindElement("/QckvwModel");
			this.oQckVwdialog.openBy(oEvent.getSource());
		},

		/// favorite handling  selection and deselection  adds item to favorites table
		onFavoriteSelection: function(oEvent) {
			var state = oEvent.getSource().getPressed();
			this.setflag = "X";
			this.setevent = "";
			if (state == true) {
				this.setflag = "Y";
				var favObj = oEvent.getSource().getParent().getBindingContext("json").getObject();
				var sfavorite = {};
				sfavorite.Maktx = favObj.Maktx;
				sfavorite.Matkl = favObj.Matkl;
				sfavorite.Matnr = favObj.Matnr;
				sfavorite.Menge = favObj.Menge;
				sfavorite.Mfrnr = favObj.Mfrnr;
				//  sfavorite.Fav = favObj.Fav;
				sfavorite.Uom = favObj.Uom;
				sfavorite.Verpr = favObj.Verpr;
				sfavorite.Waers = favObj.Waers;
				var oModel = this.getOwnerComponent().getModel();
				var oJSONModel = this.getOwnerComponent().getModel("json");
				var that = this;
				//	
				oModel.create("/FavoriteSet", sfavorite, {
					success: function(oData, oResponse) {
						MessageToast.show("Item Selected as Favorite");
						oModel.read("/CheckflagSet('F')", {
							success: function(r) {

								oJSONModel.setProperty("/favCount", r);

								that.getOwnerComponent()._oViews._oViews["pr.req.view.Master"].byId("FavList").setInfo(r.Count);
								sap.ui.core.BusyIndicator.hide();
								oJSONModel.refresh(true);
							}
						});
					},
					error: function() {
						sap.ui.core.BusyIndicator.hide();
					}
				});
			}
			if (state == false) {
				var oModel = this.getOwnerComponent().getModel();
				var oJSONModel = this.getOwnerComponent().getModel("json");
				var unfavObj = oEvent.getSource().getParent().getBindingContext("json").getObject();
				var unfavorite = {};
				unfavorite.Matnr = unfavObj.Matnr;
				var that = this;
				oModel.remove("/FavoriteSet(Matnr='" + unfavObj.Matnr + "')", {
					success: function(oData, oResponse) {
						MessageToast.show("Item deselected as favorite");
						oModel.read("/CheckflagSet('F')", {
							success: function(r) {
								sap.ui.core.BusyIndicator.hide();
								oJSONModel.setProperty("/favCount", r);
								that.getOwnerComponent()._oViews._oViews["pr.req.view.Master"].byId("FavList").setInfo(r.Count);
								oJSONModel.refresh(true);
							}
						});
					},
					error: function() {}
				});
			}
		},

		onAfterRendering: function() {
			var oJSONModel = this.getOwnerComponent().getModel("json");
			oJSONModel.getProperty("/tablebindingModel");
			oJSONModel.refresh("true");
		},

		/// on add to cart press adds draft items to shopping cart
		onAddToCartPressed: function(oEvent) {
			var objData = oEvent.getSource().getParent().getBindingContext("json").getObject();
			if (objData.Menge === "0.000" || objData.Menge === "") {
				MessageBox.warning("Quantity should not be Empty or Zero");
			} else {
				var cartData = {};
				cartData.Ebelp = "00010";
				cartData.Knttp = this.byId("selComb").getSelectedKey();
				cartData.Maktx = objData.Maktx;
				cartData.Matkl = objData.Matkl;
				cartData.Matnr = objData.Matnr;
				cartData.Menge = objData.Menge;
				cartData.Mfrnr = objData.Mfrnr;
				cartData.Wgbez = objData.Name1;
				cartData.Uom = objData.Uom;
				cartData.Verpr = objData.Verpr;
				cartData.Waers = objData.Waers;
				var oModel = this.getOwnerComponent().getModel();
				var oJSONModel = this.getOwnerComponent().getModel("json");
				sap.ui.core.BusyIndicator.show(0);
				oModel.create("/DraftitemsSet", cartData, {
					success: function(oData, oResponse) {

						//	MessageToast.show("Item added to cart");

						oModel.read("/CheckflagSet('X')", {
							success: function(r) {
								oJSONModel.setProperty("/Flag", r);
								oJSONModel.refresh("true");
								MessageToast.show("Item added to cart");
								sap.ui.core.BusyIndicator.hide();
							}

						});
						// to update the table with the new item created  
						oModel.read("/DraftitemsSet", {
							success: function(r, s) {

								oJSONModel.setProperty("/cartModel", r.results);
								sap.ui.core.BusyIndicator.hide();
							}
						});
						oJSONModel.refresh(true);
					},
					error: function() {
						sap.ui.core.BusyIndicator.hide();
					}
				});
			}
		}

	});
});