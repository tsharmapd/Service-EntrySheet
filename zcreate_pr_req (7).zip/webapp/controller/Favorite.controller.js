sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/m/MessageToast"
], function(Controller, MessageToast) {
	"use strict";

	return Controller.extend("pr.req.controller.Favorite", {

		onInit: function() {

		},

		/// router for navigation	
		getRouter: function() {
			return sap.ui.core.UIComponent.getRouterFor(this);
		},

		// navigates back to previous screen		
		onFavNavBack: function() {
			var objId = "objectId";
			this.getRouter().navTo("object", {
				objectId: objId
			});
		},
		handleChange:function(oEvent){
			var that = this;
			 var qty = oEvent.getSource().getValue();
			 var oJSONModel = that.getOwnerComponent().getModel("json");
			 oJSONModel.setProperty("/favQty",qty);
			 
			 	},
		onListUpdateFinished: function(oEvent) {
			var sTitle,
				fOrderTotal = 0,
				iTotalItems = oEvent.getParameter("total"),
				oJSONModel = this.getOwnerComponent().getModel("json");
			if (oEvent.getSource().getBinding("items").isLengthFinal()) {
				if (iTotalItems) {
					sTitle = this.byId("lineItemsHeader").setText("Fav Items (" + iTotalItems + ")");
				} else {
					//Display 'Line Items' instead of 'Line items (0)'
					sTitle = this.byId("lineItemsHeader").setText("Fav Items(0)");
				}
			}
		},
		onFavShoppingCartPressed: function(oEvent) {
			var oJSONModel = this.getOwnerComponent().getModel("json");
			sap.ui.core.BusyIndicator.show();
			this.getOwnerComponent().getModel().read("/DraftitemsSet", {
				success: function(r) {
					//	oTable.setBusy(false);
					sap.ui.core.BusyIndicator.hide();
					oJSONModel.setProperty("/cartModel", r.results);
				}
			});

			if (!this.oFavcartPress) {
				this.oFavcartPress = sap.ui.xmlfragment("pr.req.view.fragment.ShoppingCart", this);
				this.getView().addDependent(this.oFavcartPress);
				this.oFavcartPress.setModel(oJSONModel);
				oJSONModel.refresh();
			}
			this.oFavcartPress.setModel(oJSONModel);
			oJSONModel.refresh();
			this.oFavcartPress.open();
		},
			onDeletePressed: function(oEvent) {
			var oModel = this.getOwnerComponent().getModel();
			var oJSONModel = this.getOwnerComponent().getModel("json");
			var selctdItem = oEvent.getParameter("listItem").getBindingContext("json").getObject();
			var olinenum = selctdItem.Ebelp;
			var Guid = selctdItem.Guid;
			//	sap.ui.core.BusyIndicator.show(0);
			oModel.remove("/DraftlineSet(Guid='" + Guid + "',Ebelp='" + olinenum + "')", {
				success: function(data, response) {
					sap.ui.core.BusyIndicator.hide();
					oModel.read("/DraftitemsSet", {
						success: function(r, s) {
							oJSONModel.setProperty("/cartModel", r.results);
						}
					});
					MessageToast.show("Draft item successfully removed from cart");
					oModel.read("/CheckflagSet('X')", {
						success: function(r) {
							sap.ui.core.BusyIndicator.hide();
							oJSONModel.setProperty("/Flag", r);
						}
					});
					oJSONModel.refresh("true");
				}
			});
		},

		///// cart dialog cancel closes dialog
		cancel: function() {
			this.oFavcartPress.close();
		},
		//// navigation on View cart press on cart dialog
		ViewCart: function(oEvt) {
			var cartId = "cartId";
			this.getOwnerComponent().getRouter().navTo("cart", {
				cartId: cartId
			});
		},

		// quick view  opens with product details
		onFavQckviewPressed: function(oEvent) {
			if (!this.oQckVwdialog) {
				this.oQckVwdialog = sap.ui.xmlfragment("pr.req.view.fragment.QuickView", this);
			}
			var sObject = oEvent.getSource().getBindingContext().getObject();
			var oJSONModel = this.getOwnerComponent().getModel("json");
			oJSONModel.setProperty("/QckvwModel", sObject);
			this.oQckVwdialog.setModel(oJSONModel);
			this.oQckVwdialog.bindElement("/QckvwModel");
			this.oQckVwdialog.openBy(oEvent.getSource());
		},
		// To unfavorite the fav Item		
		toUnFavoriteItem: function(oEvent) {
			var pressedstate = oEvent.getSource().getPressed();
			if (pressedstate == false) {
				var oModel = this.getOwnerComponent().getModel();
				var oJSONModel = this.getOwnerComponent().getModel("json");
				var unfavObj = oEvent.getSource().getBindingContext().getObject();
				var unfavorite = {};
			/*	if(unfavObj.Matnr==""){
					unfavObj.Matnr = 'X';
				}*/
			//	unfavorite.Matnr = unfavObj.Matnr;
				unfavorite.Maktx = unfavObj.Maktx;
				
				var sPath = "/FavoriteSet(Matnr='" + unfavObj.Matnr + "')";
			//	var path ="/FavoriteSet(Matnr='" + unfavObj.Matnr + "',Maktx='"+ unfavObj.Maktx +"')";
			//	encodeURIComponent(path);
				var that = this;
					sap.ui.core.BusyIndicator.show(0);
				oModel.remove(sPath,{
					success: function(oData, oResponse) {
						sap.ui.core.BusyIndicator.hide();
						MessageToast.show("Item removed from favorites");
						oModel.read("/CheckflagSet('F')", {
							success: function(r) {
								oJSONModel.setProperty("/favCount", r);
								that.getOwnerComponent()._oViews._oViews["pr.req.view.Master"].byId("FavList").setInfo(r.Count);
								oJSONModel.refresh(true);
							}
						});
					},
					error: function() {
						sap.ui.core.BusyIndicator.hide();
					}
				});
			}
		},
		
		//on add to cart
		onFavAddToCartPressed: function(oEvent) {
			var objData = oEvent.getSource().getBindingContext().getObject();
				var oModel = this.getOwnerComponent().getModel();
			var oJSONModel = this.getOwnerComponent().getModel("json");
			var that = this;
			var cartData = {};
			cartData.Ebelp = "00010";
			//	cartData.Knttp =this.byId("selComb2").getSelectedKey();
			cartData.Maktx = objData.Maktx;
			cartData.Matkl = objData.Matkl;
			cartData.Matnr = objData.Matnr;
		//	cartData.Menge = objData.Menge;
	     	cartData.Menge = oJSONModel.getData().favQty;
			cartData.Mfrnr = objData.Mfrnr;
			cartData.Uom = objData.Uom;
			cartData.Verpr = objData.Verpr;
			cartData.Waers = objData.Waers;
			var eQty ="0.000";
			sap.ui.core.BusyIndicator.show(0);
			oModel.create("/DraftitemsSet", cartData, {
				success: function(oData, oResponse) {
					oJSONModel.setProperty("/favQty",eQty);
					oJSONModel.refresh("true");
					MessageToast.show("Item added to the cart");
					oModel.read("/CheckflagSet('X')", {
						success: function(r) {
							sap.ui.core.BusyIndicator.hide();
							oJSONModel.setProperty("/Flag", r);
							
							oJSONModel.refresh("true");
						
						}
						
					});
					
					// to update the table with the new item created  
					oModel.read("/DraftitemsSet", {
						success: function(r, s) {
							sap.ui.core.BusyIndicator.hide();
							oJSONModel.setProperty("/cartModel", r.results);
						}
					});
					
					oJSONModel.refresh("true");
				},
				error: function() {
					sap.ui.core.BusyIndicator.hide();
				}
			});

		}

	});
});