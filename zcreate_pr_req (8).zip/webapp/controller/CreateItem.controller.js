sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/m/MessageBox",
	"sap/m/MessageToast",
	"sap/ui/model/Filter"
], function(Controller, MessageBox, MessageToast, Filter) {
	"use strict";

	return Controller.extend("pr.req.controller.CreateItem", {

		onInit: function() {
		},
		getRouter: function() {
			return sap.ui.core.UIComponent.getRouterFor(this);
		},
		//Shopping cart press
		onCreateShoppingCartPressed: function(oEvent) {
			var oJSONModel = this.getOwnerComponent().getModel("json");
			sap.ui.core.BusyIndicator.show();
			this.getOwnerComponent().getModel().read("/DraftitemsSet", {
				success: function(r) {
					sap.ui.core.BusyIndicator.hide();
					oJSONModel.setProperty("/cartModel", r.results);
				}
			});

			if (!this.ocartPress) {
				this.ocartPress = sap.ui.xmlfragment("pr.req.view.fragment.ShoppingCart", this);
				this.getView().addDependent(this.ocartPress);
				this.ocartPress.setModel(oJSONModel);
				oJSONModel.refresh();
			}
			this.ocartPress.setModel(oJSONModel);
			oJSONModel.refresh();
			this.ocartPress.open();
		},
		onAddCreatedItemToFavPress: function() {
			var canProceed = true;
			var shText = this.byId("shtextId");
			if (shText.getValue() === "") {
				shText.setValueState("Error");
				shText.setValueStateText("Enter short text");
				canProceed = false;
			}

			var qtyVal = this.byId("qtyId");
			if (qtyVal.getValue() === "") {
				qtyVal.setValueState("Error");
				qtyVal.setValueStateText("Enter Quantity");
				canProceed = false;
			}
			var UomId = this.byId("UomId");
			if (UomId.getSelectedKey() === "") {
				UomId.setValueState("Error");
				UomId.setValueStateText("Enter Unit of Measure");
				canProceed = false;
			}
			var valPric = this.byId("valprId");
			if (valPric.getValue() === "") {
				valPric.setValueState("Error");
				valPric.setValueStateText("Enter Valuation Price");
				canProceed = false;
			}
             if(canProceed){
			var matrlGrp = this.byId("matgrpId").getValue();
			var oModel = this.getOwnerComponent().getModel();
			var oJSONModel = this.getOwnerComponent().getModel("json");
			var crcyVal = "CAD";
			var addToCart = {};
			//	addToCart.Knttp = accAsgn;
			//	addToCart.Text1 = shText.getValue();
			addToCart.Maktx = shText.getValue();
		    addToCart.Matnr = shText.getValue();
			addToCart.Menge = qtyVal.getValue();
			addToCart.Uom = UomId.getSelectedKey();
			addToCart.Verpr = valPric.getValue();
			addToCart.Waers = crcyVal;
			addToCart.Wgbez = this.byId("matgrpId").getValue();
			//addToCart.Lfdat = delvyDt;
			//addToCart.Matkl = matrlGrp;
			var matrlNum =oJSONModel.getData().Matrlnumber;
    		addToCart.Matkl = matrlNum;
			var that = this;

			//	
			oModel.create("/FavoriteSet", addToCart, {
				success: function(oData, oResponse) {
					MessageToast.show("Item Added to Favorites");
					oModel.read("/CheckflagSet('F')", {
						success: function(r) {
							oJSONModel.setProperty("/favCount", r);
							that.getOwnerComponent()._oViews._oViews["pr.req.view.Master"].byId("FavList").setInfo(r.Count);
							oJSONModel.refresh(true);
							that.refreshCreateItem();
						}
					});

				},
				error: function() {
					sap.ui.core.BusyIndicator.hide();
				}
			});
             }
             else{
             	MessageBox.warning("Please fill all the fields to add as favoite Item");
             }
		},
		refreshCreateItem:function(){
			this.byId("shtextId").setValue("");
			this.byId("shtextId").setValueState("None");
			this.byId("qtyId").setValue("");
			this.byId("qtyId").setValueState("None");
			this.byId("UomId").setSelectedKey("");
			this.byId("UomId").setValueState("None");
			this.byId("valprId").setValue("");
			this.byId("valprId").setValueState("None");
			//	this.byId("crcyId").setValue("");
			//	this.byId("crcyId").setValueState("None");
			this.byId("deldtId").setValue("");
			this.byId("deldtId").setValueState("None");
			this.byId("matgrpId").setValue("");
			this.byId("cmntsId").setValue("");
			

		},

		onDeletePressed: function(oEvent) {
			var oModel = this.getOwnerComponent().getModel();
			var oJSONModel = this.getOwnerComponent().getModel("json");
			var selctdItem = oEvent.getParameter("listItem").getBindingContext("json").getObject();
			var olinenum = selctdItem.Ebelp;
			var Guid = selctdItem.Guid;
			//	sap.ui.core.BusyIndicator.show(0);
			oModel.remove("/DraftlineSet(Guid='" + Guid + "',Ebelp='" + olinenum + "')", {
				success: function(data, response) {
					sap.ui.core.BusyIndicator.hide();
					oModel.read("/DraftitemsSet", {
						success: function(r, s) {
							oJSONModel.setProperty("/cartModel", r.results);
						}
					});
					MessageToast.show("Draft item successfully removed from cart");
					oModel.read("/CheckflagSet('X')", {
						success: function(r) {
							sap.ui.core.BusyIndicator.hide();
							oJSONModel.setProperty("/Flag", r);
						}
					});
					oJSONModel.refresh("true");
				}
			});
		},

		///// cart dialog cancel closes dialog
		cancel: function() {
			this.ocartPress.close();
		},
		//// navigation on View cart press on cart dialog
		ViewCart: function(oEvt) {
			var cartId = "cartId";
			this.getOwnerComponent().getRouter().navTo("cart", {
				cartId: cartId
			});
		},

		onCreateItemPress: function() {
			var canProceed = true;
			var shText = this.byId("shtextId");
			if (shText.getValue() === "") {
				shText.setValueState("Error");
				shText.setValueStateText("Enter short text");
				canProceed = false;
			}

			var qtyVal = this.byId("qtyId");
			if (qtyVal.getValue() === "") {
				qtyVal.setValueState("Error");
				qtyVal.setValueStateText("Enter Quantity");
				canProceed = false;
			}
			var UomId = this.byId("UomId");
			if (UomId.getSelectedKey() === "") {
				UomId.setValueState("Error");
				UomId.setValueStateText("Enter Unit of Measure");
				canProceed = false;
			}
			var valPric = this.byId("valprId");
			if (valPric.getValue() === "") {
				valPric.setValueState("Error");
				valPric.setValueStateText("Enter Valuation Price");
				canProceed = false;
			}
			/*var crcyVal = this.byId("crcyId");
				if (crcyVal.getValue() === "") {
				crcyVal.setValueState("Error");
				crcyVal.setValueStateText("Enter Currency");
				canProceed = false;
			}*/
		/*	var delvyDt = this.byId("deldtId").getDateValue();
				if (delvyDt.getDateValue() === "") {
				delvyDt.setValueState("Error");
				delvyDt.setValueStateText("Choose Delivery Date");
				canProceed = false;
			}*/

		var updatedFormat;
		var  delvyDt = this.byId("deldtId").getDateValue();
			if (this.byId("deldtId").getDateValue() === "") {
				updatedFormat = null;
			} else {
				var oDate = new Date(delvyDt);
				updatedFormat = [oDate.getFullYear(), oDate.getMonth() + 1, oDate.getDate()].join("-");
			//	updatedFormat = updatedFormat + "T00:00:00";
			}
			var matrlGrp = this.byId("matgrpId").getValue();
			var oModel = this.getOwnerComponent().getModel();
			var oJSONModel = this.getOwnerComponent().getModel("json");
			var matrlNum =oJSONModel.getData().Matrlnumber;
			var crcyVal = "CAD";
			var addToCart = {};
			//	addToCart.Knttp = accAsgn;
			addToCart.Text1 = shText.getValue();
			addToCart.Maktx = shText.getValue();
			addToCart.Menge = qtyVal.getValue();
			addToCart.Uom = UomId.getSelectedKey();
			addToCart.Verpr = valPric.getValue();
			addToCart.Preis = valPric.getValue();
			addToCart.Waers = crcyVal;
			addToCart.Wgbez = this.byId("matgrpId").getValue();
			addToCart.DelDate = updatedFormat;
			addToCart.Matkl = matrlNum;
			oModel.create("/DraftitemsSet", addToCart, {
				success: function(oData, oResponse) {
					MessageToast.show("Draft Item Successfully created");
					oModel.read("/CheckflagSet('X')", {
						success: function(r) {
							sap.ui.core.BusyIndicator.hide();
							oJSONModel.setProperty("/Flag", r);
							oJSONModel.refresh("true");
						}
					});
				},
				error: function() {
					sap.ui.core.BusyIndicator.hide();
				}
			});

			this.byId("shtextId").setValue("");
			this.byId("shtextId").setValueState("None");
			this.byId("qtyId").setValue("");
			this.byId("qtyId").setValueState("None");
			this.byId("UomId").setSelectedKey("");
			this.byId("UomId").setValueState("None");
			this.byId("valprId").setValue("");
			this.byId("valprId").setValueState("None");
			//	this.byId("crcyId").setValue("");
			//	this.byId("crcyId").setValueState("None");
			this.byId("deldtId").setValue("");
			this.byId("deldtId").setValueState("None");
			this.byId("matgrpId").setValue("");
			this.byId("cmntsId").setValue("");
			
		},

		// on decline press 	
		onDeleteCreateItem: function() {
			//	this.byId("actasgnId").setValue("");
			this.byId("shtextId").setValue("");
			this.byId("qtyId").setValue("");
			this.byId("UomId").setSelectedKey("");
			this.byId("valprId").setValue("");
			//	this.byId("crcyId").setValue("");
			this.byId("deldtId").setValue("");
			this.byId("matgrpId").setValue("");
		//	this.getOwnerComponent().getRouter().navTo("object");          
		},
		//  f4 value help request opens a dialog list	
		handleValueHelp: function(oEvent) {
			var sInputValue = oEvent.getSource().getValue();
			this.inputId = oEvent.getSource().getId();
			// create value help dialog
			if (!this._valueHelpDialog) {
				this._valueHelpDialog = sap.ui.xmlfragment("pr.req.view.fragment.ValueHelp", this);
				this.getView().addDependent(this._valueHelpDialog);
			}

			// create a filter for the binding
			this._valueHelpDialog.getBinding("items").filter([new Filter(
				"Wgbez60",
				sap.ui.model.FilterOperator.Contains, sInputValue
			)]);

			// open value help dialog filtered by the input value
			this._valueHelpDialog.open(sInputValue);
		},

		_handleValueHelpSearch: function(evt) {
			var sValue = evt.getParameter("value");
			var oFilter = new Filter(
				"Wgbez60",
					sap.ui.model.FilterOperator.Contains, sValue
			);
			evt.getSource().getBinding("items").filter([oFilter]);
		},

		_handleValueHelpClose: function(evt) {
			var that = this;
			var oJSONModel = that.getOwnerComponent().getModel("json");
			var oSelectedItem = evt.getParameter("selectedItem");
			if (oSelectedItem) {
				var orderInput = this.byId("matgrpId");
				orderInput.setValue(oSelectedItem.getTitle());
				var oVal =	oSelectedItem.getDescription();
				oJSONModel.setProperty("/Matrlnumber",oVal);
				
			}
		
			evt.getSource().getBinding("items").filter([]);
		},

		/*	suggestionItemSelected: function(evt) {
			var oItem = evt.getParameter('selectedItem'),
				oText = this.getView().byId('selectedKey'),
				sKey = oItem ? oItem.getKey() : '';

			oText.setText(sKey);
		},
*/
		// navigation back from create item view
		onCrtItemNavBack: function(oEvent) {
			var objId = "objectId";
			this.getRouter().navTo("object", {
				objectId: objId
			});
		}

	});
});