sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"pr/req/model/formatter",
	"sap/ui/model/Filter",
	"sap/ui/model/Sorter",
	"sap/m/MessageToast"
], function(Controller, formatter, Filter, Sorter, MessageToast) {
	"use strict";

	return Controller.extend("pr.req.controller.PreviousRequisitions", {
		formatter: formatter,
		// Constants:
		PO_ITEMS_TABLE: {
			ID: "prevTable",
			SORT_KEY: {
				EADAT: "Eadat"
			}
		},
		onInit: function() {
			this.getOwnerComponent().getRouter().getRoute("previous").attachPatternMatched(this._handleMatched, this);
		},
		_handleMatched: function() {
			var oModel = this.getOwnerComponent().getModel();
			var oJSONModel = this.getOwnerComponent().getModel("json");
			sap.ui.core.BusyIndicator.show(0);
			oModel.read("/PrevitemsSet", {
				success: function(r) {
					sap.ui.core.BusyIndicator.hide();
					oJSONModel.setProperty("/prevTableModel", r.results);

				}
			});
			oModel.read("/FilterSet", {
				success: function(r) {
					sap.ui.core.BusyIndicator.hide();
					oJSONModel.setProperty("/filtrModel", r.results);

				}
			});
		},
		/// on Shopping cart btn press
		onPrevShoppingCartPressed: function(oEvent) {
			var oJSONModel = this.getOwnerComponent().getModel("json");
			sap.ui.core.BusyIndicator.show();
			this.getOwnerComponent().getModel().read("/DraftitemsSet", {
				success: function(r) {
					//	oTable.setBusy(false);
					sap.ui.core.BusyIndicator.hide();
					oJSONModel.setProperty("/cartModel", r.results);
				}
			});
			// opens a list of draft items in cart 
			if (!this.oPrevcartPress) {
				this.oPrevcartPress = sap.ui.xmlfragment("pr.req.view.fragment.ShoppingCart", this);
				this.getView().addDependent(this.oPrevcartPress);
				this.oPrevcartPress.setModel(oJSONModel);
				oJSONModel.refresh();
			}
			this.oPrevcartPress.setModel(oJSONModel);
			oJSONModel.refresh();
			this.oPrevcartPress.open();
		},

		///// cart dialog cancel closes dialog
		cancel: function() {
			this.oPrevcartPress.close();
		},
		//// navigation on View cart press on cart dialog
		ViewCart: function(oEvt) {
			var cartId = "cartId";
			this.getOwnerComponent().getRouter().navTo("cart", {
				cartId: cartId
			});
		},

		/* Gives the items count on table header*/
		onListUpdateFinished: function(oEvent) {
			var sTitle,
				fOrderTotal = 0,
				iTotalItems = oEvent.getParameter("total"),
				oJSONModel = this.getOwnerComponent().getModel("json");
			if (oEvent.getSource().getBinding("items").isLengthFinal()) {
				if (iTotalItems) {
					sTitle = this.byId("prevItemsHeader").setText("Items (" + iTotalItems + ")");
				} else {
					//Display 'Line Items' instead of 'Line items (0)'
					sTitle = this.byId("prevItemsHeader").setText("Items(0)");
				}
			}
		},

		onSorterPressed: function() {
			if (!this.sorterDialog) {
				this.sorterDialog = sap.ui.xmlfragment("pr.req.view.fragment.Sorter", this);
				this.getView().addDependent(this.sorterDialog);
			}
			this.sorterDialog.open();
		},

		handleSortingConfirm: function(oEvent) {
			var oView = this.getView();
			var oTable = oView.byId("prevTable");
			var mParams = oEvent.getParameters();
			var oBinding = oTable.getBinding("items");
			var sPath;
			var bDescending;
			var aSorters = [];
			sPath = mParams.sortItem.getKey();
			bDescending = mParams.sortDescending;
			aSorters.push(new Sorter(sPath, bDescending));
			oBinding.sort(aSorters);
		},
		////////////
		/*
		
		var myData = {};
var withoutDuplicate = {
    "myData": []
};for (i = 0; i < data.results.length; i++) {
		    if (withoutDuplicate.myData.length == 0) {
		        withoutDuplicate.myData.push({
		            "Product": data.results[i].ProductID,
		            "Count": 1
		        });
		    } else 
		        for (j = 0; j < withoutDuplicate.myData.length; j++) {
		            if (withoutDuplicate.myData[j].Product == data.results[i].ProductID) {
		                //count++
		                withoutDuplicate.myData[j].Count = withoutDuplicate.myData[j].Count + 1;
		                var flag = 0;
		                break;
		            } else {
		                var flag = 1;
		            }
		        }
		        if (flag == 1) {
		            withoutDuplicate.myData.push({
		                "Product": data.results[i].ProductID,
		                "Count": 1
		            });
		        }
		    }
		}*/

		// to filter table records based on created by
		onFilterCreatedBy: function() {
			if (!this.fDialog) {
				this.fDialog = sap.ui.xmlfragment("pr.req.view.fragment.createdbyFilter", this);
				this.getView().addDependent(this.fDialog);
			}

			var c = [];

			var d = [];
			var e = [];

			var oArray = this.getOwnerComponent().getModel("json").getData().prevTableModel;
			//	c.push("ALL");
			for (var i = 0; i < oArray.length; i++) {
				if (c.indexOf(oArray[i].Erdat) === -1) {
					c.push(oArray[i].Erdat);
				}

			}

			function isDateInArray(h, k) {
				for (var x = 0; x < k.length; x++) {
					if (h.getTime() === k[x].getTime()) {
						return true;
					}
				}
				return false;
			}
			var uniqueDates = [];
			for (var y = 0; y< c.length; y++) {
				if (!isDateInArray(c[y], uniqueDates)) {
					uniqueDates.push(c[y]);
				}
			}
			//	c.sort();
			/*	for (var k = 0; k < c.length; k++) {
					if (c.indexOf(c[k].Erdat) === -1) {
						e.push(c[k].Erdat);
					}

				}*/

			for (var j = 0; j < uniqueDates.length; j++) {

				var object = {};
				object.Erdat = uniqueDates[j];
				d.push(object);

			}
			var oJSONModel = this.getOwnerComponent().getModel("json");
			oJSONModel.setProperty("/dateFilter", d);
		
			this.fDialog.open();
		},
		/// to get items based on created by filter
		onFilterCreatedByConfirm: function(oEvent) {
			var params = oEvent.getParameters();
			var aFilterItems = params.filterItems;
			//	var oSelectedFilter = aFilterItems[0].getKey();

			//	var aFilterItems = params.filterItems;
			var iLength = aFilterItems.length;
			var aFilter = [];
			for (var i = 0; i < iLength; i++) {
				if (params.filterItems[i].mBindingInfos.key.binding.sPath == "Ernam") {
					if (params.filterItems[i].mBindingInfos.key.binding.oValue) {
						aFilter.push(new sap.ui.model.Filter(
							"Ernam",
							sap.ui.model.FilterOperator.EQ, params.filterItems[i].mBindingInfos.key.binding.oValue
						));
					}
				}
				if (params.filterItems[i].mBindingInfos.key.binding.sPath == "Erdat") {
					if (params.filterItems[i].mBindingInfos.key.binding.oValue) {
						aFilter.push(new sap.ui.model.Filter(
							"Erdat",
							sap.ui.model.FilterOperator.EQ, params.filterItems[i].mBindingInfos.key.binding.oValue
						));
					}
				}
				var otable = this.byId("prevTable").getBinding("items").filter(aFilter);
			}
			//	var Matnr = this.sSearch;

		},
		onFilterCreatedOn: function() {

		},
		/*
    var c = [];
    var d = [];
    c.push("ALL");
    for(var i=0; i<oArray.results.length; i++) {
      if(c.indexOf(oArray.results[i].Werks) === -1) {
        c.push(oArray.results[i].Werks);
      }
    }
    for(var j=0; j<c.length; j++) {
      var object = {};
      object.Werks = c[j];
      d.push(object);
    }
    var oModelPlant = new sap.ui.model.json.JSONModel();
    oModelPlant.setData({data: d});
    var oPlntdd = sap.ui.getCore().byId("plantDropdown");
    oPlntdd.setModel(oModelPlant); 
*/
		// navigate back to detail screen
		onPrevNavBack: function() {
			var objId = "objectId";
			this.getRouter().navTo("object", {
				objectId: objId
			});
		},
		//router component for navigation
		getRouter: function() {
			return sap.ui.core.UIComponent.getRouterFor(this);
		},
		onDeletePressed: function(oEvent) {
			var oModel = this.getOwnerComponent().getModel();
			var oJSONModel = this.getOwnerComponent().getModel("json");
			var selctdItem = oEvent.getParameter("listItem").getBindingContext("json").getObject();
			var olinenum = selctdItem.Ebelp;
			var Guid = selctdItem.Guid;
			//	sap.ui.core.BusyIndicator.show(0);
			oModel.remove("/DraftlineSet(Guid='" + Guid + "',Ebelp='" + olinenum + "')", {
				success: function(data, response) {
					sap.ui.core.BusyIndicator.hide();
					oModel.read("/DraftitemsSet", {
						success: function(r, s) {
							oJSONModel.setProperty("/cartModel", r.results);
						}
					});
					MessageToast.show("Draft item successfully removed from cart");
					oModel.read("/CheckflagSet('X')", {
						success: function(r) {
							sap.ui.core.BusyIndicator.hide();
							oJSONModel.setProperty("/Flag", r);
						}
					});
					oJSONModel.refresh("true");
				}
			});
		},
		// to add  multiple prev reqs to cart
		onPrevReqAddtoCartPress: function(oEvent) {
			var oJSONModel = this.getOwnerComponent().getModel("json");
			var oMaster = {};
			var Items = [];
			var oTable = this.byId('prevTable');
			var selectedItems = oTable.getSelectedItems();
			for (var i = 0; i < selectedItems.length; i++) {
				Items.push({
					"Banfn": selectedItems[i].getCells()[0].getText(),
					"Bnfpo": selectedItems[i].getCells()[1].getText(),
					"Ernam": selectedItems[i].getCells()[2].getText(),
					"Erdat": selectedItems[i].getCells()[3].getText(),
					"Matnr": selectedItems[i].getCells()[4].getText(),
					"Txz01": selectedItems[i].getCells()[5].getText(),
					"Verpr": selectedItems[i].getCells()[6].getText(),
					"Menge": selectedItems[i].getCells()[7].getText(),
					"Wgbez": selectedItems[i].getCells()[8].getText(),
					"Matkl": selectedItems[i].getCells()[9].getText()
				});
			}
			oJSONModel.setProperty("/Payload", Items);
			var oModel = this.getOwnerComponent().getModel("json").getData().Payload;
			var oMaster = {};
			var oItemData = [];
			for (var i = 0; i < oModel.length; i++) {
				if (oMaster.Guid == null) {
					// create header
					oMaster.Flag = "P";
					oMaster.Guid = "X";
				}
				//create item 
				var oDetail = {};
				//	oDetail.Guid = oModel[i].Guid;
				//	oDetail.Ebelp = oModel[i].Ebelp;

				oDetail.Matnr = oModel[i].Matnr;
				oDetail.Maktx = oModel[i].Txz01;
				//	oDetail.Uom = oModel[i].Uom;
				/*	if(oModel[i].Verpr!==Null){
						oDetail.Verpr = oModel[i].Verpr;
					}*/
				oDetail.Verpr = oModel[i].Verpr;
				oDetail.Waers = oModel[i].Waers;
				oDetail.Wgbez = oModel[i].Wgbez;
				oDetail.Matkl = oModel[i].Matkl;
				oDetail.Knttp = oModel[i].Knttp;
				oDetail.Menge = oModel[i].Menge;
				//	oDetail.Lfdat = oModel[i].Lfdat;
				oItemData.push(oDetail);
			}

			// insert item data into header data
			oMaster.nav_htoi = oItemData;
			//get model instance
			var oModelMain = this.getOwnerComponent().getModel();
			//set http header with tokem fetch
			oModelMain.setHeaders({
				"Access-Control-Allow-Origin": "*",
				"Content-Type": "application/x-www-form-urlencoded",
				"X-CSRF-Token": "Fetch"
			});
			//fetch token and get reponse
			var token;
			oModelMain.read('/DraftitemsSet', null, null, false, function(oData, oResponse) {
					token = oResponse.headers['x-csrf-token'];
				},
				function() {
					alert("Error while reading");
				});
			//set http header for POST rest with token fetched from read
			oModelMain.setHeaders({
				"X-Requested-With": "XMLHttpRequest",
				"Content-Type": "application/json",
				"DataServiceVersion": "2.0",
				"Accept": "application/atom+xml,application/atomsvc+xml,application/xml",
				"X-CSRF-Token": token
			});
			//call POST method
			sap.ui.core.BusyIndicator.show(0);
			var that = this;
			oModelMain.create("/CheckflagSet", oMaster, {
				success: function(oData, oResponse) {
					// Success
					sap.ui.core.BusyIndicator.hide();
					var oMsg = oResponse.headers;
					//	var oEsheet = oResponse.data.Name1;
					var jsonStr = oMsg["sap-message"];
					sap.m.MessageToast.show("Items added to the cart");
					oModelMain.read("/CheckflagSet('X')", {
						success: function(r) {
							sap.ui.core.BusyIndicator.hide();
							oJSONModel.setProperty("/Flag", r);
						},
						error:function(){
							sap.ui.core.BusyIndicator.hide();
						}
					});
					oJSONModel.refresh(true);
					oModel.read("/DraftitemsSet", {
						success: function(r, s) {
							oJSONModel.setProperty("/cartModel", r.results);
							oJSONModel.refresh();
						}
					});
				},
				error:function(){
					sap.ui.core.BusyIndicator.hide();
				}
			});
			that.byId("prevTable").removeSelections(true);
		}

	});
});