sap.ui.define([
		"pr/req/controller/BaseController",
		"sap/ui/model/json/JSONModel",
		"sap/ui/model/Filter",
		"sap/m/MessageBox"
	], function(BaseController,JSONModel,Filter,MessageBox) {
		"use strict";

		return BaseController.extend("pr.req.controller.App", {

			onAfterRendering: function() {
				var oModel = this.getOwnerComponent().getModel();
				var that = this;
				var oJSONModel = new JSONModel({});
				oModel.read("/CheckflagSet('X')", {
					success: function(r) {
						var data = r;

						oJSONModel.setProperty("/flag", data);
						if (data.Flag === "Y") {
							if (!that.oMessageDialog) {
								that.oMessageDialog = sap.ui.xmlfragment("pr.req.view.messageDialog", that);
								that.getView().addDependent(that.oMessageDialog);

							}
							// forward compact/cozy style into Dialog
							that.oMessageDialog.addStyleClass(that.getOwnerComponent().getContentDensityClass());

							that.oMessageDialog.open();

						}

					},

					error: function() {

						MessageBox.error("Unable to retrieve data for flag. Please try again.");
					}
				});
			},
			onContinueToCartPress: function() {
				var oModel = this.getOwnerComponent().getModel();
			//	var oJSONModel = this.getOwnerComponent().getModel("json");
				//this.Guid = oJSONModel.getProperty("/flag")[0].Guid;filters: aFilter,
				//var aFilter = [new Filter("Guid", "EQ", this.Guid)];
				oModel.read("/DraftitemsSet", {
					
					success: function(r) {
						var cartnum = r.results;
					//	oJSONModel.setProperty("/cartNo", cartnum);

					},
					error: function() {

						MessageBox.error("Unable to retrieve cartData. Please try again.");
					}
				});
			},
			onDiscard:function(){
				var oModel= this.getOwnerComponent().getModel();
				/*	oModel.delete("/DraftitemsSet", {
					success: function(r) {
						var cartnum = r.results;
					//	oJSONModel.setProperty("/cartNo", cartnum);

					},
					error: function() {

						MessageBox.error("Unable to delete records from cartData. Please try again.");
					}
				});*/
					this.oMessageDialog.close();
			},
		

			onShoppingCartPressed: function() {
				this.getRouter().navTo("cart", {});
			}

			//////OnInit std app logic/////
			/*	var oViewModel,
				fnSetAppNotBusy,
				oListSelector = this.getOwnerComponent().oListSelector,
				iOriginalBusyDelay = this.getView().getBusyIndicatorDelay();

			oViewModel = new JSONModel({
				busy : true,
				delay : 0
			});
			this.setModel(oViewModel, "appView");

			fnSetAppNotBusy = function() {
				oViewModel.setProperty("/busy", false);
				oViewModel.setProperty("/delay", iOriginalBusyDelay);
			};

			this.getOwnerComponent().getModel().metadataLoaded()
					.then(fnSetAppNotBusy);

			// Makes sure that master view is hidden in split app
			// after a new list entry has been selected.
			oListSelector.attachListSelectionChange(function () {
				this.byId("idAppControl").hideMaster();
			}, this);*/

			// apply content density mode to root view
			//	this.getView().addStyleClass(this.getOwnerComponent().getContentDensityClass());

		});

	}

);