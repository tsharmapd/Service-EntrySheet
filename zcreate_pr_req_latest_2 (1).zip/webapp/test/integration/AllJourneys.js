jQuery.sap.require("sap.ui.qunit.qunit-css");
jQuery.sap.require("sap.ui.thirdparty.qunit");
jQuery.sap.require("sap.ui.qunit.qunit-junit");
QUnit.config.autostart = false;

// We cannot provide stable mock data out of the template.
// If you introduce mock data, by adding .json files in your webapp/localService/mockdata folder you have to provide the following minimum data:
// * At least 3 SesHeaderSet in the list
// * All 3 SesHeaderSet have at least one nav_htoi

sap.ui.require([
	"sap/ui/test/Opa5",
	"pr/req/test/integration/pages/Common",
	"sap/ui/test/opaQunit",
	"pr/req/test/integration/pages/App",
	"pr/req/test/integration/pages/Browser",
	"pr/req/test/integration/pages/Master",
	"pr/req/test/integration/pages/Detail",
	"pr/req/test/integration/pages/NotFound"
], function (Opa5, Common) {
	"use strict";
	Opa5.extendConfig({
		arrangements: new Common(),
		viewNamespace: "pr.req.view."
	});

	sap.ui.require([
		"pr/req/test/integration/MasterJourney",
		"pr/req/test/integration/NavigationJourney",
		"pr/req/test/integration/NotFoundJourney",
		"pr/req/test/integration/BusyJourney",
		"pr/req/test/integration/FLPIntegrationJourney"
	], function () {
		QUnit.start();
	});
});