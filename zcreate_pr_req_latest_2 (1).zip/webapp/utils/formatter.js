sap.ui.define([], function() {
	"use strict";
	return {
		/**
		 * itemMaster date change
		 */

		getDateValue: function(oDate) {

			var changeDate = oDate;
			var b = changeDate.split("", 8);
			return b[4] + b[5] + "/" + b[6] + b[7] + "/" + b[0] + b[1] + b[2] + b[3];
		},
		removeLeadingZeros: function(stringWithZeros, desc, data) {
			if (stringWithZeros) {
				return stringWithZeros.replace(/^0+/, '') + " " + desc + "     " + data;
			}
		},

		masterremoveLeadingZeros: function(stringWithZeros) {
			if (stringWithZeros) {
				return stringWithZeros.replace(/^0+/, '');
			}
		},
		statusText: function(a, b) {
			return a + " " + b;
		},
		checkBox: function(x) {
			if (x == "X") {
				return true;
			} else {
				return false;
			}
		},
	
		/**
		 * Function that returns the date from json model date
		 * Eg. input /Date(132842349234)/ , output Jan 22, 2015
		 * @param inputDate
		 * @returns {*}
		 */
		formatDateFromString: function(inputDate, format) {
			if (inputDate == null) {
				// return 'No date';
				return "";
			}
			// modified the code becoz if  inputdate is of type string, then value doesnt set to datepicker 
			if (typeof(inputDate) == "string") {
				var dateToReturn = raytheon.gto.utils.Formatter.milliDateConvertion(inputDate, format, "false");
			} else {
				var dateToReturn = raytheon.gto.utils.Formatter.milliDateConvertion(inputDate, format, "");
			}
			var date = new Date(dateToReturn),
				mnth = ("0" + (date.getMonth() + 1)).slice(-2),
				day = ("0" + date.getDate()).slice(-2);
			return [mnth, day, date.getFullYear()].join("/");

		},

		milliDateConvertion: function(date, format, formatOption) {
			var fDate = '';
			var oDateFormat = "";
			if (format) {
				oDateFormat = sap.ui.core.format.DateFormat.getDateInstance({
					pattern: format
				});
			} else {
				oDateFormat = sap.ui.core.format.DateFormat.getDateInstance({
					pattern: 'MM/DD/YYYY'
				});
			}

			if (date) {
				var now = date.replace(/[^0-9]/g, '');
				if (formatOption != null) {
					if (formatOption === "false") {
						fDate = new Date(Number(now));
					} else {
						fDate = oDateFormat.format(new Date(Number(now)));
					}
				} else {
					fDate = oDateFormat.format(new Date(Number(now)));
				}
			} else {
				fDate = 'MM/DD/YYYY';
			}
			return fDate;
		}

		/**
		 * Removes the leading zeros from a string
		 * @param stringWithZeros
		 * @returns {XML|string|void}
		 */

	};
});