sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/m/MessageBox",
	"sap/m/MessageToast",
	"sap/ui/model/Filter"
], function(Controller, MessageBox, MessageToast, Filter) {
	"use strict";

	return Controller.extend("pr.req.controller.CreateItem", {
		onInit: function() {},
		getRouter: function() {
			return sap.ui.core.UIComponent.getRouterFor(this);
		},
		//Shopping cart press
		onCreateShoppingCartPressed: function(oEvent) {
			var oJSONModel = this.getOwnerComponent().getModel("json");
			sap.ui.core.BusyIndicator.show();
			this.getOwnerComponent().getModel().read("/DraftitemsSet", {
				success: function(r) {
					sap.ui.core.BusyIndicator.hide();
					oJSONModel.setProperty("/cartModel", r.results);
				}
			});
			// to open shopping cart fragment from favorite view	
			if (!this.ocartPress) {
				this.ocartPress = sap.ui.xmlfragment("pr.req.view.fragment.ShoppingCart", this);
				this.getView().addDependent(this.ocartPress);
				this.ocartPress.setModel(oJSONModel);
				oJSONModel.refresh();
			}
			//setting model to the cart
			this.ocartPress.setModel(oJSONModel);
			oJSONModel.refresh();
			this.ocartPress.open();
		},
		validateInput: function(oEvent) {
			if (oEvent.getSource().getValue() !== "") {
				oEvent.getSource().setValueState("None");
			}
		},
		stateChange: function(oEvent) {
			if (oEvent.getSource().getSelectedKey() !== "") {
				oEvent.getSource().setValueState("None");
			}
		},
		// called to add the created item to the favorites 
		onAddCreatedItemToFavPress: function() {
			//validations
			var canProceed = true;
			var shText = this.byId("shtextId");
			if (shText.getValue() === "") {
				shText.setValueState("Error");
				shText.setValueStateText("Enter short text");
				canProceed = false;
			}

			var qtyVal = this.byId("qtyId");
			if (qtyVal.getValue() === "" || qtyVal.getValue() === 0 || qtyVal.getValue() < 1) {
				qtyVal.setValueState("Error");
				qtyVal.setValueStateText("Invalid Quantity");
				canProceed = false;
			}
			var UomId = this.byId("UomId");
			if (UomId.getSelectedKey() === "") {
				UomId.setValueState("Error");
				UomId.setValueStateText("Enter Unit of Measure");
				canProceed = false;
			}
			var valPric = this.byId("valprId");
			if (valPric.getValue() === "") {
				valPric.setValueState("Error");
				valPric.setValueStateText("Enter Valuation Price");
				canProceed = false;
			}
			var omat = this.byId("matgrpId");
				if (omat.getValue() === "") {
				omat.setValueState("Error");
				omat.setValueStateText("Enter Material");
				canProceed = false;
			}
			// when validations are satisfied
			if (canProceed) {
				var matrlGrp = this.byId("matgrpId").getValue();
				var oModel = this.getOwnerComponent().getModel();
				var oJSONModel = this.getOwnerComponent().getModel("json");
				// currency val is defaulted to CAD
				var crcyVal = "CAD";
				var addToCart = {};
				addToCart.Maktx = shText.getValue();
				addToCart.Matnr = shText.getValue();
				addToCart.Menge = qtyVal.getValue();
				addToCart.Uom = UomId.getSelectedKey();
				addToCart.Verpr = valPric.getValue();
				addToCart.Waers = crcyVal;
				addToCart.Wgbez = this.byId("matgrpId").getValue();
				var matrlNum = oJSONModel.getData().Matrlnumber;
				addToCart.Matkl = matrlNum;
				var that = this;
				oModel.create("/FavoriteSet", addToCart, {
					success: function(oData, oResponse) {
						MessageToast.show("Item Added to Favorites");
						oModel.read("/CheckflagSet('F')", {
							success: function(r) {
								oJSONModel.setProperty("/favCount", r);
								// after adding create item to favorites , to set the favorites count on the master view
								that.getOwnerComponent()._oViews._oViews["pr.req.view.Master"].byId("FavList").setInfo(r.Count);
								oJSONModel.refresh(true);
								that.refreshCreateItem();
							}
						});
					},
					error: function() {
						sap.ui.core.BusyIndicator.hide();
					}
				});
			} else {
				MessageBox.warning("Please fill all the fields to add as favoite Item");
			}
		},
		// to refresh all the entries
		refreshCreateItem: function() {
			this.byId("shtextId").setValue("");
			this.byId("shtextId").setValueState("None");
			this.byId("qtyId").setValue("");
			this.byId("qtyId").setValueState("None");
			this.byId("UomId").setSelectedKey("");
			this.byId("UomId").setValueState("None");
			this.byId("valprId").setValue("");
			this.byId("valprId").setValueState("None");
			this.byId("deldtId").setValue("");
			this.byId("deldtId").setValueState("None");
			this.byId("matgrpId").setValue("");
			this.byId("cmntsId").setValue("");
		},
		// to delete the draft items from the cart  
		onDeletePressed: function(oEvent) {
			var oModel = this.getOwnerComponent().getModel();
			var oJSONModel = this.getOwnerComponent().getModel("json");
			var selctdItem = oEvent.getParameter("listItem").getBindingContext("json").getObject();
			var olinenum = selctdItem.Ebelp;
			var Guid = selctdItem.Guid;
			//delete method to remove cart  items
			oModel.remove("/DraftlineSet(Guid='" + Guid + "',Ebelp='" + olinenum + "')", {
				success: function(data, response) {
					sap.ui.core.BusyIndicator.hide();
					oModel.read("/DraftitemsSet", {
						success: function(r, s) {
							oJSONModel.setProperty("/cartModel", r.results);
						}
					});
					MessageToast.show("Draft item successfully removed from cart");
					oModel.read("/CheckflagSet('X')", {
						success: function(r) {
							sap.ui.core.BusyIndicator.hide();
							oJSONModel.setProperty("/Flag", r);
						}
					});
					oJSONModel.refresh("true");
				}
			});
		},

		///// cart dialog cancel closes dialog
		cancel: function() {
			this.ocartPress.close();
		},
		//// navigation on View cart press on cart dialog
		ViewCart: function(oEvt) {
			var cartId = "cartId";
			this.getOwnerComponent().getRouter().navTo("cart", {
				cartId: cartId
			});
		},
		// to add the created item to cart
		onCreateItemPress: function() {
			//validations
			var canProceed = true;
			var shText = this.byId("shtextId");
			if (shText.getValue() === "") {
				shText.setValueState("Error");
				shText.setValueStateText("Enter short text");
				canProceed = false;
			}

			var qtyVal = this.byId("qtyId");
			if (qtyVal.getValue() === "" || qtyVal.getValue() === 0 || qtyVal.getValue() < 1) {
				qtyVal.setValueState("Error");
				qtyVal.setValueStateText("Invalid Quantity");
				canProceed = false;
			}
			var UomId = this.byId("UomId");
			if (UomId.getSelectedKey() === "") {
				UomId.setValueState("Error");
				UomId.setValueStateText("Enter Unit of Measure");
				canProceed = false;
			}
			var valPric = this.byId("valprId");
			if (valPric.getValue() === "") {
				valPric.setValueState("Error");
				valPric.setValueStateText("Enter Valuation Price");
				canProceed = false;
			}
			var updatedFormat;
			var delvyDt = this.byId("deldtId").getDateValue();
			if (this.byId("deldtId").getDateValue() === "") {
				updatedFormat = null;
				 this.byId("deldtId").setValueState("Error");
				  this.byId("deldtId").setValueStateTest("please enter date");
				  canProceed = false ;
			
			} else {
				var oDate = new Date(delvyDt);
				// to update date in system date format
				updatedFormat = [oDate.getFullYear(), oDate.getMonth() + 1, oDate.getDate()].join("-");
			}
				var omat = this.byId("matgrpId");
				if (omat.getValue() === "") {
				omat.setValueState("Error");
				omat.setValueStateText("Enter Material");
				canProceed = false;
			}
			
			var matrlGrp = this.byId("matgrpId").getValue();
			if(canProceed){
			var oModel = this.getOwnerComponent().getModel();
			var oJSONModel = this.getOwnerComponent().getModel("json");
			var matrlNum = oJSONModel.getData().Matrlnumber;
			var crcyVal = "CAD";
			var addToCart = {};
			//	addToCart.Knttp = accAsgn;
			addToCart.Text1 = shText.getValue();
			addToCart.Maktx = shText.getValue();
			addToCart.Menge = qtyVal.getValue();
			addToCart.Uom = UomId.getSelectedKey();
			addToCart.Verpr = valPric.getValue();
			addToCart.Preis = valPric.getValue();
			addToCart.Waers = crcyVal;
			addToCart.Wgbez = this.byId("matgrpId").getValue();
			addToCart.DelDate = updatedFormat;
			addToCart.Matkl = matrlNum;
			var that = this;
			oModel.create("/DraftitemsSet", addToCart, {
				success: function(oData, oResponse) {
					MessageToast.show("Draft Item Successfully created");
					that.refreshCreateItem();
					oModel.read("/CheckflagSet('X')", {
						success: function(r) {
							sap.ui.core.BusyIndicator.hide();
							oJSONModel.setProperty("/Flag", r);
							oJSONModel.refresh("true");
						}
					});
				},
				error: function() {
					sap.ui.core.BusyIndicator.hide();
				}
			});
			}
			else{
				MessageBox.warning("please fill all the fields to add item to Cart");
			}
			// to reset the values after posting
		/*	this.byId("shtextId").setValue("");
			this.byId("shtextId").setValueState("None");
			this.byId("qtyId").setValue("");
			this.byId("qtyId").setValueState("None");
			this.byId("UomId").setSelectedKey("");
			this.byId("UomId").setValueState("None");
			this.byId("valprId").setValue("");
			this.byId("valprId").setValueState("None");
			this.byId("deldtId").setValue("");
			this.byId("deldtId").setValueState("None");
			this.byId("matgrpId").setValue("");
			this.byId("cmntsId").setValue("");*/

		},

		// on decline press  reset all the entered values 	
		onDeleteCreateItem: function() {
			this.byId("shtextId").setValue("");
			this.byId("qtyId").setValue("");
			this.byId("UomId").setSelectedKey("");
			this.byId("valprId").setValue("");
			this.byId("deldtId").setValue("");
			this.byId("matgrpId").setValue("");
		},
		//  f4 value help request opens a dialog list	
		handleValueHelp: function(oEvent) {
			var sInputValue = oEvent.getSource().getValue();
			this.inputId = oEvent.getSource().getId();
			// create value help dialog
			if (!this._valueHelpDialog) {
				this._valueHelpDialog = sap.ui.xmlfragment("pr.req.view.fragment.ValueHelp", this);
				this.getView().addDependent(this._valueHelpDialog);
			}

			// create a filter for the binding
			this._valueHelpDialog.getBinding("items").filter([new Filter(
				"Wgbez60",
				sap.ui.model.FilterOperator.Contains, sInputValue
			)]);

			// open value help dialog filtered by the input value
			this._valueHelpDialog.open(sInputValue);
		},
		// fuzzy search for value help filter
		_handleValueHelpSearch: function(evt) {
			var sValue = evt.getParameter("value");
			var oFilter = new Filter(
				"Wgbez60",
				sap.ui.model.FilterOperator.Contains, sValue
			);
			evt.getSource().getBinding("items").filter([oFilter]);
		},
		// called to close valuehelp dialog
		_handleValueHelpClose: function(evt) {
			var that = this;
			var oJSONModel = that.getOwnerComponent().getModel("json");
			var oSelectedItem = evt.getParameter("selectedItem");
			
			if (oSelectedItem) {
				var orderInput = this.byId("matgrpId");
				orderInput.setValueState("None");
				orderInput.setValue(oSelectedItem.getTitle());
				var oVal = oSelectedItem.getDescription();
				oJSONModel.setProperty("/Matrlnumber", oVal);

			}

			evt.getSource().getBinding("items").filter([]);
		},
		// to filter live change values in value help
		_handleLiveChange: function(oEvent) {
			var that = this;
			var aFilters = [];
			var sQuery = oEvent.getParameters().value;
			if (sQuery && sQuery.length > 0) {
				var filter = new Filter("Wgbez60", sap.ui.model.FilterOperator.Contains, sQuery);
				aFilters.push(filter);
			}
			var oList = sap.ui.getCore().byId("list");
			var oBinding = oList.getBinding("items");
			oBinding.filter(aFilters);
		},
		// navigation back from create item view
		onCrtItemNavBack: function(oEvent) {
			var objId = "objectId";
			this.getRouter().navTo("object", {
				objectId: objId
			});
		}

	});
});