sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/core/routing/History",
	"sap/m/MessageBox",
	"sap/m/MessageToast",

], function(Controller, History, MessageBox, MessageToast) {
	"use strict";

	return Controller.extend("pr.req.controller.ShoppingCart", {

		onInit: function() {
			this.getOwnerComponent().getRouter().getRoute("cart").attachPatternMatched(this._onMatched, this);

		},
		// triggers whenever route matches
		_onMatched: function() {
			var oModel = this.getOwnerComponent().getModel();
			var oJSONModel = this.getOwnerComponent().getModel("json");
			this.selection = oJSONModel.getProperty("/SelectedKey");
			if (this.selection == "R") {
				this.getView().byId("wbsLbl").setVisible(true);
				this.getView().byId("wbsId").setVisible(true);
			} else {
				this.getView().byId("wbsLbl").setVisible(false);
				this.getView().byId("wbsId").setVisible(false);
			}
			sap.ui.core.BusyIndicator.show(0);
			var that = this;
			// called to set the cart Model
			oModel.read("/DraftitemsSet", {
				success: function(r) {
					sap.ui.core.BusyIndicator.hide();
					oJSONModel.setProperty("/cartModel", r.results);
					var oCartModel = that.getOwnerComponent().getModel("json").getData().cartModel;

					var gTotal = 0.00;
					for (var i = 0; i < oCartModel.length; i++) {
						if (oCartModel[i].Menge && oCartModel[i].Verpr) {
							// total equal  to qty multiplied by price
							oCartModel[i].Total = (oCartModel[i].Menge * oCartModel[i].Verpr).toFixed(2);
							// sum of all items total
							gTotal = ((Number(oCartModel[i].Total) + Number(gTotal)) * 1).toFixed(2);
							that.getOwnerComponent().getModel("json").refresh(true);
						}
						that.getOwnerComponent().getModel("json").refresh(true);
						oJSONModel.setProperty("/sumTotal", gTotal);
					}
				},
				error: function() {
					sap.ui.core.BusyIndicator.hide();
					MessageToast.show("Unable to get records from cartData. Please try again.");
				}
			});
			//called to set the count of the cart
			oModel.read("/CheckflagSet('X')", {
				success: function(r) {
					oJSONModel.setProperty("/Flag", r);
				}
			});
			// called to get the address
			oModel.read("/AddressSet", {
				success: function(r) {
					oJSONModel.setProperty("/addrModel", r.results);
				}
			});
		},
		/// navigation back to previous hash
		onNavBack: function() {
			var sPreviousHash = History.getInstance().getPreviousHash(),
				oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation");
			if (sPreviousHash !== undefined || !oCrossAppNavigator.isInitialNavigation()) {
				history.go(-1);
			} else {
				oCrossAppNavigator.toExternal({
					target: {
						shellHash: "#Shell-home"
					}
				});
			}
		},

		// to get the total w.r.t the quantity entered
		onQuantityChange: function(oEvent) {
			var that = this;
			var oJSONModel = that.getOwnerComponent().getModel("json");
			var qty = oEvent.getSource().getValue();
			var gTotal = 0.00;
			var oCartModel = that.getOwnerComponent().getModel("json").getData().cartModel;
			var gTotal = 0.00;
			for (var i = 0; i < oCartModel.length; i++) {
				if (qty && oCartModel[i].Verpr) {
					oCartModel[i].Total = (qty * oCartModel[i].Verpr).toFixed(2);
					gTotal = ((Number(oCartModel[i].Total) + Number(gTotal)) * 1).toFixed(2);
					that.getOwnerComponent().getModel("json").refresh(true);
				}
				that.getOwnerComponent().getModel("json").refresh(true);
				oJSONModel.setProperty("/sumTotal", gTotal);
			}
		},

		// Remove all items from the cart view
		RemoveAllItems: function() {
			var oModel = this.getOwnerComponent().getModel();
			var oJSONModel = this.getOwnerComponent().getModel("json");
			var oRecord = this.getView().getModel("json").getData().cartModel[0];
			var delData = {};
			delData.Guid = oRecord.Guid;
			var srecord = oRecord.Guid;
			sap.ui.core.BusyIndicator.show(0);
			// to remove all items from the shopping cart view
			oModel.remove("/DraftitemsSet('" + srecord + "')", delData, {
				success: function(data, response) {
					sap.ui.core.BusyIndicator.hide();
					MessageToast.show("Draft items successfully removed ");
					oJSONModel.refresh(true);
				},
				error: function() {
					sap.ui.core.BusyIndicator.hide();
					MessageToast.show("Unable to delete records from cartData. Please try again.");
				}
			});
			// to refresh Address after removing items
			this.refreshAddress();
			//called  to set cart model after deletion
			oModel.read("/DraftitemsSet", {
				success: function(r) {
					oJSONModel.setProperty("/cartModel", r.results);
					//called to set count after deletion
					oModel.read("/CheckflagSet('X')", {
						success: function(r) {
							sap.ui.core.BusyIndicator.hide();
							oJSONModel.setProperty("/Flag", r);
						}
					});
					oJSONModel.refresh(true);
				}
			});
			oJSONModel.refresh();
		},
		// to refresh all the entries after posting or deleting
		refreshCart: function() {
			this.byId("cmnts").setValue("");
			this.byId("namId").setValue("");
			this.byId("strtId").setValue("");
			this.byId("pstlId").setValue("");
			this.byId("cityId").setValue("");
			this.byId("ctryId").setValue("");
			this.byId("phnId").setValue("");
			this.byId("carId").setValue("");
			this.byId("HeaderId").setNumber("");
			var oJsonModel = this.getOwnerComponent().getModel("json");
			oJsonModel.setProperty("/tablebindingModel", "");
			oJsonModel.refresh();

		},
		// to refresh address after posting or deleting
		refreshAddress: function() {
			this.byId("cmnts").setValue("");
			this.byId("namId").setValue("");
			this.byId("strtId").setValue("");
			this.byId("pstlId").setValue("");
			this.byId("cityId").setValue("");
			this.byId("ctryId").setValue("");
			this.byId("phnId").setValue("");
			this.byId("carId").setValue("");
			this.byId("HeaderId").setNumber("");
		},
		// All items in the cart are posted to order
		onOrderPressed: function() {
			var oModel = this.getOwnerComponent().getModel("json").getData().cartModel;
			var oTable = this.byId("checkOutTable").getItems();
			var oJSONModel = this.getOwnerComponent().getModel("json");
			this.selection = oJSONModel.getProperty("/SelectedKey");
			var canContinue = true;
			if (this.selection == "R") {
				if (this.byId("wbsId").getValue() === "") {
					this.byId("wbsId").setValueState("Error");
					this.byId("wbsId").setValueStateText("WBS Element should not be empty");
					canContinue = false;
				}
			}
			// to get selected key cost centre,thirdparty, project
			this.Knttp = oJSONModel.getProperty("/SelectedKey");

			//store all the context/contextPath of the table in an array
			var oMaster = {};
			var oItemData = [];
			for (var i = 0; i < oModel.length; i++) {
				if (oMaster.Guid == null) {
					// create header	///P///	
					oMaster.Flag = "X";
					oMaster.Guid = oModel[i].Guid;
				}
				//create item 
				var oDetail = {};
				oDetail.Guid = oModel[i].Guid;
				oDetail.Ebelp = oModel[i].Ebelp;
				oDetail.Text = this.byId("cmnts").getValue();
				oDetail.Name1 = this.byId("namId").getValue();
				oDetail.Street = this.byId("strtId").getValue();
				oDetail.PostCode1 = this.byId("pstlId").getValue();
				oDetail.City1 = this.byId("cityId").getValue();
				oDetail.Country = this.byId("ctryId").getValue();
				oDetail.MobNumber = this.byId("phnId").getValue();
				oDetail.Carrier = this.byId("carId").getValue();
				oDetail.WbsEle = this.byId("wbsId").getValue();
				oDetail.Matnr = oModel[i].Matnr;
				oDetail.Maktx = oModel[i].Maktx;
				oDetail.Uom = oModel[i].Uom;
				oDetail.Preis = oModel[i].Verpr;
				oDetail.Verpr = oModel[i].Verpr;
				oDetail.Waers = oModel[i].Waers;
				oDetail.Matkl = oModel[i].Matkl;
				oDetail.Knttp = this.Knttp;
				oDetail.Menge = oModel[i].Menge;
				oItemData.push(oDetail);
			}
			// insert item data into header data
			oMaster.nav_htoi = oItemData;
			//get model instance
			var oModelMain = this.getOwnerComponent().getModel();
			//set http header with tokem fetch
			oModelMain.setHeaders({
				"Access-Control-Allow-Origin": "*",
				"Content-Type": "application/x-www-form-urlencoded",
				"X-CSRF-Token": "Fetch"
			});
			//fetch token and get reponse
			var token;
			oModelMain.read('/DraftitemsSet', null, null, false, function(oData, oResponse) {
					token = oResponse.headers['x-csrf-token'];
				},
				function() {

				});
			//set http header for POST rest with token fetched from read
			oModelMain.setHeaders({
				"X-Requested-With": "XMLHttpRequest",
				"Content-Type": "application/json",
				"DataServiceVersion": "2.0",
				"Accept": "application/atom+xml,application/atomsvc+xml,application/xml",
				"X-CSRF-Token": token
			});
			//call POST method
			sap.ui.core.BusyIndicator.show(0);
			var that = this;
			oModelMain.create("/CheckflagSet", oMaster, {
				success: function(oData, oResponse) {
					// Success
					sap.ui.core.BusyIndicator.hide(5);
					// to set the created order number to the title of print/view fragment
					oJSONModel.setProperty("/title", oResponse.data.Banfn);
					oJSONModel.refresh();
					var oMsg = oResponse.headers;
					//	var oEsheet = oResponse.data.Name1;
					var jsonStr = oMsg["sap-message"];
					sap.m.MessageToast.show((JSON.parse(jsonStr).message));

					// opens the dialog to print/preview 
					if (!that.odialog) {
						that.odialog = sap.ui.xmlfragment("pr.req.view.fragment.pDialog", that);
						that.getView().addDependent(that.odialog);
						that.odialog.setModel(oJSONModel);
						var prNum = oJSONModel.getProperty("/title");
						var prNo = "00" + prNum;
						oJSONModel.refresh();
						sap.ui.getCore().byId("pId").setText("Purchase Requisition '" + prNo + "' Created.");
						that.odialog.open();
					}
					// to open dialog during second rendering
					if (that.odialog) {
						var prNum = oJSONModel.getProperty("/title");
						var prNo = "00" + prNum;
						oJSONModel.refresh();
						sap.ui.getCore().byId("pId").setText("Purchase Requisition '" + prNo + "' Created.");
						that.odialog.open();
					}
					// To set count of cart after order
					oModelMain.read("/CheckflagSet('X')", {
						success: function(r) {
							oJSONModel.setProperty("/Flag", r);
							oJSONModel.refresh("true");
							// to set cart model data after placing an order
							oModelMain.read("/DraftitemsSet", {
								success: function(r) {

									oJSONModel.setProperty("/cartModel", r.results);
									sap.ui.core.BusyIndicator.hide();
								}
							});
							oJSONModel.refresh();
						}
					});
					//add create operation for uploading files to backend

					var oFileName = that.byId("attach");
					if (oFileName.getValue()) {
						var sPath = "/sap/opu/odata/sap/ZMM_ODATA_PR_NEW_SRV/SesAttachSet";
						var sFileVal = oFileName.getValue();
						var sGuid = oMaster.Guid;

						var sUrl = sPath + "(Filename='" + sFileVal + "',sGuid='')/$value";
						oFileName.setUploadUrl(sUrl);
						oFileName.setSendXHR(true);

						//add header parameters
						that.getOwnerComponent().getModel().refreshSecurityToken();
						var file = jQuery.sap.domById(oFileName.getId() + "-fu").files[0];
						var base64_marker = 'data:' + file.type + ';base64,';
						var reader = new FileReader();
						reader.onload = (function(theFile) {
							return function(evt) {
								var base64Index = evt.target.result.indexOf(base64_marker) + base64_marker.length;
								var base64 = evt.target.result.substring(base64Index);
								var token = that.getOwnerComponent().getModel().getHeaders()['x-csrf-token'];
								$.ajaxSetup({
									cache: false
								});

								jQuery.ajax({
									url: sPath,
									async: false,
									dataType: 'json',
									cache: false,
									data: base64,
									type: "POST",
									beforeSend: function(xhr) {
										xhr.setRequestHeader("X-CSRF-Token", token);
										xhr.setRequestHeader("Content-Type", file.type);
										xhr.setRequestHeader("slug", sFileVal + ",");
									},
									success: function(odata) {
										oFileName.setValue("");
									}
								});
							};
						})(file);
						reader.readAsDataURL(file);

					} //get value from file if condition
				},
				error: function(oError) {
					// Error
					sap.ui.core.BusyIndicator.hide();
					jQuery.sap.require("sap.m.MessageBox");
					sap.m.MessageBox.show((JSON.parse(oError.responseText).error.message.value), {
						icon: sap.m.MessageBox.Icon.Information,
						title: "Message Box"
					});
				}
			});

		},
		// called to print/view the pdf of the created purchase order
		onPrintPress: function() {

			var oModel = this.getOwnerComponent().getModel();
			var oJSONModel = this.getOwnerComponent().getModel("json");
			var that = this;
			var Banfn = oJSONModel.getProperty("/title");
			var banfn = '00' + Banfn;
			var sRead = "/sap/opu/odata/sap/ZMM_ODATA_PR_NEW_SRV/pdfSet(Banfn='" + banfn + "')" + "/$value";
			oModel.read(sRead, {
				async: true,
				success: function(odata, response) {},
				error: function() {}
			});
			window.open(sRead, "Preview", "height=800,width=1000,left=50,top=50");
			that.odialog.close();
			that.getOwnerComponent().getRouter().navTo("object");
			that.refreshCart();
		},
		// close the preview pop-up
		onCancelpDialog: function() {
			var that = this;
			that.odialog.close();
		},
		// To delete the selected item from the cart///
		onDeleteSelectedItemPressed: function(oEvent) {
			var that = this;
			var oModel = this.getOwnerComponent().getModel();
			var oJSONModel = this.getOwnerComponent().getModel("json");
			var selctdItem = oEvent.getParameter("listItem").getBindingContext("json").getObject();
			var price = selctdItem.Total;
			var olinenum = selctdItem.Ebelp;
			var Guid = selctdItem.Guid;
			sap.ui.core.BusyIndicator.show(0);
			oModel.remove("/DraftlineSet(Guid='" + Guid + "',Ebelp='" + olinenum + "')", {
				success: function(data, response) {
					sap.ui.core.BusyIndicator.hide();
					MessageToast.show("Draft item successfully removed ");
					var gTotal = 0.00;
					var oCartModel = that.getOwnerComponent().getModel("json").getData().cartModel;
					that.getOwnerComponent().getModel("json").refresh(true);
					oCartModel.splice(oCartModel.indexOf(selctdItem), 1);
					oJSONModel.setProperty("/cartModel", oCartModel);
					var oTable = that.byId("checkOutTable");
					oTable.getModel("json").refresh();
					// to get and set the total after deleting items
					for (var i = 0; i < oCartModel.length; i++) {
						if (oCartModel[i].Menge && oCartModel[i].Verpr) {
							oCartModel[i].Total = (oCartModel[i].Menge * oCartModel[i].Verpr).toFixed(2);
						}
					}
					that.getOwnerComponent().getModel("json").refresh(true);
					//updating count of cart icon after deletion
					oModel.read("/CheckflagSet('X')", {
						success: function(r) {
							oJSONModel.setProperty("/Flag", r);
						}
					});
					var total = oJSONModel.getProperty("/sumTotal");
					var gtotal = total - price;
					oJSONModel.getProperty("/sumTotal", gtotal);
					that.byId("HeaderId").setNumber(gtotal);
				}
			});
		},

		///Attachment
		openAttachmentPress: function() {
			if (!this.dialogAttachment) {
				this.dialogAttachment = sap.ui.xmlfragment("pr.req.view.fragment.AttachmentDialog", this);
			}
			this.dialogAttachment.open();
		},
		//attachment cancel press
		onAttachmentCancelPress: function() {
			this.dialogAttachment.close();
		},
		// on attachment submit press
		onAttachmentSubmitPress: function() {
			this.dialogAttachment.close();
		}

	});
});