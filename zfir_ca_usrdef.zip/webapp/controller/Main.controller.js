sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/m/MessageToast"
], function(Controller, MessageToast) {
	"use strict";

	return Controller.extend("zfir_ca_usrdef.controller.Main", {

		//init function
		onInit: function() {
			var oLayout = this.byId("lb1");
			oLayout.setLayoutData(
				new sap.m.FlexItemData({
					alignSelf: sap.m.FlexAlignSelf.Center
				})
			);
			var oLayoutj = this.byId("lb2");
			oLayoutj.setLayoutData(
				new sap.m.FlexItemData({
					alignSelf: sap.m.FlexAlignSelf.Center
				})
			);
			//get model
			var that = this; //instance of view
			var oModel = this.getOwnerComponent().getModel();
			var JSONModel = this.getOwnerComponent().getModel("json");
			sap.ui.core.BusyIndicator.show(0);
			oModel.read("/UserdefSet('')", {
				success: function(r) {
					var oRig = r.Rig;
					var oText = that.byId("val");
					oText.setValue(oRig);
					var oJb = r.Job;
					var oJob = that.byId("val2");
					oJob.setValue(oJb);
					JSONModel.setProperty("/Rig", oRig);
					JSONModel.setProperty("/Job", oJb);
					sap.ui.core.BusyIndicator.hide();
				},
				error: function(oError) {
					sap.ui.core.BusyIndicator.hide();
					sap.m.MessageToast.show("Rig is not maintained yet!!");
				}
			});

		}, //end of onInit

		//on Save button
		onUpdate: function(evt) {
			var json = this.getOwnerComponent().getModel("json");
			var oModel = this.getOwnerComponent().getModel();
			var JSONModel = this.getOwnerComponent().getModel("json");
			var oPrev = json.getData().Rig;
			var oJob = json.getData().Job;
			var that = this;
			var oVal = this.byId("val").getProperty("value");
			var oValjob = this.byId("val2").getProperty("value");
			if (oVal) {
				if (oVal === "001") {
					MessageToast.show("Invalid Rig Number!!");
				} else {
					//save values
					var oMaster = {};
					oMaster.Rig = oVal;
					oMaster.Job = oValjob;
					//set http header with tokem fetch
					oModel.setHeaders({
						"Access-Control-Allow-Origin": "*",
						"Content-Type": "application/x-www-form-urlencoded",
						"X-CSRF-Token": "Fetch"
					});
					//fetch token and get reponse
					var token;
					oModel.read("/UserdefSet", null, null, false, function(oData, oResponse) {
							token = oResponse.headers["x-csrf-token"];
						},
						function() {
							MessageToast.show("Error while reading");
						});
					//set http header for POST rest with token fetched from read
					oModel.setHeaders({
						"X-Requested-With": "XMLHttpRequest",
						"Content-Type": "application/json",
						"DataServiceVersion": "2.0",
						"Accept": "application/atom+xml,application/atomsvc+xml,application/xml",
						"X-CSRF-Token": token
					});
					sap.ui.core.BusyIndicator.show(0);
					oModel.create("/UserdefSet", oMaster, {
						success: function(oData, oResponse) {
							// Success
							sap.ui.core.BusyIndicator.hide();
							var oMsg = oResponse.headers;
							var jsonStr = oMsg["sap-message"];
							sap.m.MessageToast.show((JSON.parse(jsonStr).message));
							JSONModel.setProperty("/Rig", oVal);
							JSONModel.setProperty("/Job", oValjob);
						},
						error: function(oError) {
							// Error
							var sJob = oJob;
							var oText = that.byId("val2");
							oText.setValue(sJob);
							var sRig = oPrev;
							oText = that.byId("val");
							oText.setValue(sRig);
							sap.ui.core.BusyIndicator.hide();
							jQuery.sap.require("sap.m.MessageBox");
							sap.m.MessageBox.show((JSON.parse(oError.responseText).error.message.value), {
								icon: sap.m.MessageBox.Icon.Information,
								title: "Message Box"
							});
						}
					});
				}
			} else {
				var oRig = this.byId("val2").getValue();
				sap.ui.core.BusyIndicator.show(0);
				oModel.remove("/UserdefSet('" + oRig + "')", {
					method: "DELETE",
					success: function(oData, oResponse) {
						sap.ui.core.BusyIndicator.hide();
						JSONModel.setProperty("/Rig", oData);
						var oText = that.byId("val");
						oText.setValue("");
						oText = that.byId("val2");
						oText.setValue("");
						sap.m.MessageToast.show("Defaults set to initial as Rig is blank!!");
					},
					error: function(oError) {
						sap.ui.core.BusyIndicator.hide();
						sap.m.MessageToast.show("Not able to update yet!!");
					}
				});
			}
		},

		//on Reset button
		onReset: function(evt) {
			var that = this; //instance of view
			var oRig = this.byId("val").getValue();
			var oModel = this.getOwnerComponent().getModel();
			var JSONModel = this.getOwnerComponent().getModel("json");
			sap.ui.core.BusyIndicator.show(0);
			oModel.remove("/UserdefSet('" + oRig + "')", {
				method: "DELETE",
				success: function(oData, oResponse) {
					sap.ui.core.BusyIndicator.hide();
					JSONModel.setProperty("/Rig", oData);
					var oMsg = oResponse.headers;
					var jsonStr = oMsg["sap-message"];
					var oText = that.byId("val");
					oText.setValue("");
					oText = that.byId("val2");
					oText.setValue("");
					sap.m.MessageToast.show((JSON.parse(jsonStr).message));
				},
				error: function(oError) {
					sap.ui.core.BusyIndicator.hide();
					sap.m.MessageToast.show("Not able to reset yet!!");
				}
			});
		}
	});
});