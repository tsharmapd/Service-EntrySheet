/*eslint-disable no-console, no-alert */
sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/m/MessageToast"
], function(Controller,JSONModel,MessageToast) {
	"use strict";

	return Controller.extend("zfir_mm_cses.controller.Master", {

		onInit: function() {
			var oView= this.getView();
			var oModel = this.getOwnerComponent().getModel();
			var JSONModel = this.getOwnerComponent().getModel("json");
		
			
			oModel.read("/SesHeaderSet", {
						
			
				success: function(r) {
					var notes = r.results;
					JSONModel.setProperty("/listDataModel", notes);
					
				},
				error: function() {
				
					MessageToast.error("Unable to retrieve notes. Please try again.");
				}
			});
		},
			
		
			
//			var oModel = new sap.ui.model.odata.ODataModel(
//				"/sap/opu/odata/SAP/ZMM_CREATE_SES_SRV", true);
			//			var oArray;

/*
			oModel.attachRequestCompleted(function() {
				var data = oModel.getData();
				console.log(data);
			});
*/

//			oModel.read("/SesHeaderSet",
//				null, null, true,
//				function(oData, oResponse) {});

			/*
			      this.setModel(odataModel, "odataModel");
						var oModelheader = new sap.ui.model.json.JSONModel();
						var oArray1 = oArray.results;
						oModelheader.setData({
							modelData: oArray1
						});
						var oHeader = sap.ui.getCore().byId("list");
						oHeader.setModel(oModelheader);
						oHeader.bindRows("/modelData");
						//var oModel = new oDataModel(jQuery.sap.getModulePath("sap.ui.demo.mock", "/products.json"));
						//this.getView().setModel(oModel);
			*/
		
		getRouter : function () {
			return sap.ui.core.UIComponent.getRouterFor(this);
		},
		onListItemPress: function(evt) {
		//var oList = this.byId("listId");
		// var  oitem =oList.getBinding("items");
		 var ocontx= evt.getSource().mProperties.title;
		 
			//this.index = oList.indexOfItem(evt.getParameter("listItem"));
			//this.itemNumber = oList.getBinding("items").getModel().getData().lineItemHeader[this.index].Ebeln;
		//	var oItem = evt.getSource();
		//	var oCtx = oItem.getBindingContext();
			this.getRouter().navTo("detail",{
				ebeln : ocontx
			});
			//bind table list with corresponding valus of services
			
			MessageToast.show("Pressed : " + evt.getSource().getTitle());
		},

		onNav: function(oEvent) {
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("detail");
		},

		handleSearch: function(evt) {
			var filters = {};
			var query = evt.getParameter("query");
			if (query && query.length > 0) {
				var filter = new sap.ui.model.Filter("Ebeln", sap.ui.model.FilterOperator.Contains, query);
				filters.push(filter);
			} //need to add logic for backend search by calling service 

			//update items
			var list = this.getView().byId("list");
			var binding = list.getBinding("items");
			binding.filter(filters);
		}

	});
});