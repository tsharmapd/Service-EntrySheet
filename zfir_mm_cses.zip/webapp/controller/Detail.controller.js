/*eslint linebreak-style: ["error", "windows"]*/
sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/core/routing/History"
], function(Controller, History) {
	"use strict";

	return Controller.extend("zfir_mm_cses.controller.Detail", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf zfir_mm_cses.view.view.Detail
		 */
		onInit: function() {
			var oRouter = this.getRouter();
			oRouter.getRoute("detail").attachMatched(this._onRouteMatched, this);
		},

		onBack: function() {
			var oHistory = History.getInstance();
			var oPrevHash = oHistory.getPreviousHash();
			if (oPrevHash !== undefined) {
				window.history.go(-1);
			} else {
				var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
				oRouter.navTo("overview", true);
			}
		},

		getRouter: function() {
			return sap.ui.core.UIComponent.getRouterFor(this);
		},

		onEdit: function(oEvent) {

			var oTable = sap.ui.getCore().byId("items");


		},

		onSave: function(oEvent) {
			var oView = this.getView();
			var oModel = new sap.ui.model.json.JSONModel();
			oModel = oView.getModel();
			var oTable = this.byId("items");
			var oItems = oTable.getItems();
			//store all the context/contextPath of the table in an array
			var aContexts = oTable.getItems().map(function(oItem) {
				return oItem.getBindingContext().getPath(); // binding path
			});
			var count = aContexts.length;
			var oMaster = {};
			var oItemData = [];
			aContexts.forEach(function(sPath, index) {
				var i = index;
				var qty = oItems[i].getAggregation("cells")[3].getProperty("value");
				oModel.setProperty(sPath + '/Menge', qty);
				var oLine = oModel.getProperty(sPath);
				if (oMaster.Ebeln == null) {
					// create header			
					oMaster.Ebeln = oLine.Ebeln;
					oMaster.Name1 = "abc";
				}
				//create item 
				var oDetail = {};
				oDetail.Ebeln = oMaster.Ebeln;
				oDetail.Ebelp = oLine.Ebelp;
				oDetail.Menge = qty;
				oDetail.Meins = oLine.Meins;
				oDetail.Brtwr = oLine.Brtwr;
				oDetail.Wmenge = oLine.Wmenge;
				oDetail.ShortTetx = oLine.ShortTetx;
				oItemData.push(oDetail);
			});

			// insert item data into header data
			oMaster.nav_htoi = oItemData;
			//send data to backend to create service entry sheet
			oModel.setHeaders({
				"Access-Control-Allow-Origin": "*",
				"Content-Type": "application/x-www-form-urlencoded",
				"X-CSRF-Token": "Fetch"
			});
			var token;
			oModel.read('/SesHeaderSet', null, null, false, function(oData, oResponse) {
						token = oResponse.headers['x-csrf-token'];
					},
					function() {
						alert("Error while reading")
					})
				//set http POST rest

			oModel.setHeaders({
				"X-Requested-With": "XMLHttpRequest",
				"Content-Type": "application/json",
				"DataServiceVersion": "2.0",
				"Accept": "application/atom+xml,application/atomsvc+xml,application/xml",
				"X-CSRF-Token": token
			});

			//call create method
			oModel.create('/SesHeaderSet', oMaster, null, function(oData, oResponse) {
					alert("Success!")
				},
				function() {
					alert("Problem!")
				})


		},

		_onRouteMatched: function(oEvent) {
			var oArgs, oView;

			oArgs = oEvent.getParameter("arguments");
			oView = this.getView();
			var sObjectPath = ("'" + oArgs.ebeln + "'");
			oView.bindElement({
				path: "/SesHeaderSet(" + sObjectPath + ")",
				events: {
					change: this._onBindingChange.bind(this),
					dataRequested: function(oEvent) {
						oView.setBusy(true);
					},
					dataReceived: function(oEvent) {
						oView.setBusy(false);
					}
				}
			});
		},

		_onBindingChange: function(oEvent) {
				// No data for the binding
				if (!this.getView().getBindingContext()) {
					this.getRouter().getTargets().display("notFound");
				}
			}
			/**
			 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
			 * (NOT before the first rendering! onInit() is used for that one!).
			 * @memberOf zfir_mm_cses.view.view.Detail
			 */
			//	onBeforeRendering: function() {
			//
			//	},

		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf zfir_mm_cses.view.view.Detail
		 */
		//	onAfterRendering: function() {

		//	}

		/**
		 * Called whthe Controller is destroyed. Use this one to free resources and finalize activities.
		 * @memberOf zfir_mm_cses.view.view.Detail
		 */
		//	onExit: function() {
		//
		//	}

	});

});