jQuery.sap.require("sap.ui.qunit.qunit-css");
jQuery.sap.require("sap.ui.thirdparty.qunit");
jQuery.sap.require("sap.ui.qunit.qunit-junit");
QUnit.config.autostart = false;

sap.ui.require([
		"sap/ui/test/Opa5",
		"fm/test/integration/pages/Common",
		"sap/ui/test/opaQunit",
		"fm/test/integration/pages/Worklist",
		"fm/test/integration/pages/Object",
		"fm/test/integration/pages/NotFound",
		"fm/test/integration/pages/Browser",
		"fm/test/integration/pages/App"
	], function (Opa5, Common) {
	"use strict";
	Opa5.extendConfig({
		arrangements: new Common(),
		viewNamespace: "fm.view."
	});

	sap.ui.require([
		"fm/test/integration/WorklistJourney",
		"fm/test/integration/ObjectJourney",
		"fm/test/integration/NavigationJourney",
		"fm/test/integration/NotFoundJourney",
		"fm/test/integration/FLPIntegrationJourney"
	], function () {
		QUnit.start();
	});
});