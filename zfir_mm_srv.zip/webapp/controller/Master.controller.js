sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/m/MessageToast",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/Filter",
	"zfir_mm_srv/model/formatter"
], function(Controller, MessageToast, JSONModel, Filter, formatter) {
	"use strict";

	return Controller.extend("zfir_mm_srv.controller.Master", {
		formatter: formatter,
		oGroupSort: {
			sGroupKey: null,
			bGroupDescending: null,
			sSortKey: null,
			bSortDescending: null
		},
		// Constants:
		PO_ITEMS_TABLE: {
			ID: "POItemsTable",
			SORT_KEY: {
				EADAT: "Eadat",
				EBELN: "Ebeln"
			}
		},
		//get the model instance
		onInit: function() {
			var oModel = this.getOwnerComponent().getModel();
			JSONModel = this.getOwnerComponent().getModel("json");
			sap.ui.core.BusyIndicator.show(0);
			//read entityset SesHeaderSet 
			oModel.read("/EbelnVHSet", {
				success: function(r) {
					var oResults = r.results;
					JSONModel.setProperty("/ebelnDataModel", oResults);
				},
				error: function() {
					sap.ui.core.BusyIndicator.hide();
					MessageToast.show("Unable to retrieve data. Please try again.");
				}
			});
			oModel.read("/LgortVHSet", {
				success: function(r) {
					var oResults = r.results;
					JSONModel.setProperty("/lgortDataModel", oResults);
				},
				error: function() {
					sap.ui.core.BusyIndicator.hide();
					MessageToast.show("Unable to retrieve data. Please try again.");
				}
			});
			oModel.read("/VendorVHSet", {
				success: function(r) {
					var oResults = r.results;
					JSONModel.setProperty("/vendorDataModel", oResults);
				},
				error: function() {
					sap.ui.core.BusyIndicator.hide();
					MessageToast.show("Unable to retrieve data. Please try again.");
				}
			});
			//read entityset UomVHSet for uom f4 
			oModel.read("/UomVHSet", {
				success: function(r) {
					var oResults = r.results;
					JSONModel.setProperty("/uomDataModel", oResults);
					sap.ui.core.BusyIndicator.hide();
				},
				error: function() {
					sap.ui.core.BusyIndicator.hide();
					MessageToast.show("Unable to retrieve data. Please try again.");
				}
			});
			//disable sort button
			var oSort = this.byId("sort");
			oSort.setEnabled(false);
		},

		//method to get router instance
		getRouter: function() {
			return sap.ui.core.UIComponent.getRouterFor(this);
		},

		//called when item is pressed
		onListItemPress: function(evt) {
			//get the ebeln presed
			var oCtx = evt.getSource().getTitle();
			var oLine = evt.getSource().getBindingContext("json").getProperty("Ebelp");
			//navigate to detail view the clicked ebeln
			this.getRouter().navTo("detail", {
				ebeln: oCtx,
				ebelp: oLine
			});

			MessageToast.show("Order : " + evt.getSource().getTitle());
		},

		//called on search control
		handleSearch: function(evt) {
			var aFilters = [];
			var sQuery = evt.getSource().getValue();
			if (sQuery && sQuery.length > 0) {
				var filter = new Filter("Ebeln", sap.ui.model.FilterOperator.Contains, sQuery);
				aFilters.push(filter);
			}
			var oList = this.getView().byId("list");
			var oBinding = oList.getBinding("items");
			oBinding.filter(aFilters);
		},

		//call on filter value change
		onChange: function(oEvent) {
			this.byId("filterBar").fireFilterChange(oEvent);
		},
		//reset all filters
		onReset: function(oEvent) {
			var oItems = this.byId("filterBar").getAllFilterItems(true);
			for (var i = 0; i < oItems.length; i++) {
				var oControl = this.byId("filterBar").determineControlByFilterItem(oItems[i]);
				if (oControl) {
					oControl.setValue("");
				}
			}
		},
		//Search functionality based on values in filters
		onSearch: function(oEvent) {
			var i;
			var oControl;
			var filter;
			var aFilter = [];
			var aFilters = this.byId("filterBar").getFilterGroupItems();
			var aFiltersWithValue = [];
			for (i = 0; i < aFilters.length; i++) {
				oControl = this.byId("filterBar").determineControlByFilterItem(aFilters[i]);
				if (oControl && oControl.getValue && oControl.getValue()) {
					aFiltersWithValue.push(aFilters[i]);
					if (i === 0) {
						filter = new Filter("Ebeln", sap.ui.model.FilterOperator.Contains, oControl.getValue());
						aFilter.push(filter);
					}
					if (i === 1) {
						var nDate = sap.ui.core.format.DateFormat.getDateInstance({
							pattern: "yyyy-MM-dd"
						});
						var oDatef = nDate.format(new Date(oControl.getValue()));
						var oDateout = oDatef + 'T00:00:00';
						filter = new Filter("Eadat", sap.ui.model.FilterOperator.EQ, oDateout);
						aFilter.push(filter);
					}
					if (i === 2) {
						filter = new Filter("Lgort", sap.ui.model.FilterOperator.EQ, oControl.getSelectedKey());
						aFilter.push(filter);
					}
					if (i === 3) {
						filter = new Filter("Lifnr", sap.ui.model.FilterOperator.EQ, oControl.getSelectedKey());
						aFilter.push(filter);
					}
				}
			}

			var oModel = this.getOwnerComponent().getModel();
			JSONModel = this.getOwnerComponent().getModel("json");
			var oSort = this.byId("sort");
			sap.ui.core.BusyIndicator.show(0);
			//read entityset SesHeaderSet 
			oModel.read("/SesHeaderSet", {
				filters: aFilter,
				success: function(r) {
					var oResults = r.results;
					JSONModel.setProperty("/listDataModel", oResults);
					if (oResults.length === 0) {
						oSort.setEnabled(false);

					} else {
						oSort.setEnabled(true);
					}
					sap.ui.core.BusyIndicator.hide();
				},
				error: function() {
					oSort.setEnabled(false);
					sap.ui.core.BusyIndicator.hide();
					MessageToast.show("Unable to retrieve data. Please try again.");
				}
			});
		},
		//add f4 valuehelp for Purchase Order
		handleValueHelpPo: function(oEvent) {
			var sInputValue = oEvent.getSource().getValue();
			this.inputId = oEvent.getSource().getId();
			// create value help dialog
			if (!this._oPOf4) {
				this._oPOf4 = sap.ui.xmlfragment(
					"zfir_mm_srv.view.POf4",
					this
				);
				this.getView().addDependent(this._oPOf4);
			}
			// create a filter for the binding
			this._oPOf4.getBinding("items").filter([new Filter(
				"Ebeln",
				sap.ui.model.FilterOperator.Contains, sInputValue
			)]);
			// open value help dialog filtered by the input value
			this._oPOf4.open(sInputValue);
		},
		//addf4 valuehelp for Storage Locations
		handleValueHelpLg: function(oEvent) {
			var sInputValue = oEvent.getSource().getValue();
			this.inputId = oEvent.getSource().getId();
			// create value help dialog
			if (!this._oSLf4) {
				this._oSLf4 = sap.ui.xmlfragment(
					"zfir_mm_srv.view.SLf4",
					this
				);
				this.getView().addDependent(this._oSLf4);
			}
			// create a filter for the binding
			this._oSLf4.getBinding("items").filter([new Filter(
				"Lgobe",
				sap.ui.model.FilterOperator.Contains, sInputValue
			)]);
			// open value help dialog filtered by the input value
			this._oSLf4.open(sInputValue);
		},
		//add f4 valuehelp for Vendor
		//addf4 valuehelp for Storage Locations
		handleValueHelpLf: function(oEvent) {
			var sInputValue = oEvent.getSource().getValue();
			this.inputId = oEvent.getSource().getId();
			// create value help dialog
			if (!this._oLFf4) {
				this._oLFf4 = sap.ui.xmlfragment(
					"zfir_mm_srv.view.LFf4",
					this
				);
				this.getView().addDependent(this._oLFf4);
			}
			// create a filter for the binding
			this._oLFf4.getBinding("items").filter([new Filter(
				"Name1",
				sap.ui.model.FilterOperator.Contains, sInputValue
			)]);
			// open value help dialog filtered by the input value
			this._oLFf4.open(sInputValue);
		},
		_handleValueHelpSearch: function(evt) {
			var oDialog = evt.getParameter("id");
			var sValue = evt.getParameter("value");
			var oFilter;
			if (oDialog === "pod") {
				oFilter = new Filter(
					"Ebeln",
					sap.ui.model.FilterOperator.Contains, sValue
				);
			} else {
				if (oDialog === "sld") {
					oFilter = new Filter(
						"Lgobe",
						sap.ui.model.FilterOperator.Contains, sValue
					);
				} else {
					oFilter = new Filter(
						"Name1",
						sap.ui.model.FilterOperator.Contains, sValue
					);
				}
			}
			evt.getSource().getBinding("items").filter([oFilter]);
		},
		_handleValueHelpClose: function(evt) {
			var orderInput;
			var oDialog = evt.getParameter("id");
			var oSelectedItem = evt.getParameter("selectedItem");
			if (oSelectedItem) {
				if (oDialog === "pod") {
					orderInput = this.byId("po");
					orderInput.setValue(oSelectedItem.getTitle());
				} else {
					if (oDialog === "sld") {
						orderInput = this.byId("sl");
						orderInput.setValue(oSelectedItem.getTitle());
					} else {
						orderInput = this.byId("lf");
						orderInput.setValue(oSelectedItem.getTitle());
					}
				}
			}
			evt.getSource().getBinding("items").filter([]);
		},

		//sorter function called when sorting is called
		handleSort: function() {
			if (!this._lineItemViewDialog) {
				this._lineItemViewDialog = new sap.m.ViewSettingsDialog({
					sortDescending: this.oGroupSort.bSortDescending,
					sortItems: [
						new sap.m.ViewSettingsItem({
							text: "Created On",
							key: this.PO_ITEMS_TABLE.SORT_KEY.EADAT,
							selected: this.oGroupSort.sSortKey === this.PO_ITEMS_TABLE.SORT_KEY.EADAT
						}),
						new sap.m.ViewSettingsItem({
							text: "Purchase Order",
							key: this.PO_ITEMS_TABLE.SORT_KEY.EBELN,
							selected: this.oGroupSort.sSortKey === this.PO_ITEMS_TABLE.SORT_KEY.EBELN
						})
					],
					confirm: jQuery.proxy(
						function(evt) {
							var oParams = evt.getParameters();
							this.oGroupSort.sSortKey = oParams.sortItem.getKey();
							this.oGroupSort.bSortDescending = oParams.sortDescending;
							this._groupSortItemTable();
							this.iCurNumItems = 0;
						}, this)
				});
				jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), this._lineItemViewDialog);
			}
			this._lineItemViewDialog.open();
		},

		/* Called if sorting or grouping of table is changed */
		_groupSortItemTable: function() {
			var oOverviewBinding;
			var aSorter = [];
			if ((this.oGroupSort.sGroupKey === null)) {
				if (this.oGroupSort.sSortKey === this.PO_ITEMS_TABLE.SORT_KEY.EADAT) {
					aSorter.push(new sap.ui.model.Sorter(this.PO_ITEMS_TABLE.SORT_KEY.EADAT, this.oGroupSort.bSortDescending, false));
				} else {
					if (this.oGroupSort.sSortKey === this.PO_ITEMS_TABLE.SORT_KEY.EBELN) {
						aSorter.push(new sap.ui.model.Sorter(this.PO_ITEMS_TABLE.SORT_KEY.EBELN, this.oGroupSort.bSortDescending, false));
					} else {
						aSorter.push(new sap.ui.model.Sorter(this.oGroupSort.sSortKey, this.oGroupSort.bSortDescending, false));
					}
				}
			}
			oOverviewBinding = this.byId("list").getBinding("items");
			oOverviewBinding.sort(aSorter);
		}
	});
});