sap.ui.define([], function() {
	"use strict";

	return {
		/**
		 * Rounds the currency value to 2 digits
		 *
		 * @public
		 * @param {string} sValue value to be formatted
		 * @returns {string} formatted currency value with 2 digits
		 */
		currencyValue: function(sValue) {
			if (!sValue) {
				return "";
			}

			return parseFloat(sValue).toFixed(2);
		},

		decimal : function(value) {
			if (value) {
				var oInt = parseInt(value);
				return oInt;
			} else {
				return value;
			}
		},

		decimalHeader : function(Ebelp,Txz01) {
			if (Ebelp) {
				var oInt = parseInt(Ebelp);
				return ("Item:" + oInt + "-" + Txz01);
			} else {
				return Ebelp;
			}
		},
		
		date: function(value) {
			if (value) {
				var oDateFormat = sap.ui.core.format.DateFormat.getDateTimeInstance({
					pattern: "dd/MM/yyyy"
				});
				var date = new Date(value.getUTCFullYear(), value.getUTCMonth(), value.getUTCDate());
				return ("Created on: " + oDateFormat.format(new Date(date)));
			} else {
				return value;
			}
		}
	};

});